#include <npendel.hpp>
#include <iostream>
#include <fstream>
#include <string>
#include <limits.h>
#include <time.h>
#include <gl_objects.hpp>
#include <limits>


#ifndef MACX
#include <GL/gl.h>
#include <GL/glext.h>
#else//MACX
#include <OpenGL/gl.h>
#include <OpenGL/glext.h>
#endif//MACX

using namespace std;



void NPendel::farbiger_quader(const BoxDim &dim,const GLfloat color[4])
{
  glPushMatrix();
  glColor3f(color[0],color[1],color[2]);
  glTranslatef(dim.offset[0],dim.offset[1], dim.offset[2]);
  glScalef(dim.size[0], dim.size[1], dim.size[2]);
  
  glPushAttrib(GL_POLYGON_BIT);
  
  glEnable(GL_POLYGON_OFFSET_FILL);
  glPolygonOffset(1.0f,1.0f);
  
  globj::Cube cube(1);
  cube.draw();
  
  glDisable(GL_POLYGON_OFFSET_FILL);
  glLineWidth(2);
  glPolygonMode(GL_FRONT,GL_LINE);
  glDisable(GL_LIGHTING);
  glColor3f(0.0,0.0,0.0);
  
  cube.draw();
  
  glEnable(GL_LIGHTING);
  glPopAttrib();
  
  glPopMatrix();
}


void NPendel::init_frames()
{
  selectedBody=-1;
  Frame f;
  f.t=0.0;
  f.m[0][0]=1;  f.m[0][1]=0;  f.m[0][2]=0;  f.m[0][3]=0;
  f.m[1][0]=0;  f.m[1][1]=1;  f.m[1][2]=0;  f.m[1][3]=0;
  f.m[2][0]=0;  f.m[2][1]=0;  f.m[2][2]=1;  f.m[2][3]=0;
  f.m[3][0]=0;  f.m[3][1]=0;  f.m[3][2]=0;  f.m[3][3]=1;
  for(int j=0;j<nObj;j++)
    {
      frames[j].clear();
      const float v=j*0.25;
      f.m[3][2]=v;
      frames[j].push_back(f);
    }
  
}


NPendel::NPendel():
  dataLoaded(false)
{
  dataDir=".";
  
  resize(get_n_files());
  
  indexMax=0;
  
  list=0;
  nList=0;
}


NPendel::~NPendel(){}

int NPendel::get_n_files()
{
  QStringList filters;
  QDir dir(dataDir);
  filters<<"animations_datei_*.dat";
  dir.setNameFilters(filters);
  int n=dir.count();
  //qDebug()<<"get_n_files: n= "<<n;
  return n>0?n:1;
}


void NPendel::resize(const int nObj_)
{
  //detect number of files  
  //qDebug()<<"resize("<<nObj_<<")\n";
  nObj=nObj_;
  frames.resize(nObj);
  dataFile.resize(nObj);
  boxDim.resize(nObj);
  for(int i=0;i<nObj;i++)
    {
      char str[256];
      snprintf(str,256,"animations_datei_%02d.dat",i);
      dataFile[i]=str;
      boxDim[i].offset[0]=0;
      boxDim[i].offset[1]=0;
      boxDim[i].offset[2]=0;
      boxDim[i].size[0]=0.3;
      boxDim[i].size[1]=0.2;
      boxDim[i].size[2]=0.2;
    }
  init_frames();
  
  
  
}

double NPendel::getTMax() const
{
  //use time from first object
  if(indexMax>0)
    return frames[0][indexMax].t;
  return 0.0;
}

double NPendel::getTMin() const
{
  return frames[0][0].t;
}
size_t NPendel::getTimeIndex(const double t) const
{
  const double tMin=getTMin();
  const double tMax=getTMax();
  int index;
  
  if(t<tMin)
    index=0;
  else if(t>tMax)
    index=indexMax;
  else
    {
      double T=tMax-tMin;
      if(T>1e-7)//division by zero?
        {
          index=round(indexMax*(t-tMin)/T);
          if(index<0)
            {
              qDebug()<<__PRETTY_FUNCTION__<<" error, 0> index= "<<index;
              index=0;
            }
          else if(index>indexMax)
            {
              qDebug()<<__PRETTY_FUNCTION__<<" error, indexMax < index= "<<index;
              index=indexMax;
            }
        }
      else
        index=0;
    }
  return (size_t)index;
}

void NPendel::transform(const double t, const int no)
{
  GLfloat m[4][4];
  getTransform(m,t,no);
  glMultMatrixf((GLfloat *)m);
}
void NPendel::getTransform(GLfloat m[4][4], const double t, const int body)
{
  
  size_t index=getTimeIndex(t);
  // copy
  for(int i=0;i<4;i++)
    for(int j=0;j<4;j++)
      m[i][j]=frames[body][index].m[i][j];
}



void NPendel::loadData()
{
  int nNew=get_n_files();
  qDebug()<<" loadData, nNew= "<<nNew<< "nObj= "<<nObj;
  
  if(nObj != nNew)
    resize(nNew);
  
  
  
  //TODO load data ;)
  int i;//,j;//,idx_min=numeric_limits<int>::max();
  uint idx_min=numeric_limits<uint>::max();
  double trash;
  
  ifstream infile;
  QString name;
  
  //read object position and orientation
  for(i=0;i<nObj;i++)
    {
      Frame f;
      frames[i].clear();
      
      indexMax=0;
      name=dataDir+"/"+dataFile[i];
      infile.clear();
      infile.open(name.toAscii(),ios::binary);
      
      qDebug()<<" loading name= "<<name<<" (i= "<<i<<")";
      if(!infile.good())
        {
          qDebug()<<__PRETTY_FUNCTION__<<" Cannot open file "<<name<<"\n";
          return;
        }
      
      //cuboid dimensions
      char c;
      infile>>c;
      if(c=='#')
        {
          infile>>boxDim[i].offset[0];
          infile>>boxDim[i].offset[1];
          infile>>boxDim[i].offset[2];
          infile>>boxDim[i].size[0];
          infile>>boxDim[i].size[1];
          infile>>boxDim[i].size[2];
          char trash[2048];
          infile.getline(trash,2048);

//          qDebug()<<"got boxDim.offset= "<<boxDim[i].offset[0]<<" "<<boxDim[i].offset[1]<<" "<<boxDim[i].offset[2];
//          qDebug()<<"got boxDim.size= "<<boxDim[i].size[0]<<" "<<boxDim[i].size[1]<<" "<<boxDim[i].size[2];
//          qDebug()<<"got trash= "<<trash;
        }
      else
        {
          qDebug()<<"warning: error reading cuboid dimensions, using defaults";
          char trash[2048];
          infile.getline(trash,2048);
        }

      skipInfileComments(infile);

      while(infile.good())
        {
          infile>>trash;//time       
          f.t=trash;
          infile>>trash;  f.m[3][0]=trash;
          infile>>trash;  f.m[3][1]=trash;
          infile>>trash;  f.m[3][2]=trash;
          infile>>trash;  f.m[0][0]=trash;
          infile>>trash;  f.m[1][0]=trash;
          infile>>trash;  f.m[2][0]=trash;
          infile>>trash;  f.m[0][1]=trash;
          infile>>trash;  f.m[1][1]=trash;
          infile>>trash;  f.m[2][1]=trash;
          infile>>trash;  f.m[0][2]=trash;
          infile>>trash;  f.m[1][2]=trash;
          infile>>trash;  f.m[2][2]=trash;
          f.m[0][3] = 0;
          f.m[1][3] = 0;
          f.m[2][3] = 0;
          f.m[3][3] = 1;

          if(infile.eof())
            {
              //qDebug()<<"infile.eof()!! infile.good()= "<<infile.good()<<" infile.eof()= "<<infile.eof();
//              char line[2048];
//              infile.getline(line,2048);
//              qDebug()<<" line= "<<line;
              break;
            }
          
          frames[i].push_back(f);
          
          indexMax++;
        }
      
      if(frames[i].size()<idx_min)
        idx_min=frames[i].size();
      
      infile.close();
    }
  
  // if no data was loaded
  if(frames[0].size() == 0)
    {
      init_frames();
      indexMax=0;
    }
  else
    {
      indexMax=frames[0].size();
      for(size_t i=1; i<frames.size();i++)
	if(indexMax>frames[i].size())
	  indexMax=frames[i].size();
      indexMax--;
    }
  
  makeList();
  
}

void NPendel::drawWithNames(const double t)
{
  for(int i=0;i<nObj;i++)
    {
      glPushName(i);
      glPushMatrix();
      transform(t,i);
      glCallList(list+i);
      glPopMatrix();
      glPopName();
    }
}

void NPendel::drawAxes(const double t, const float len, const bool hidden)
{
  glDisable(GL_LIGHTING);
  for(int i=1; i<nObj; i++)
    {
      glPushMatrix();
      {
        //      #define USE_ALPHA
        
        transform(t,i);
        
#ifdef USE_ALPHA
        const GLfloat a=0.75f;
        if(hidden) {
          glLineWidth(1);
          glEnable(GL_BLEND);
          glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
          glColor4f(1,0,0,a);
        } else {
          glLineWidth(2);
          glDisable(GL_BLEND);
          glColor3f(1,0,0);
        }
#else
        if(hidden) {
          glLineWidth(1);
          glEnable(GL_LINE_STIPPLE);
          glLineStipple(1,0xAAAA);
        } else {
          glLineWidth(2);
          glDisable(GL_LINE_STIPPLE);
          glLineStipple(1,0xFFFF);
        }
        glColor3f(1,0,0);
#endif
        
        glBegin(GL_LINES);
        glVertex3f(0,0,0);
        glVertex3f(len*0.75,0,0);
#ifdef USE_ALPHA
        glColor4f(0,1,0,a);
#else
        glColor3f(0,1,0);
#endif
        glVertex3f(0,0,0);
        glVertex3f(0,len*0.75,0);
        glEnd();
#ifdef USE_ALPHA
        glColor4f(0,0,1,a);
#else
        glLineWidth(2);
        //glLineStipple(2,0xBEBE);
        glLineStipple(2,0xAAAA);
        glColor3f(0,0,1);
#endif
        
        glBegin(GL_LINES);
        glVertex3f(0,0,0);
        glVertex3f(0,0,len);
        glEnd();
#ifdef USE_ALPHA
        glDisable(GL_BLEND);
#else
        glDisable(GL_LINE_STIPPLE);
#endif
      }
      glPopMatrix();
    }
  glEnable(GL_LIGHTING);
  
  
}


void NPendel::draw(const double t)
{
  glPushAttrib(GL_ENABLE_BIT);
  
  for(int i=0;i<nObj;i++)
    {
      glPushMatrix();
      transform(t,i);
      if(selectedObj == i)
        {
          glCallList(list+i);
          
          glPushAttrib(GL_POLYGON_BIT | GL_ENABLE_BIT | GL_DEPTH_BUFFER_BIT);
          glEnable(GL_BLEND);
          
          glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
          glSecondaryColor3f(10000.0f,-10000.0f,-10000.0f);
          
          glDepthFunc(GL_LEQUAL);
          
          glDisable(GL_LIGHTING);
#ifndef WIN32
          glEnable(GL_COLOR_SUM);
#else
#warning "WIN32: FIXME GL_COLOR_SUM"
          glEnable(GL_COLOR_SUM_EXT);
#endif
          glCallList(list+i);
          
          glDepthFunc(GL_LESS);
          
          //glCallList(bbxList+i);
          
          glPopAttrib(); //GL_POLYGON_BIT| ...
        }
      else
        glCallList(list+i);
      glPopMatrix(); //transform
    }
  glPopAttrib();
}

void NPendel::setDataDir(QString dataDir_)
{
  dataDir=dataDir_;
}

void NPendel::init(const QString modelDir_)
{
  modelDir=modelDir_;
  makeList();
}

void NPendel::setSelectionHit(const SelectionHit &sh)
{
  if(sh.numNames==0) // deselect
    {
      selectedObj = -1;
      return;
    }
  else if(sh.numNames > 1)
    {
      selectedBody = sh.names[1];
      selectedObj = sh.names[1];
    }
  else
    cerr<<__PRETTY_FUNCTION__<<"Something is wrong here! hint: fix this in drawWithNames()?"<<endl;
  
  cout<<"selectedBody="<<selectedBody<<"\n";
  float mat[4][4];
  getTransform(mat, sh.time, selectedBody);
  mat4f m(&mat[0][0]);
  // abs. pos. of the body frame
  vec4f bodyPos(m._L4);
  m.setL4(vec4f(0,0,0,1));
  // m.transpose();
  const vec4f hitPointAbs(sh.hitPoint[0], sh.hitPoint[1], sh.hitPoint[2]);
  const vec4f hitPointRel=m*(hitPointAbs-bodyPos);
  
  cout<<"hitPointAbs="<<hitPointAbs<<", hitPointRel"<<hitPointRel<<"\n";
  
  // cout<<"m="<<m;
  
  // selectionPoint = qglviewer::Vec(hitPointRel.x, hitPointRel.y, hitPointRel.z);
  selectionPoint = hitPointRel;
}

void NPendel::getRefPos(double ref[3],const double t)
{
  GLfloat mat[4][4];
  if(selectedBody<0)
    {
      getTransform(mat, t, 0);
      ref[0]=mat[3][0];
      ref[1]=mat[3][1];
      ref[2]=mat[3][2];
    }
  else
    {
      // int body=selectedBody<0?0:selectedBody;
      GLfloat mat[4][4];
      getTransform(mat, t, selectedBody);
      mat4f m(&mat[0][0]);
      // abs. pos. of the body frame
      vec4f bodyPos(m._L4);
      m.setL4(vec4f(0,0,0,1));
      m.transpose();
      // vec4f localPos(selectionPoint[0], selectionPoint[1], selectionPoint[2], 0.0f);
      vec4f localPos(selectionPoint);
      vec4f absPos = m*localPos + bodyPos;
      
      ref[0]=absPos.x;
      ref[1]=absPos.y;
      ref[2]=absPos.z;
    }
}



GLuint NPendel::makeList()
{
  if(list)
    {
      glDeleteLists(list,nList);
      list=0;
    }
  
  GLfloat color_shininess = 20.0;
  GLfloat mat_specular[] = {1.0,1.0,1.0, 1.0};
  glMaterialfv(GL_FRONT_AND_BACK, GL_SPECULAR, mat_specular);
  glMaterialfv(GL_FRONT_AND_BACK, GL_SHININESS, &color_shininess);
  
  list= glGenLists(nObj);
  nList=nObj;
  //qDebug()<<"generating "<<nList<<" lists";
  
  
  GLfloat red[4]={1.0,0.0,0.0,0.0};
  GLfloat green[4]={0.0,1.0,0.0,0.0};
  // Koerper
  for(int i=0; i<nList;i++)
    {
      glNewList(list+i, GL_COMPILE);
      glPushMatrix();
      if(0 == (i%2))
        farbiger_quader(boxDim[i],red);
      else
        farbiger_quader(boxDim[i],green);
      glPopMatrix();
      glEndList();
    }
  
  return list;
}
