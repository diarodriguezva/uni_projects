#ifndef __NPENDEL_HPP__
#define __NPENDEL_HPP__
#ifndef MACX
#include <GL/gl.h>
#else//MACX
#include <OpenGL/gl.h>
#endif//MACX
#include <QtCore>
#include <gl_objects.hpp>
#include "anim_interface.hpp"

class NPendel:
  public QObject, 
  public AnimInterface
{
  Q_OBJECT
 public:
  NPendel();
  ~NPendel();

  void loadData();
  void drawAxes(const double t, const float len=0.1f, const bool hidden=false);
  void draw(const double t);  
  void drawWithNames(const double t);
  void setDataDir(QString path);
  void init(const QString conf_path);
  double getTMax() const;
  double getTMin() const;
  void getRefPos(double ref[3],const double t);
  QString getName(){return QString("NPendel");}
  void setSelectionHit(const SelectionHit &sh);
 private:
  GLuint list;
  GLuint nList;
  GLuint makeList();
  QString dataDir;
  QString modelDir;
  
  bool dataLoaded;


  struct Frame
  {
    GLfloat m[4][4];//transform matrix
    double t;//time
  };
  struct BoxDim
  {
    float offset[3];
    float size[3];
  };

  size_t getTimeIndex(const double t) const;
  void getTransform(GLfloat trans[4][4], const double t, const int no);
  void transform(const double t, const int no);
  void init_frames();
  int get_n_files();
  void resize(const int nObj_);
  void farbiger_quader(const BoxDim &dim,const GLfloat color[4]);
  std::vector<std::vector<Frame> > frames;
  QVector<QString> dataFile;
  QVector<BoxDim> boxDim;
  int indexMax;
  int nObj;
  //! used for revolve around point:
  int selectedBody;
  //! point on body to track
  vec4f selectionPoint;

};



// class NPendelPlugin: public QObject, AnimPlugin
// {
// public:
//  Q_OBJECT
//  Q_INTERFACES(AnimPlugin)


//     AnimInterface *Create()
//    {
//      return (obj=new NPendel());
//    }
// };
#endif//__NPENDEL_HPP__
