#include <viewer_options_dialog.hpp>

ViewerOptionsDialog::ViewerOptionsDialog(QWidget *p):
  QDialog(p)
{
  setupUi(this);
}

ViewerOptionsDialog::~ViewerOptionsDialog(){}

void ViewerOptionsDialog::setOptions(const ViewerOptions &vo)
{
  drawAxes->setChecked(vo.drawAxes);
  moveCamera->setChecked(vo.moveCamera);
  drawMultisampling->setChecked(vo.drawMultisampled);
  drawText2D->setChecked(vo.drawText2D);
  drawCornerAxis->setChecked(vo.drawCornerAxis);
}

const ViewerOptions& ViewerOptionsDialog::getOptions()
{
  opts.drawAxes=drawAxes->isChecked();
  opts.moveCamera=moveCamera->isChecked();
  opts.drawMultisampled=drawMultisampling->isChecked();
  opts.drawText2D=drawText2D->isChecked();
  opts.drawCornerAxis=drawCornerAxis->isChecked();

  return opts;
}
