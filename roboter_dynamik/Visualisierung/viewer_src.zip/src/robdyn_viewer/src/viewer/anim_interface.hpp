#ifndef __ANIM_INTERFACE_HPP__
#define __ANIM_INTERFACE_HPP__
#include <QtCore>
#include <fstream>
#include <string>
#include <selectionHit.hpp>

class QString;
class Viewer;
namespace qglviewer{
  class ManipulatedFrame;
  class Vec;
}

/**
 * skip comment lines in data files (lines with '#' as the first
 * non-whitespace character)
 */
namespace {
  void skipInfileComments(std::ifstream &infile)
  {
    std::string tmp;
    while(infile.good()) {
      const std::streampos old_stream_pos=infile.tellg();
      getline(infile,tmp);
      size_t pos=tmp.find_first_not_of(" \t\r\n");
      if(pos==std::string::npos)
        pos=0;
      if(tmp[pos]=='#')
        continue;
      else {
        infile.seekg(old_stream_pos);
        break;
      }
    }
  }
}

/*!
  Plugin interface definition for animation objects
*/
class AnimInterface
{
public:
  enum{ANIM_TMAX_NONE=-1};
  enum{ANIM_TAKT_NONE=-1};
  AnimInterface():
    selectedObj(-1),
    nObj(0)
  {}
  AnimInterface(const int nObj_):
    selectedObj(-1),
    nObj(nObj_)
  {qDebug()<<"have "<<nObj<<" objects reged";}
  virtual ~AnimInterface(){}
  //!load data
  virtual void loadData()=0;

  /**
     draws the axes of the bodies at time \p t with a unit length of \p len.
     This function can provide two different appearances: when it is hidden
     (=obscured by an other object) (e.g. with stippled or transparant lines)
     or shown (e.g. with a thicker line). The hidden version is always visible.
  */
  virtual void drawAxes(const double t , const float len= 0.1f, const bool hidden = false){}
  //!draw object at time \p t
  virtual void draw(const double t)=0;
  /**
     draw object at time \p t with IDs (GLuint-Names) to provide information
     for selection. Overload this method in order to use this object in selections.
  */
  virtual void drawWithNames(const double t){}
  //!set path to data
  virtual void setDataDir(const QString dir_)=0;
  //!initialize plugin
  virtual void init(const QString model_path)=0;
  //!get maximum time
  virtual double getTMax()const=0;
  //!get minimum time
  virtual double getTMin()const=0;
  //!get reference frame position at time t
  virtual void getRefPos(double ref[3],const double /*t*/){ref[0]=0;ref[1]=0;ref[2]=0;};
  //!get object name
  virtual QString getName()=0;
  //!handle context menu event. default=ignore
  virtual void handleContextMenuEvent(){;}
  //!save settings
  virtual void saveSettings(QSettings &settings){;}
  //!load settings
  virtual void loadSettings(QSettings &settings){;}
  virtual void setViewer(QObject *v){}
  //!save scene as wrl
  virtual int addWrl(std::ofstream&out);
  //!returns number of selectable items in plugin
  virtual int getNumObjects() const{return nObj;}

  // //!set base index for drawWithNames
  // virtual void setNameBase(const int base){nameBase=base;};

  //!set index of selected component (-1 == deselect)
  virtual void setSelectedObj(const int index);

  /**
     Set OpenGL selection hit. The plugin can handle it internally.
     Depending on the IDs generated in drawWithNames(), hierarchical
     selections can be achieved.
     sh.numNames==0 means deselection!
  */
  virtual void setSelectionHit(const SelectionHit &sh);

  virtual qglviewer::ManipulatedFrame *getManipulator(){return 0x0;}

  /**
     defines, if this plugin provides data to draw a color bar
  */
  virtual bool hasColorBarValues(){return false;}
  /**
     returns the values for the color bar
  */
  virtual void getColorBarValues(float &min,float &max,float &indicatorVal){}

protected:
  // int nameBase;
  int selectedObj;
  int nObj;
};

inline int AnimInterface::addWrl(std::ofstream&out)
{
  qDebug()<<"plugin "<<getName()<<" : wrl-export not supported!";
  return 0;
}

inline void AnimInterface::setSelectedObj(const int num)
{
  selectedObj=num;
  // if((num>=nameBase) && (num<nObj+nameBase))
  //   selectedObj=num-nameBase;
  // else
  //   selectedObj=-1;
};

// inline void AnimInterface::setSelectionHit(const int num, const unsigned int *names, , const vec *hitPoint)
inline void AnimInterface::setSelectionHit(const SelectionHit &sh)
{
  if(sh.numNames > 2)
    qDebug()<<__PRETTY_FUNCTION__<<                                     \
      " num > 1! You should handle this function in your own plugin!";
  if(sh.numNames == 2)
    selectedObj=sh.names[1];
}

class AnimPlugin
{
public:
  AnimPlugin()
  {
    obj=0;
  }
  virtual ~AnimPlugin()
  {
    // if(obj)
    delete obj;
  }

  //!create new plugin object
  virtual AnimInterface *Create()=0;
protected:
  AnimInterface *obj;
};

Q_DECLARE_INTERFACE(AnimPlugin,
                    "am2b.Plugin.AnimPlugin/1.0");
#endif// __ANIM_INTERFACE_HPP__
