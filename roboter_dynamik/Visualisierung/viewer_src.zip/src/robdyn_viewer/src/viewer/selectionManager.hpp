#ifndef __SELECTION_MANAGER__HPP__
#define __SELECTION_MANAGER__HPP__

// #include <vector>
#include <ostream>
#include <QObject>
#include <QVector>

/**
   Defines the maximum number of hierarchical levels:
   A value of 3 should do it.
   [0]: index of the plugin in plugin manager
   [1]: usually component index of a plugin (e.g. a body)
   [2]: could be a subcomponent of e.g. a body
*/
#define MAX_NUM_NAMES 3
// Structured information of an OpenGL selection buffer entry.
// Is being filled by SelectionManager::handleSelection(...).
struct SingleSelectionHit
{
  SingleSelectionHit():numNames(0),zMin(0),zMax(0){}
  unsigned int numNames;
  unsigned int zMin;
  unsigned int zMax;
  // const unsigned int *names; // pointer to the selection buffer!
  unsigned int names[MAX_NUM_NAMES]; // 3 hierarchical levels possible!
  // compare two SingleSelectionHits
  bool operator == (SingleSelectionHit &b);
};

class SelectionManager: public QObject
{
  Q_OBJECT
  
public:
  SelectionManager();
  ~SelectionManager();
  
  void setFromSelectionBuffer( const int numHits,
			       const unsigned int *selectionBuffer,
			       const bool sortHitsInZ=true);
  // void setCurrentComponentSelection(const int index);

  friend std::ostream & operator<<(std::ostream & os, const SelectionManager &a)
  {
    os<<"--------------------\n";
    os<<"SelectionManager content:\n";
    unsigned int i=0;
    SingleSelectionHit ssh;
    foreach(ssh, a.selectionHits)
      {
	os<<i<<": numNames="<<ssh.numNames<<"; zMin="<<ssh.zMin<<"; zMax="<<ssh.zMax<<"; names=";
	const unsigned int *names=ssh.names;
	for(unsigned int j=0;j<ssh.numNames;j++,names++)
	  os<<*names<<", ";
	os<<"\n";
	++i;
      }
    os<<"--------------------\n";
    return os;
  }
  
  QVector<SingleSelectionHit> selectionHits;
  double selectionTime;
private:
  void parseSelectionBuffer(const int numHits,
			    const unsigned int *selectionBuffer,
			    const bool sortHitsInZ);
  SingleSelectionHit oldSelection;
  unsigned int oldHitIndex;
signals:
  void selectionChanged(const SingleSelectionHit &selected, const SingleSelectionHit &deselected);
};

#endif // __SELECTION_MANAGER__HPP__
