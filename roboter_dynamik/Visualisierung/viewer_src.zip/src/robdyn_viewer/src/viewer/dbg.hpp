#ifndef __DBG_HPP__
#define __DBG_HPP__
#include <QtCore>

struct DebugScoped
{
  const char*str;
  DebugScoped(const char*f):
    str(f)
  {
    qDebug()<<"DEBUG_START: "<<str<<"\n";
  }
  ~DebugScoped()
  {
    qDebug()<<"DEBUG_END: "<<str<<"\n";
  }
};

#define DBG DebugScoped __dbg__(__PRETTY_FUNCTION__)

#define DBG_LINE qDebug()<<__FILE__<<" -- "<<__LINE__;
#endif
