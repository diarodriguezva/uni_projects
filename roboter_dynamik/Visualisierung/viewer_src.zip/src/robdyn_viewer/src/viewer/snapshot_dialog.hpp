#ifndef __SNAPSHOT_DIALOG_HPP__
#define __SNAPSHOT_DIALOG_HPP__

#include <QtGui>
#include <QDialog>
#include <QColorDialog>
#include <ui_snapshot_dialog.h>
#include <viewer.hpp>


class SnapshotDialog: public QDialog, private Ui::SnapshotDialog
{
  Q_OBJECT
  
  public:

  SnapshotDialog(QWidget *p);
  ~SnapshotDialog();

  const QSize& getSize()const{return size;}		     
  void setSize(const QSize sz);
  void setWindowSize(const QSize sz);
  void setName(const QString name_);				      
  const QString&getName()const{return name;}
private slots:
  void askForName();
  void fixedRatio(int );
  void scaleChange(double);
  void accept();
private:
  QSize size;
  QSize windowSize;
  QString name;
};

#endif //__SNAPSHOT_DIALOG_HPP__
