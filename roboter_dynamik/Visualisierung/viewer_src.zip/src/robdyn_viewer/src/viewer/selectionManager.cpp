#include <algorithm>
#include <iostream>
#include <selectionManager.hpp>

using namespace std;

SelectionManager::SelectionManager():
  selectionTime(-1.0)
{}

SelectionManager::~SelectionManager(){}

bool zCompare (SingleSelectionHit a, SingleSelectionHit b) { return (a.zMin<b.zMin); }

void SelectionManager::setFromSelectionBuffer(const int numHits, const unsigned int *selectionBuffer, const bool sortZ)
{

  if (numHits <= 0)
    {
      cout<<__PRETTY_FUNCTION__<<": numHits="<<numHits<<endl;
      SingleSelectionHit none;
      emit(selectionChanged(none,oldSelection));
      oldSelection=none;
      return;
    }
  // save old selection state
  QVector<SingleSelectionHit> oldSelectionHits(selectionHits);
  parseSelectionBuffer(numHits, selectionBuffer, true);

  cout<<__PRETTY_FUNCTION__<<": numHits="<<numHits<<"; selectionBuffer=\n"<<*this<<"\n";

  // compare current with old selectionHits to enable a cycling through components
  // 1. by number/index
  bool identical=oldSelectionHits.count()==selectionHits.count();
  // 2. by values
  if(identical)
    {
      // QVectorIterator<SingleSelectionHit> oit(oldSelectionHits);
      // QVectorIterator<SingleSelectionHit> nit(selectionHits);
      for(QVectorIterator<SingleSelectionHit>oit(oldSelectionHits),nit(selectionHits);oit.hasNext();/*oit++,nit++*/)
	{
	  SingleSelectionHit oh=oit.next(), nh=nit.next();
	  const unsigned int n=oh.numNames;
	  identical = n==nh.numNames;
	  if(identical)
	    {
	      for(unsigned int i=0; i<n; i++)
		{
		  identical=(oh.names[i]==nh.names[i]);
		  if(!identical) break;
		}
	    }
	  // check again:
	  if(!identical)
	    break;
	}
    }
  // now we are shure whether we have an identical selection or not
  if(identical) // special case: cycle thru possible selections
    oldHitIndex=(oldHitIndex+1)%numHits;
  else
    oldHitIndex=0;

  SingleSelectionHit ssh = selectionHits.at(oldHitIndex);
  emit(selectionChanged(ssh,oldSelection));
  oldSelection=ssh;
}


void SelectionManager::parseSelectionBuffer(const int numHits, const unsigned int *selectionBuffer, const bool sortZ)
{
  selectionHits.clear();
  selectionHits.reserve(numHits);
  const unsigned int *sb=selectionBuffer;
  for(int i=0; i<numHits; i++)
    {
      SingleSelectionHit ssh;
      unsigned int numNames=sb[0];
      if(numNames > MAX_NUM_NAMES) {
	cerr<<__PRETTY_FUNCTION__<<": numNames="<<numNames<<" > MAX_NUM_NAMES="
	    <<MAX_NUM_NAMES<<"; clamping value!"<<endl;
	numNames=MAX_NUM_NAMES;	}
      ssh.numNames=numNames;
      ssh.zMin=sb[1];
      ssh.zMax=sb[2];
      for(unsigned int j=0;j<numNames;j++)
	ssh.names[j]=sb[3+j];
      selectionHits.push_back(ssh);
      // prepare pointer for next dataset
      sb=&sb[3+sb[0]];
    }
  if(sortZ)
    {
      std::sort(selectionHits.begin(),selectionHits.end(), zCompare);
    }
}
