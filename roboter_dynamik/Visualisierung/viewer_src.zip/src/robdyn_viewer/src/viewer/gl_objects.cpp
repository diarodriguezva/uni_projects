/*!
  @file gl_objects.cpp

  implementation file of some commonly used OpenGL drawing objects,
  such as box, sphere, more complex geometrical objects are found in
  other files beginning with 'gl_objects_XXX.cpp'

  Copyright (C) 2009 Institute of Applied Mechanics, Technische Universitaet Muenchen.
  Author: Markus Schwienbacher (schwienbacher@amm.mw.tum.de)
*/

#include "gl_objects.hpp"

#include <iostream>
#include <math.h>
#include "gl_color.hpp"

#include <QtCore>//qDebug()
#ifndef MACX
#include <GL/glext.h>
#else
#include <OpenGL/glext.h>
#endif//MACX

#ifdef WIN32
#include <windows.h>
#include <wingdi.h>
#endif//WIN32

#include <stdlib.h>
#include <assert.h>

using namespace std;

#ifdef WIN32
/*
  for win32 load opengl extensions dynamically
*/
PFNGLDRAWRANGEELEMENTSPROC glDrawRangeElements__ = NULL;
//typedef void (APIENTRY * PFNGLMULTIDRAWELEMENTSEXTPROC) (GLenum mode, const GLsizei *count, GLenum type, const GLvoid* *indices, GLsizei primcount);
PFNGLMULTIDRAWELEMENTSEXTPROC glMultiDrawElements__ = NULL;
PFNGLSECONDARYCOLOR3FEXTPROC glSecondaryColor3f__ = NULL;

static int __glext_initialized__=0;


void initGLExt()
{
  
  if(0 == __glext_initialized__)
    {
      const GLubyte *ver = glGetString( GL_VERSION );
      if(0 != ver)
	{
          qDebug()<<" got ver= "<<ver<<endl;
	  int ok=0;
	  if(ver[0] == '1')
	    {
              qDebug()<<"opengl version major = 1"<<endl;
	      if(ver[2] > '2')
		{
                  qDebug()<<"opengl version minor>2 ==> ok"<<endl;
		  ok=1;
		}
	      else
		ok=0;
	    }
	  if(ver[0] >= '2' )
	    {
              qDebug()<<"opengl version major= "<<ver[0]<<" >=2 ==> ok"<<endl;
	      ok=1;
	    }
	  if(ok)
	    {
	      glDrawRangeElements__ = (PFNGLDRAWRANGEELEMENTSPROC)wglGetProcAddress("glDrawRangeElements");
	      if(glDrawRangeElements__ != 0x0 )
		{
                  __glext_initialized__=1;
                  qDebug()<<"\n initialized glDrawRangeElements, got address= "<<hex<<glDrawRangeElements__<<dec<<endl;
		}
	      else
              {
                  qDebug()<<"\n CANNOT initialized glDrawRangeElements"<<endl;
                  abort();
              }
              glMultiDrawElements__ = (PFNGLMULTIDRAWELEMENTSEXTPROC) wglGetProcAddress("glMultiDrawElements");
              if(glMultiDrawElements__ != 0x0)
              {
                  qDebug()<<"\n initialized glMultiDrawElements, address= "<<hex<<glMultiDrawElements__<<dec<<endl;
                  __glext_initialized__=1;
              }
              else
              {
                  qDebug()<<"\n CANNOT initialized glMultiDrawElements"<<endl;
                  abort();
              }
              glSecondaryColor3f__ = (PFNGLSECONDARYCOLOR3FEXTPROC) wglGetProcAddress("glSecondaryColor3f");
              if(glSecondaryColor3f__ != 0x0)
              {
                  qDebug()<<"\n initialized glSecondaryColor3f, address= "<<hex<<glSecondaryColor3f__<<dec<<endl;
                  __glext_initialized__=1;
              }
              else
              {
                  qDebug()<<"\n CANNOT initialized glSecondaryColor3f"<<endl;
                  abort();
              }
	    }
	}
      else
        qDebug()<<" can't get version string!"<<endl;
    }
}

extern "C" void glDrawRangeElements(GLenum mode, GLuint start, GLuint end, GLsizei count, GLenum type, const GLvoid *indices)
{
  if(__glext_initialized__)
    glDrawRangeElements__(mode,  start, end, count, type, indices);
  else
    cerr<<"\n *** WARNING -- "<<__PRETTY_FUNCTION__<<" -- "<<"OpenGL extensions not initialized"<<endl;
}

extern "C" void glMultiDrawElements(GLenum mode, const GLsizei *count, GLenum type, const GLvoid* *indices, GLsizei primcount)
{
    if(__glext_initialized__ >=2)//fixme: flag per function
        glMultiDrawElements__(mode,count,type,indices,primcount);
    else
      cerr<<"\n *** WARNING -- "<<__PRETTY_FUNCTION__<<" -- "<<"OpenGL extensions not initialized"<<endl;
}


extern "C" void glSecondaryColor3f(GLfloat r, GLfloat g, GLfloat b)
{
    if(__glext_initialized__)
       glSecondaryColor3f__(r,g,b);
    else
        cerr<<"\n *** WARNING -- "<<__PRETTY_FUNCTION__<<" -- "<<"OpenGL extensions not initialized"<<endl;
}

#else //WIN32
void initGLExt(){}
#endif//WIN32

namespace globj
{
  //==================================================
  // GLOBJECT
  //==================================================
  GLObject::GLObject()
  {
    list=0;
    listBuilt=false;
  }
  GLObject::~GLObject()
  {
    if(listBuilt)
      glDeleteLists(list,1);
  }
  
  void GLObject::genList()
  {
    if(listBuilt)
      glDeleteLists(list,1);
    list=glGenLists(1);
    glNewList(list, GL_COMPILE);   
    draw();
    glEndList();
    listBuilt=true;
  }
  
  void GLObject::callList()
  {
    glCallList(list);
  }
  
  
  //========================================
  // C Y L I N D E R
  //========================================
  Cylinder::Cylinder(const GLfloat r,
		     const GLfloat h,
		     const unsigned short numSeg,
		     const bool b):
    GLVObject(),
    radius(r),
    height(h),
    n(numSeg),
    base(b),
    capTop(0x0),
    capBtm(0x0),
    iCT(0x0),
    iCB(0x0),
    unitCircle(0x0)
  {
    initGLExt();
    if(n<3)
      n=3;
    if(n>n_max)
      {
	//WRL_WARN(__PRETTY_FUNCTION__<<" n > n_max! Setting n = n_max = "<<n_max);
	n=n_max;
      }
    rebuildUnitCircle(n);
  }
  Cylinder::~Cylinder()
  {
    delete[] unitCircle;
  }
  
  void Cylinder::draw()
  {
    if(dirty) rebuildGeometry();
    glInterleavedArrays(GL_N3F_V3F, 0, vertexArray);
    // cylinder
    glDrawRangeElements(GL_QUAD_STRIP, 0, 2*n+1, 2*(n+1), GL_UNSIGNED_SHORT, elementArray);
    // upper cap
    glDrawRangeElements(GL_TRIANGLE_FAN, 3*n+4, 4*n+5, n+2, GL_UNSIGNED_SHORT, iCT);
    // lower cap
    glDrawRangeElements(GL_TRIANGLE_FAN, 2*n+2, 3*n+3, n+2, GL_UNSIGNED_SHORT, iCB);
    
    glDisableClientState( GL_VERTEX_ARRAY );
  }
  
  void Cylinder::draw(const bool side, const bool top, const bool bottom)
  {
    if(dirty) rebuildGeometry();
    glInterleavedArrays(GL_N3F_V3F, 0, vertexArray);
    // cylinder
    if(side)
      glDrawRangeElements(GL_QUAD_STRIP, 0, 2*n+1, 2*(n+1), GL_UNSIGNED_SHORT, elementArray);
    // upper cap
    if(top)
      glDrawRangeElements(GL_TRIANGLE_FAN, 3*n+4, 4*n+5, n+2, GL_UNSIGNED_SHORT, iCT);
    // lower cap
    if(bottom)
      glDrawRangeElements(GL_TRIANGLE_FAN, 2*n+2, 3*n+3, n+2, GL_UNSIGNED_SHORT, iCB);
    
    glDisableClientState( GL_VERTEX_ARRAY );
  }
  
  void Cylinder::drawIsoLines(const bool top, const bool btm, const bool side)
  {
    if(dirty) rebuildGeometry();
    glPushAttrib(GL_CURRENT_BIT | GL_ENABLE_BIT);
    glDisable(GL_LIGHTING);
    glEnableClientState(GL_VERTEX_ARRAY);
    glColor3f(0,0,0);
    if(top)
      {
	glVertexPointer(3, GL_FLOAT, 6*sizeof(GLfloat), &(capTop[1].v[0]));
	glDrawArrays(GL_LINE_STRIP, 0, n+1);
      }
    if(btm)
      {
 	glVertexPointer(3, GL_FLOAT, 6*sizeof(GLfloat), &(capBtm[1].v[0]));
  	glDrawArrays(GL_LINE_STRIP, 0, n+1);
      }
    if(side)
      {
	glBegin(GL_LINES);
	glVertex3fv(&(vertexArray[0].v[0]));
	glVertex3fv(&(vertexArray[1].v[0]));
	glVertex3fv(&(vertexArray[n].v[0]));
	glVertex3fv(&(vertexArray[n+1].v[0]));
	glEnd();
      }
    glDisableClientState(GL_VERTEX_ARRAY);
    glPopAttrib();
  }
  
  GLfloat * buildUnitCircle(GLfloat *data, const GLushort n)
  {
    delete[] data;
    data=new GLfloat[2*(n+1)];
    GLfloat *d=data;
    double a=0.0;
    double angleStep = 2*M_PI/n;
    for(GLushort i = 0; i<=n; i++)
      {
	a = i*angleStep;
	*d = (GLfloat) cos(a); ++d;
	*d = (GLfloat) sin(a); ++d;
      }
    return data;
  }
  
  void Cylinder::rebuildUnitCircle(const GLushort numSeg)
  {
    if(numSeg<3)
      n=3;
    else if(numSeg>n_max)
      {
	//WRL_WARN(__PRETTY_FUNCTION__<<" n > n_max! Setting n = n_max = "<<n_max);
	n=n_max;
      }
    else
      n=numSeg;
    
#if 1
    unitCircle=buildUnitCircle(unitCircle, n);
#else
    delete[] unitCircle;
    unitCircle = new GLfloat[2*(n+1)];
    GLfloat *c=unitCircle;
    double a;
    double angleStep = 2*M_PI/n;
    
    for(GLushort i = 0; i<=n; i++)
      {
	a = i * angleStep;
	
	*c = (GLfloat) cos(a); ++c;
	*c = (GLfloat) sin(a); ++c;
      }
#endif
  }
  
  void Cylinder::setHeight(const GLfloat h)
  {
    height=h;
    if(dirty) rebuildGeometry();
    else // everything is ok -> only change the height in the vertex array
      {
	GLfloat ht,hb;
	if(base)
	  {
	    ht = height;
	    hb = 0.0f;
	  }
	else
	  {
	    ht = height*0.5f;
	    hb = -height*0.5f;
	  }
	Vertex *v0 = vertexArray;
	Vertex *v1 = capBtm;
	Vertex *v2 = capTop;
	v1->v[2]=hb; ++v1;
	v2->v[2]=ht; ++v2;
	
	for(GLushort i = 0; i<=n; i++)
	  {
	    v0->v[2]=ht; ++v0;
	    v0->v[2]=hb; ++v0;
	    v1->v[2]=hb; ++v1;
	    v2->v[2]=ht; ++v2;
	  }
      }
  }
  
  // extrudes the circle to a cylinder
  void Cylinder::rebuildGeometry()
  {
    // memory allocation
    numVerts = 4*n+6; // 4*(n+1)+2
    numElements = 4*n+6; // 4*(n+1)+2
    
    // reduce reallocation to a minimum
    if(oldNumVerts != numVerts)
      {
        //qDebug()<<__PRETTY_FUNCTION__<<" allocating vertexArray, size: "<<numVerts*sizeof(Vertex)<<"Byte\n";
	delete[] vertexArray;
	vertexArray = new Vertex[numVerts];
	if(!vertexArray)
          qDebug()<<__PRETTY_FUNCTION__<<" could not allocate enough memory for vertex array!";
	
        //qDebug()<<__PRETTY_FUNCTION__<<" allocating indexArray, size: "<<numElements*sizeof(GLushort)<<"Byte\n";
	delete[] elementArray;
	elementArray = new GLushort[numElements];
	if(!elementArray)
          qDebug()<<__PRETTY_FUNCTION__<<" could not allocate enough memory for element array!";
	
	oldNumVerts = numVerts;
      }
    GLushort offB = 2*n+2;
    GLushort offT = 3*n+4;
    capBtm=&vertexArray[offB];
    capTop=&vertexArray[offT];
    iCB=&elementArray[offB];
    iCT=&elementArray[offT];
    
    // calculations
    Vertex *v0 = vertexArray;
    Vertex *v1 = capBtm;
    Vertex *v2 = capTop;
    GLushort *e0 = elementArray;
    GLushort *e1 = iCB;
    GLushort *e2 = iCT;
    
    GLfloat ht,hb;
    if(base)
      {
	ht = height;
	hb = 0.0f;
      }
    else
      {
	ht = height*0.5f;
	hb = -height*0.5f;
      }
    
    v1->n[0]=0.0f;  v1->n[1]=0.0f;  v1->n[2]=-1.0f;
    v1->v[0]=0.0f;  v1->v[1]=0.0f;  v1->v[2]=hb;
    ++v1;
    *e1++=offB;
    
    v2->n[0]=0.0f;  v2->n[1]=0.0f;  v2->n[2]=1.0f;
    v2->v[0]=0.0f;  v2->v[1]=0.0f;  v2->v[2]=ht;
    ++v2;
    *e2++ = offT;
    
    GLfloat *uc=unitCircle;
    
    GLfloat x,y,xr,yr;
    for(GLushort i = 0; i<=n; i++)
      {
	x=*uc++;
	y=*uc++;
	xr=x*radius;
	yr=y*radius;
	
	v0->n[0]=x;
	v0->n[1]=y;
	v0->n[2]=0.0f;
	v0->v[0]=xr;
	v0->v[1]=yr;
	v0->v[2]=ht;
	++v0;
	
	v0->n[0]=x;
	v0->n[1]=y;
	v0->n[2]=0.0f;
	v0->v[0]=xr;
	v0->v[1]=yr;
	v0->v[2]=hb;
	++v0;
	
	// side
	*e0++=2*i;
	*e0++=2*i+1;
	
	// bottom
	v1->n[0]=0.0f;
	v1->n[1]=0.0f;
	v1->n[2]=-1.0f;
	v1->v[0]=xr;
	v1->v[1]=yr;
	v1->v[2]=hb;
	++v1;
	*e1++=-i+1+n+offB;
	
	// top
	v2->n[0]=0.0f;
	v2->n[1]=0.0f;
	v2->n[2]=1.0f;
	v2->v[0]=xr;
	v2->v[1]=yr;
	v2->v[2]=ht;
	++v2;
	*e2++=i+1+offT;
      }
    
    dirty=false;
    //qDebug()<<__PRETTY_FUNCTION__<<" finished building geometry\n";
    
    // Ausgabe der Datenstruktur
#if 0
    qDebug()<<"numVerts: "<<numVerts<<"\n";
    Vertex *v=vertexArray;
    GLushort *e = elementArray;
    for(unsigned short i=0;i<numVerts;i++, ++v, ++e)
      {
	if(i==offB||i==offT)
          qDebug()<<"==================================================================\n";
        qDebug()<<"\t\t\t\t\t\t\t";
        qDebug()<<"n "<<i<<": ["<<v->n[0]<<", "<<v->n[1]<<", "<<v->n[2]<<"]\r";
        qDebug()<<"\t\t";
        qDebug()<<"| v "<<i<<": ["<<v->v[0]<<", "<<v->v[1]<<", "<<v->v[2]<<"]\r";
        qDebug()<<"e ["<<i<<"]= "<<*e<<"\n";
      }
#endif
  }
  
  
  //========================================
  // C O N E
  //========================================
  Cone::Cone(const GLfloat r, const GLfloat h, const unsigned short numSeg, const bool b):
    GLVObject(),
    radius(r),
    height(h),
    n(numSeg),
    base(b)
  {
    //initGLExt();
    if(n<3)
      n=3;
    if(n>n_max)
      {
	//WRL_WARN(__PRETTY_FUNCTION__<<" n > n_max! Setting n = n_max = "<<n_max);
	n=n_max;
      }
  }
  
  void Cone::draw(const bool side, const bool bottom)
  {
    if(dirty) rebuildGeometry();
    
    glInterleavedArrays(GL_N3F_V3F, 0, vertexArray);
    // cone
    if(side)
      glDrawRangeElements(GL_TRIANGLE_FAN, 0, n+1, n+2, GL_UNSIGNED_SHORT, elementArray);
    // lower cap
    if(bottom)
      glDrawRangeElements(GL_TRIANGLE_FAN, n+2, 2*n+3, n+2, GL_UNSIGNED_SHORT, iC);
    
    glDisableClientState( GL_VERTEX_ARRAY );
  }
  
  void Cone::draw(const GLfloat colorCone[3], const GLfloat colorCap[3])
  {
    if(dirty) rebuildGeometry();
    
    glPushAttrib(GL_CURRENT_BIT);
    glInterleavedArrays(GL_N3F_V3F, 0, vertexArray);
    // cone
    glColor3fv(colorCone);
    glDrawRangeElements(GL_TRIANGLE_FAN, 0, n+1, n+2, GL_UNSIGNED_SHORT, elementArray);
    // lower cap
    glColor3fv(colorCap);
    glDrawRangeElements(GL_TRIANGLE_FAN, n+2, 2*n+3, n+2, GL_UNSIGNED_SHORT, iC);
    
    glDisableClientState( GL_VERTEX_ARRAY );
    glPopAttrib();
  }
  
  void Cone::drawIsoLines(const bool capLines, const bool sideLines)
  {
    if(dirty) rebuildGeometry();
    
    glPushAttrib(GL_CURRENT_BIT | GL_ENABLE_BIT);
    glDisable(GL_LIGHTING);
    glColor3f(0,0,0);
    if(capLines)
      {
	glEnableClientState(GL_VERTEX_ARRAY);
 	glVertexPointer(3, GL_FLOAT, 6*sizeof(GLfloat), &(cap[1].v[0]));
  	glDrawArrays(GL_LINE_STRIP, 0, n+1);
 	glDisableClientState(GL_VERTEX_ARRAY);
      }
    if(sideLines)
      {
	glBegin(GL_LINES);
	glVertex3fv(&(vertexArray[0].v[0]));
	glVertex3fv(&(vertexArray[1].v[0]));
	glVertex3fv(&(vertexArray[0].v[0]));
	glVertex3fv(&(vertexArray[n/2+1].v[0]));
	glEnd();
      }
    glPopAttrib();
  }
  
  
  void Cone::rebuildGeometry()
  {
    // memory allocation
    numVerts = 2*n+4;
    numElements = 2*n+4;
    
    // reduce reallocation to a minimum
    if(oldNumVerts != numVerts)
      {
        //qDebug()<<__PRETTY_FUNCTION__<<" allocating vertexArray, size: "<<numVerts*sizeof(Vertex)<<"Byte\n";
	delete[] vertexArray;
	vertexArray = new Vertex[numVerts];
	if(!vertexArray)
          qDebug()<<__PRETTY_FUNCTION__<<" could not allocate enough memory for vertex array!";
	
        //qDebug()<<__PRETTY_FUNCTION__<<" allocating indexArray, size: "<<numElements*sizeof(GLushort)<<"Byte\n";
	delete[] elementArray;
	elementArray = new GLushort[numElements];
	if(!elementArray)
          qDebug()<<__PRETTY_FUNCTION__<<" could not allocate enough memory for element array!";
      }
    GLushort off = n+2;
    cap = &vertexArray[off];
    iC = &elementArray[off];
    
    // calculations
    double angleStep = 2*M_PI/n;
    GLfloat rn=1/(sqrt(1+(radius*radius)/(height*height)));
    
    Vertex *v0 = vertexArray;
    Vertex *v1 = cap;
    GLushort *e0 = elementArray;
    GLushort *e1 = iC;
    
    GLfloat ht,hb;
    if(base)
      {
	ht = height;
	hb = 0.0f;
      }
    else
      {
	ht = height*0.5f;
	hb = -height*0.5f;
      }
    
    v0->n[0]=v0->n[1]=0.0f;
    v0->n[2]=-1.0f;
    v0->v[0]=v0->v[1]=0.0f;
    v0->v[2]=ht;
    ++v0;
    *e0++=0;
    
    v1->n[0]=v1->n[1]=0.0f;  v1->n[2]=-1.0f;
    v1->v[0]=v1->v[1]=0.0f;  v1->v[2]=hb;
    ++v1;
    *e1++=off;
    
    for(GLushort i = 0; i<=n; i++)
      {
	double a = i * angleStep;
	
	GLfloat x = (GLfloat) cos(a);
	GLfloat xr = x*radius;
	GLfloat xn = x*rn;
	GLfloat y = (GLfloat) sin(a);
	GLfloat yr = y*radius;
	GLfloat yn = y*rn;
	
	// cone normals
	v0->n[0]=xn;
	v0->n[1]=yn;
	v0->n[2]=radius/height*rn;
	v0->v[0]=xr;
	v0->v[1]=yr;
	v0->v[2]=hb;
	++v0;
	*e0++=i+1;
	
	//cap
	v1->v[0]=xr;
	v1->v[1]=yr;
	v1->v[2]=hb;
	v1->n[0]=v1->n[1]=0.0f;
	v1->n[2]=-1.0f;
	++v1;
	*e1++=-i+1+n+off;
      }
    
    dirty=false;
    //qDebug()<<__PRETTY_FUNCTION__<<" finished building geometry\n";
    
    // Ausgabe der Datenstruktur
#if 0
    qDebug()<<"numVerts: "<<numVerts<<"\n";
    Vertex *v=vertexArray;
    for(unsigned short i=0;i<numVerts;i++, ++v)
      {
        qDebug()<<"v "<<i<<": ["<<v->v[0]<<", "<<v->v[1]<<", "<<v->v[2]<<"]\n";
      }
    
    GLushort *e = elementArray;
    for(unsigned short i=0;i<numElements;i++, ++e)
      {
	if(i==off)
          qDebug()<<"========================================\n";
        qDebug()<<"e ["<<i<<"]= "<<*e<<"\n";
      }
#endif
  }
  
  Arrow::Arrow(GLfloat lenght, GLfloat lenghtHead, GLfloat radiusHead, GLfloat radiusShaft, unsigned short numSeg):
    l0(lenght),
    l(lenght),
    scale(1.0f),
    sign(1.0f),
    lH(lenghtHead),
    rH(radiusHead),
    rS(radiusShaft),
    n(numSeg)
  {
    //initGLExt();
    if(n<3) n=3;
    cone = new Cone(rH, lH, n);
    cyl = new Cylinder(rS, l-lH, n);
  }

  void Arrow::setLength(const GLfloat newLen)
  {
    GLfloat len=newLen;
    if(newLen<0)
      {
	len=-newLen;
	sign=-1.0f;
      }
    else
      sign=+1.0f;
    
    if(len < l0)
      {
	scale=sign*len/l0;
	l=l0;
      }
    else
      {
	scale=sign;
	l=len;
      }
    cyl->setHeight(l-lH);
  }
  
  void Arrow::draw()
  {
    glPushMatrix();
    glScalef(scale, sign*scale, scale);
    cyl->draw();
    glTranslatef(0.0f, 0.0f, l-lH);
    cone->draw();
    glPopMatrix();
  }
  
  //========================================
  // N - A R R O W S
  //========================================
  GLushort getNumSegShaft(const GLushort nH, const GLfloat rS, const GLfloat rH)
  { return (GLushort)((nH-3)*rS/rH + 3.5f); }
  
  NArrows::NArrows(GLfloat lenght, GLfloat lenghtHead, GLfloat radiusHead, GLfloat radiusShaft, unsigned short numSeg, unsigned short numHeads):
    l0(lenght),
    l(lenght),
    scale(1.0f),
    sign(1.0f),
    lH(lenghtHead),
    rH(radiusHead),
    rS(radiusShaft),
    numSegHead(numSeg),
    nHeads(numHeads)
  {
    //initGLExt();
    if(numSegHead<3) numSegHead=3;
    numSegShaft = getNumSegShaft(numSegHead,rS,rH);
    
    // factor
    rR=0.9f*rS;
    lC=lH/(nHeads - (nHeads-1)*(rR/rH));
    dC=lC*(1-rR/rH);
    
    cone = new Cone(rH, lC, numSegHead);
    shaft = new Cylinder(rS, l-lH, numSegShaft);
  }
  
  void NArrows::scaleInitialValues(const GLfloat s)
  {
    rS=s*rS;
    rR=0.9f*rS;
    lC=lH/(nHeads - (nHeads-1)*(rR/rH));
    dC=lC*(1-rR/rH);
    
    delete cone;
    delete shaft;
    cone = new Cone(rH, lC, numSegHead);
    shaft = new Cylinder(rS, l-lH, numSegShaft);
  }
  
  //   void NArrows::setNumSeg(const GLushort n)
  //   {
  //     numSegHead=n<3?3:n;
  //     numSegShaft=getNumSegShaft(numSegHead,rS,rH);
  //     cone->setNumSeg()
  //   }
  
  void NArrows::setLength(const GLfloat newLen)
  {
    GLfloat len=newLen;
    if(newLen<0)
      {
	len=-newLen;
	sign=-1.0f;
      }
    else
      sign=+1.0f;
    
    if(len < l0)
      {
	scale=sign*len/l0;
	l=l0;
      }
    else
      {
	scale=sign;
	l=len;
      }
    shaft->setHeight(l-lH);
  }
  
  void NArrows::drawWithLines()
  {
    glPushMatrix();
    glPushAttrib(GL_CURRENT_BIT | GL_ENABLE_BIT | GL_LINE_BIT);
    
    glEnable(GL_POLYGON_OFFSET_FILL);
    glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);
    glPolygonOffset(1,1);
    
    glEnable(GL_CULL_FACE);
    glScalef(scale, sign*scale, scale);
    
    shaft->draw(true,false,true);
    glLineWidth(1.0);
    shaft->drawIsoLines(true,true,false);
    
    glPushMatrix();
    glTranslatef(0.0f, 0.0f, l-lH);
    const GLfloat rs=rR/rH;
    for(GLushort i=0; i<nHeads; i++)
      {
	cone->draw();
	cone->drawIsoLines(true,false);
	glTranslatef(0,0,dC);
	if(i<nHeads-1)
	  {
	    glPushMatrix();
	    glScalef(rs,rs,1.0f);
	    cone->drawIsoLines(true,false);
	    glPopMatrix();
	  }
      }
    glPopMatrix();
    
    glDisable(GL_LIGHTING);
    glColor(GLBlack);
    glPointSize(2);
    glBegin(GL_POINTS);
    glVertex3f(0.0f,0.0f,l);
    glEnd();
    glPopMatrix();
    glPopAttrib();
  }
  
  void NArrows::draw()
  {
    glPushMatrix();
    glPushAttrib(GL_CURRENT_BIT | GL_ENABLE_BIT | GL_LINE_BIT);
    
    glEnable(GL_POLYGON_OFFSET_FILL);
    glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);
    glPolygonOffset(1,1);
    
    glEnable(GL_CULL_FACE);
    glScalef(scale, sign*scale, scale);
    
    shaft->draw(true,false,true);
    //     glLineWidth(1.0);
    //     shaft->drawIsoLines(true,true,false);
    
    //     glPushMatrix();
    glTranslatef(0.0f, 0.0f, l-lH);
    // const GLfloat rs=rR/rH;
    for(GLushort i=0; i<nHeads; i++)
      {
	cone->draw();
	// 	cone->drawIsoLines(true,false);
	glTranslatef(0,0,dC);
	// 	if(i<nHeads-1)
	// 	  {
	// 	    glPushMatrix();
	// 	    glScalef(rs,rs,1.0f);
	// 	    cone->drawIsoLines(true,false);
	// 	    glPopMatrix();
	// 	  }
      }
    //     glPopMatrix();
    
    //     glDisable(GL_LIGHTING);
    //     glColor(GLBlack);
    //     glPointSize(2);
    //     glBegin(GL_POINTS);
    //     glVertex3f(0.0f,0.0f,l);
    //     glEnd();
    glPopMatrix();
    glPopAttrib();
  }
  
  void NArrows::draw(const GLfloat c[3])
  {
    glPushMatrix();
    glPushAttrib(GL_ENABLE_BIT | GL_LINE_BIT);
    
    glEnable(GL_POLYGON_OFFSET_FILL);
    glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);
    glPolygonOffset(1,1);
    
    glEnable(GL_CULL_FACE);
    glScalef(scale, sign*scale, scale);
    
    glColor3fv(&c[0]);
    shaft->draw(true,false,true);
    glLineWidth(1.0);
    shaft->drawIsoLines(true,true,false);
    glTranslatef(0.0f, 0.0f, l-lH);
    const GLfloat f=0.75f;
    const GLfloat c1[3]={f*c[0], f*c[1], f*c[2]};
    for(GLushort i=0; i<nHeads; i++)
      {
	cone->draw(c,c1);
	cone->drawIsoLines(true,false);
	glTranslatef(0,0,dC);
      }
    glPopMatrix();
    glPopAttrib();
  }
  
  void NArrows::drawWithOutlines()
  {
    glPushMatrix();
    glPushAttrib(GL_CURRENT_BIT | GL_ENABLE_BIT | GL_LINE_BIT | GL_POLYGON_BIT);
    
    glEnable(GL_POLYGON_OFFSET_FILL);
    glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);
    glPolygonOffset(1,1);
    
    GLfloat c[4];
    glGetFloatv(GL_CURRENT_COLOR, &c[0]);
    
    glEnable(GL_CULL_FACE);
    glScalef(scale, sign*scale, scale);
    
    shaft->draw(true,false,true);
    glLineWidth(1.0);
    shaft->drawIsoLines(true,true,false);
    
    glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);
    glCullFace(GL_FRONT);
    glDisable(GL_LIGHTING);
    glColor3f(0,0,0);
    glLineWidth(1.2);
    shaft->draw(true,false,true);
    
    glPushMatrix();
    glTranslatef(0.0f, 0.0f, l-lH);
    const GLfloat rs=rR/rH;
    for(GLushort i=0; i<nHeads; i++)
      {
	glCullFace(GL_BACK);
 	glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);
	glColor3fv(c);
	glEnable(GL_LIGHTING);
	cone->draw();
	glLineWidth(1.0);
	cone->drawIsoLines(true,false);
	
	glCullFace(GL_FRONT);
	glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);
	glDisable(GL_LIGHTING);
	glColor3f(0,0,0);
	glLineWidth(1.2);
	cone->draw();
	
	glTranslatef(0,0,dC);
	if(i<nHeads-1)
	  {
	    glPushMatrix();
	    glScalef(rs,rs,1.0f);
	    glLineWidth(1.0);
	    cone->drawIsoLines(true,false);
	    glPopMatrix();
	  }
      }
    glPopMatrix();
    
    glDisable(GL_LIGHTING);
    glColor(GLBlack);
    glPointSize(2);
    glBegin(GL_POINTS);
    glVertex3f(0.0f,0.0f,l);
    glEnd();
    glPopMatrix();
    glPopAttrib();
  }
  
  
  //========================================
  // S P H E R E
  //========================================
  Sphere::Sphere():
    GLVObject(),
    radius(1.0f),
    indices(0x0),
    count(0x0),
    n(0)
  {
    setResolution(16);
  }
  
  Sphere::Sphere(const float r, const unsigned short numSeg):
    GLVObject(),
    radius(r),
    indices(0x0),
    count(0x0),
    n(0)
  {
    setResolution(numSeg);
    
    // if(n<2)
    //   n=2;
    // else if(n > n_max)
    //   {
    // 	WRL_WARN(__PRETTY_FUNCTION__<<" n > n_max! Setting n = n_max = "<<n_max);
    // 	n = n_max;
    //   }
  }
  
  Sphere::~Sphere()
  {
    delete[] indices;
    delete[] count;
  }
  
  void Sphere::draw()
  {
    draw(radius);
  }
  
  void Sphere::draw(const float r)
  {
    if(dirty) rebuildGeometry();
    
    glPushMatrix();
    glScalef(r,r,r);
    glInterleavedArrays(GL_N3F_V3F, 0, vertexArray);

#ifdef WIN32
    GLushort *e=elementArray;
    unsigned short numPerStrip = 2*(n+1);
    //unsigned short numPerStrip = 2*n;
    for (unsigned short i=0; i<2*n; ++i, e+=numPerStrip)
      {
	// qDebug()<<"draw"<<i;
	glDrawElements(GL_TRIANGLE_STRIP, numPerStrip, GL_UNSIGNED_SHORT, e);
	// quads have to be triangulated? => not as efficient => use
	// triangle strips, since it is the same indexing
	// glDrawElements(GL_QUAD_STRIP, numPerStrip, GL_UNSIGNED_SHORT, e);
      }
#else
    glMultiDrawElements(GL_QUAD_STRIP, count, GL_UNSIGNED_SHORT, indices, 2*n);
#endif
    glPopMatrix();
  }
  
  void Sphere::drawMidCircle(const float r)
  {
    if(dirty) rebuildGeometry();
    glPushMatrix();
    // glScalef(r,r,r);
    // mat4f m(0,0,r,0, r,0,0,0, 0,r,0,0, 0,0,0,1);
    mat4f m(0,r,0,0, 0,0,r,0, r,0,0,0, 0,0,0,1);
    glMultMatrixf(m);
    // GLushort *e=elementArray;
    unsigned short numPerStrip = n+1;//2*(n+1);
    glInterleavedArrays(GL_N3F_V3F, 0, vertexArray);
    glDrawArrays(GL_LINE_STRIP, 0, numPerStrip);
    glDrawArrays(GL_LINE_STRIP, n*numPerStrip, numPerStrip);
    // glDrawElements(GL_LINE_STRIP, numPerStrip, GL_UNSIGNED_SHORT, e);
    
    glPopMatrix();
  }
  
  void Sphere::setResolution(const unsigned short newN)
  {
    if(newN==n) return;
    else if(newN > n_max)
      { cerr<<__PRETTY_FUNCTION__<<": new resolution value="<<newN<<" > n_max="<<n_max<<"\n";n=n_max; }
    else if(newN<2)
      {	cerr<<__PRETTY_FUNCTION__<<": new resolution value="<<newN<<" < 2\n"; n=2; }
    else n=newN;
    
    // memory allocation
    int numPerStrip = 2*(n+1);
    numVerts = (2*n+1)*(n+1);
    numElements=(2*n+1) * numPerStrip;
    
    delete[] vertexArray;
    delete[] elementArray;
    delete[] indices;
    delete[] count;
    vertexArray = new Vertex[numVerts];
    elementArray = new GLushort[numElements];
    indices=new const GLvoid*[numPerStrip];
    count=new GLsizei[numPerStrip];
  }
  
  void Sphere::rebuildGeometry()
  {
    // // memory allocation
    // int numPerStrip = 2*(n+1);
    // numVerts = (2*n+1)*(n+1);
    // numElements=(2*n+1) * numPerStrip;
    
    // //qDebug()<<__PRETTY_FUNCTION__<<" allocating vertexArray, size: "<<numVerts*sizeof(Vertex)<<"Bytes\n";
    // delete[] vertexArray;
    // vertexArray = new Vertex[numVerts];
    // if(!vertexArray)
    //   qDebug()<<__PRETTY_FUNCTION__<<" could not allocate enough memory for vertex array!";
    
    // //qDebug()<<__PRETTY_FUNCTION__<<" allocating elementArray, size: "<<numVerts*sizeof(GLuint)<<" Bytes\n";
    // delete[] elementArray;
    // elementArray = new GLushort[numElements];
    // if(!elementArray)
    //   qDebug()<<__PRETTY_FUNCTION__<<" could not allocate enough memory for element array!";
    
    // calculations
    const double angleStep = M_PI/n;
    
    Vertex *v = vertexArray;
    GLushort *e = elementArray;
    const GLvoid **ind=indices;
    GLsizei *cnt=count;
    for(unsigned short i=0; i<=2*n; i++)
      {
	const double a = i * angleStep;
	GLfloat x = (GLfloat) cos(a);
	GLfloat y = (GLfloat) sin(a);
	
	*ind++=e;
	*cnt++=2*(n+1);
	
	for (unsigned int j=0; j<=n; j++) {
	  const double b = j * angleStep;
	  GLfloat c = (GLfloat) sin(b);
	  // aktueller Kleinradius
	  GLfloat r = c;// * radius;
	  // aktuelle höhe
	  GLfloat z = (GLfloat) cos(b);
	  
	  v->n[0] = x*c;
	  v->n[1] = y*c;
	  v->n[2] = z;
	  
	  v->v[0] = x*r;
	  v->v[1] = y*r;
	  v->v[2] = z;//*radius;
	  
	  v++;
	  
	  *e++ = (i+1) * (n+1) + j;
	  *e++ = i * (n+1) + j;
	}
      }
    // print coordinates
#if 0
    v = vertexArray;
    unsigned int k=0;
    qDebug()<<"==================== vertices sphere: ====================\n";
    for(unsigned short i=0; i<=2*n; i++)
      {
	for (unsigned int j=0; j<=n; j++, v++, k++)
	  {
            qDebug()<<k<<" ["<<i<<", "<<j<<"]= {"<<v->v[0]<<", "<<v->v[1]<<", "<<v->v[2]<<"}\n";
	  }
        qDebug()<<"========================================\n";
      }

      qDebug()<<"elementArray=\n";
      e = elementArray;
      k=0;
      for(int i=0;i<=2*n;i++)
	{
	  for(int j=0;j<=n;j++,k++)
	    {
              qDebug()<<"i"<<i<<" j"<<j<<" k"<<k<<": "<<e[0]<<" "<<e[1]<<"\n";
	      e+=2;
	    }
          qDebug()<<"--------------------\n";
	}
      qDebug()<<"==========================\n";

# if 1
    qDebug()<<"indices=\n";
    ind=indices;
    for(int i=0;i<=2*n;i++)
      {
        qDebug()<<*ind++<<", ";
      }
    qDebug()<<"\n--------------------\n";
    
    qDebug()<<"count=\n";
    cnt=count;
    for(int i=0;i<=2*n;i++)
      {
        qDebug()<<*cnt++<<", ";
      }
    qDebug()<<"\n==================================================\n";
    
# endif
#endif
    
    
    dirty=false;
    //qDebug()<<__PRETTY_FUNCTION__<<" finished building geometry\n";
  }
  
  void Sphere::setRadius(const float r)
  {
    radius=r;
    // dirty=true;
  }
  
  //========================================
  // C U B O I D
  //========================================
  Cuboid::Cuboid(const GLfloat x_, const GLfloat y_, const GLfloat z_):
    x(x_),
    y(y_),
    z(z_)
  {
    v[0][0] = v[1][0] = v[2][0] = v[3][0] = -0.5f;
    v[4][0] = v[5][0] = v[6][0] = v[7][0] =  0.5f;
    v[0][1] = v[1][1] = v[4][1] = v[5][1] = -0.5f;
    v[2][1] = v[3][1] = v[6][1] = v[7][1] =  0.5f;
    v[0][2] = v[3][2] = v[4][2] = v[7][2] = -0.5f;
    v[1][2] = v[2][2] = v[5][2] = v[6][2] =  0.5f;
  }
  
  const GLfloat Cuboid::n[6][3] = 
    {
      {-1.0, 0.0, 0.0},
      {0.0, 1.0, 0.0},
      {1.0, 0.0, 0.0},
      {0.0, -1.0, 0.0},
      {0.0, 0.0, 1.0},
      {0.0, 0.0, -1.0}
    };
  const GLint Cuboid::faces[6][4] = 
    {
      {0, 1, 2, 3},
      {3, 2, 6, 7},
      {7, 6, 5, 4},
      {4, 5, 1, 0},
      {5, 6, 2, 1},
      {7, 4, 0, 3}
    };
  
  void Cuboid::draw()
  {
    glPushMatrix();
    glScalef(x,y,z);
    for(GLint i = 5; i >= 0; i--) 
      {
	glBegin(GL_QUADS);
	glNormal3fv(&n[i][0]);
	glVertex3fv(&v[faces[i][0]][0]);
	glVertex3fv(&v[faces[i][1]][0]);
	glVertex3fv(&v[faces[i][2]][0]);
	glVertex3fv(&v[faces[i][3]][0]);
	glEnd();       
      }
    glPopMatrix();
  }
  
  //////////////////////////////////////////////////
  // FRAME
  //////////////////////////////////////////////////
  Frame::Frame(const GLfloat size):
    a(size,
      0.25*size,
      0.125*size,
      0.03125*size,
      10),
    c(size*0.2)
  {
  }
  
  void Frame::draw()
  {


#if 1//normal
    glPushAttrib(GL_CURRENT_BIT);
    glPushMatrix();
    //z-axis
    glColor(GLBlue);
    a.draw();
    //x-axis
    glRotatef(90.0,0.0,1.0,0.0);
    glColor(GLRed);
    a.draw();
    //y-axis
    glRotatef(-90.0,1.0,0.0,0.0);
    glColor(GLGreen);
    a.draw();
    
    //
    glColor(GLBlack);
    c.draw();
    glPopAttrib();
    glPopMatrix();

#endif

#if 0//debug: transparent 
    glPushAttrib(GL_CURRENT_BIT);
    glPushAttrib(GL_POLYGON_BIT | GL_ENABLE_BIT | GL_DEPTH_BUFFER_BIT);
    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
    glPushMatrix();
    //z-axis
    glColor4f(0.0, 0.0,1.0, 0.2);
    a.draw();
    //x-axis
    glRotatef(90.0,0.0,1.0,0.0);
    glColor4f(1.0, 0.0, 0.0, 0.2);
    a.draw();
    //y-axis
    glRotatef(-90.0,1.0,0.0,0.0);
    //glColor(GLGreen);
    glColor4f(0.0, 1.0, 0.0, 0.2);
    a.draw();
    
    //
    glColor4f(0.0,0.0,0.0,0.2);
    c.draw();
    glPopAttrib();
    glPopAttrib();
    glPopMatrix();

#endif
  }
  
}
