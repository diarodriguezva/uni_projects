/*!
  @file gl_objects.hpp

  some commonly used OpenGL drawing objects such as Box, Cylinder,
  Sphere, Swept Sphere Volumes ...

  Copyright (C) 2009 Institute of Applied Mechanics, Technische Universitaet Muenchen.
  Author: Markus Schwienbacher (schwienbacher@amm.mw.tum.de)
*/

#ifndef __GL_OBJECTS_HPP__
#define __GL_OBJECTS_HPP__

#ifndef MACX
#include <GL/gl.h>
#else
#include <OpenGL/gl.h>
#endif
#include <viewer_config.hpp>
#ifndef MACX
#include <malloc.h>
#endif//MACX
#include <climits>
#include <vector>

#include <matvec4f.hpp>

namespace globj
{
  struct Vertex
  {
    GLfloat n[3];
    GLfloat v[3];
  }__attribute__((__packed__));
  
  /*!
    OpenGL object interface class.
    
    only functionality is generating a display list
    using draw() virtual function and calling display list
  */
  class GLObject
  {
  public:
    GLObject();
    virtual ~GLObject();
    //!draw object
    virtual void draw()=0;
    //!generate display list
    void genList();
    //!call displaylist
    void callList();
  private:
    GLuint list;
    bool listBuilt;
  };
  
  ///////////////
  // GLVObject //
  ///////////////
  class GLVObject: public GLObject
  {
  public:
    GLVObject():
      dirty(true),
      numVerts(0),
      oldNumVerts(0),
      numElements(0),
      vertexArray(0x0),
      elementArray(0x0)
    { }
    virtual ~GLVObject()
    {
      delete[] vertexArray;
      delete[] elementArray;
    }
    
  protected:
    bool dirty;
    unsigned int numVerts, oldNumVerts;
    unsigned int numElements;
    Vertex *vertexArray;
    GLushort *elementArray;
  };
  
  //////////////
  // Cylinder //
  //////////////
  class Cylinder: protected GLVObject
  {
  public:
    /*!
     * \brief Constructs a Cylinder that heads into z-direction.
     *
     * \param radius defines the radius
     * \param height defines the total height
     * \param numSeg defines the number of line segments of the base circle (default value: 16)
     * \param base   defines whether the center of the cylinder is the base or the half height (the center of gravity) default: true
     */
    Cylinder(const GLfloat radius, const GLfloat height, const unsigned short numSeg = 16, const bool base = true);
    virtual ~Cylinder();
    
    void setRadius(const GLfloat r){radius=r; dirty=true;}
    void setHeight(const GLfloat h);//{height=h; dirty=true;}
    void setNumSeg(const unsigned short seg){dirty=true; rebuildUnitCircle(seg);}
    void setBase(const bool b){base=b; dirty=true;}
    void draw(const bool side, const bool top, const bool bottom);
    void draw(const bool drawCaps){ draw(true, drawCaps, drawCaps); }
    void draw();
    void drawIsoLines(const bool top=true, const bool btm=true, const bool side=true);
    
  private:
    void rebuildGeometry();
    void rebuildUnitCircle(const GLushort n);
    
    GLfloat radius;
    GLfloat height;
    //! unsigned int max=65535 (=UINT_MAX from climits); see: rebuildGeometry: numVerts=4*n+6 => n_max=(65535-6)/4
    static const unsigned short n_max = 16382;
    //! number of segments
    unsigned short n;
    //! defines whether the origin is in the base (true) or the center (false)
    bool base;
    //! vertex arrays
    Vertex *capTop;
    Vertex *capBtm;
    GLushort *iCT;
    GLushort *iCB;
    //! holds 2d coordinates of the circle with n segments with the radius 1.0
    GLfloat *unitCircle;
  };
  
  ////////////
  //  Cone  //
  ////////////
  /** **************************************************************************
   * draws a cone
   ************************************************************************** */
  class Cone: protected GLVObject
  {
  public:
    /*!
     * \brief Constructs a Cone that heads into z-direction.
     * 
     * \param radius defines the radius of the base
     * \param height defines the total height
     * \param numSeg defines the segmentation of the base circle to lines (default value: 16)
     * \param base   defines whether the center of the cone is the base or the half height (default: true)
     */
    Cone(const GLfloat radius, const GLfloat height, const unsigned short numSeg=16, const bool b=true);
    virtual ~Cone(){}
    
    void draw(){draw(true, true);}
    void draw(const bool, const bool);
    void draw(const GLfloat colorCone[3], const GLfloat colorCap[3]);
    void drawIsoLines(const bool cap = true, const bool side = true);
    void rebuildGeometry();
    
  private:
    GLfloat radius;
    GLfloat height;
    //! unsigned int max=65535 (=UINT_MAX from climits); see: rebuildGeometry: numVerts=2*n+4 => n_max=(65535-4)/2
    static const unsigned short n_max = 32765;
    //! number of circle segments
    unsigned short n;
    //! defines whether the origin is in the base (true) or the center (false)
    bool base;
    Vertex *cap;
    GLushort *iC;
  };
  
  /////////////
  //  Arrow  //
  /////////////
  /** **************************************************************************
   * draws a simpe arrow with one head
   * useful for e.g. force-arrows
   ************************************************************************** */
  class Arrow
  {
  public:
    /**
     * Constructs an arrow that heads into z-direction.
     */
    Arrow(GLfloat lenght, GLfloat lenghtHead, 
	  GLfloat radiusHead, GLfloat radiusShaft, 
	  unsigned short numSeg);
    ~Arrow(){delete cone; delete cyl;}
    void setLength(const GLfloat lenght);
    void draw();
    
  private:
    GLfloat l0,l;
    GLfloat scale;
    GLfloat sign;
    GLfloat lH, rH;
    GLfloat rS;
    GLushort n;
    
    Cone *cone;
    Cylinder *cyl;
  };
  
  /////////////
  // NArrows //
  /////////////
  /** **************************************************************************
   * draws an arrow with multiple heads
   * useful for e.g. torque-arrows
   ************************************************************************** */
  class NArrows
  {
  public:
    // good initial values (scale them appropriately for your needs)
    // NArrows(1.0f, 0.4f, 0.12f, 0.05f, 16, 2);
    /**
     * Constructs an arrow with multiple heads that heads into z-direction.
     */
    NArrows(const GLfloat lenght, const GLfloat lenghtHead,
	    const GLfloat radiusHead, const GLfloat radiusShaft,
	    const unsigned short numSeg = 16, const unsigned short numHeads = 2);
    ~NArrows(){}
    void setLength(const GLfloat lenght);
    void scaleInitialValues(const GLfloat s);
    //     void setNumSeg(const GLushort n);
    void draw();
    //! needs a color with 3-components
    void draw(const GLfloat color[3]);
    void drawWithLines();
    void drawWithOutlines();
    
  private:
    GLfloat l0, l;
    GLfloat scale;
    GLfloat sign;
    GLfloat lH, rH;
    //! length of a single Cone of the n Heads
    GLfloat lC;
    //! distance from one base of a cone to the next
    GLfloat dC;
    //! radius of the Shaft
    GLfloat rS;
    //! radius of the Ring = intersection between two cones
    GLfloat rR;
    GLushort numSegHead,numSegShaft;
    GLushort nHeads;
    
    Cone *cone;
    Cylinder *shaft;
  };
  
  ////////////
  // Sphere //
  ////////////
  /*!
    Sphere object.
   */
  class Sphere: protected GLVObject
  {
  public:
    Sphere();
    Sphere(const float radius, const unsigned short numSeg);
    virtual ~Sphere();
    
    void draw();
    void draw(const float radius);
    void drawMidCircle(const float radius);
    void setRadius(const float radius);
    void setResolution(const unsigned short nSec);
  private:
    void rebuildGeometry();
    float radius;
    //! unsigned short max=65535 (=UINT_MAX from climits); see: rebuildGeometry: numVerts=(2*n+1)*(n+1)
    static const unsigned short n_max = 180;

    //! used for glMultiDrawArrays:
    //! Specifies a pointer to the location where the indices are stored
    const GLvoid **indices;
    //! Points to an array of the elements counts.
    GLsizei *count;

    //! number of segments
    unsigned short n;
  };
  
  ////////////
  // Cuboid //
  ////////////
  /*!
    generic cuboid with different side lengths.
   */
  class Cuboid: public GLObject
  {
  public:
    Cuboid(const GLfloat x_, const GLfloat y_, const GLfloat z_);
    virtual ~Cuboid(){}
    void draw();
    void setSize(const GLfloat x_, const GLfloat y_, const GLfloat z_){x=x_; y=y_; z=z_;}
    
  protected:
    GLfloat x,y,z;
    GLfloat v[8][3];
    static const GLfloat n[6][3];
    static const GLint faces[6][4];
  };
  
  //////////
  // Cube //
  //////////
  /*!
    cube with equal lengths sides
   */
  class Cube: public Cuboid
  {
  public:
    Cube(GLfloat size_):
      Cuboid(size_, size_,size_)
    {}
  };
  
  ///////////
  // Frame //
  ///////////
  /*!
    coordinate frame with x-axis=red, y-axis=green, z-axis=blue
  */
  class Frame: public GLObject
  {
  public:
    //!size= length of axis arrows
    Frame(const GLfloat size=0.1);
    virtual ~Frame(){}
    void draw();
    
  private:
    Arrow a;
    Cube  c;
  };
  
  //////////////////////
  // Extrusion Object //
  //////////////////////
  /**
     Draws the surface generated by extruding a given input curve.
     The input curve is defined as a sequence of vertices arranged on the x-y-plane.
     The extrusion direction is the positive z axis.
  */
  class Extrusion : public GLVObject
  {
  public:
    Extrusion();
    virtual ~Extrusion();
    void draw();
    void draw(const mat4f &m);
    
    // define the section curve with std::vector<vec4f>
    void setInputCurve(const std::vector<vec4f> *secCurveVerts, const std::vector<vec4f> *secVertsNormals = 0x0);
    // define the section curve with c-arrays
    void setInputCurve(const unsigned int numVerts,
		       const vec4f *secCurveVerts,
		       const vec4f *secVertsNormals = 0x0);
    void setLength(const double l);
    void setClosed(const bool b);
    
  private:
    // helper func to update norm_sec_2d after changing sections (called in updateSections())
    void calcSectionNormals2D();
    void calcSectionNormalsEnds();
    // rebuild cache
    void rebuildGeometry();
    // draw cache (update it in case)
    void drawGeometry();
    //! helper function
    int setNSec(const int newNSec);

    void draw2DSection();//const vector<vec4f> &section_curve, const vec4f *normals);
    
    std::vector<vec4f> inputCurve;
    // the normals for the 2d input curve
    vec4f *inputCurveNormals;
    
    int nSec;
    
    double extrusionLength;
    bool closedInpCurve;
    bool sectionNormalsCalculated;
  };
  
  ////////////////////
  // Revolve Object //
  ////////////////////
  /**
    Draws the suface generated by revolving a given input curve.
    The defaults are:
    - the vertices describing the input curve lay on the x-y-plane.
    - the rotation axis is the x axis; the rotation direction is defined in mathematical positive direction.
    The start angle is an initial offset angle.
    The revolve angle defines the whole rotational angle and must stay within the boundaries: 0 <= a <= 2PI
  */
  class Revolve : public GLVObject
  {
  public:
    Revolve();
    Revolve(const int nRevolve);
    virtual ~Revolve();
    void draw();
    void draw(const mat4f &m);
    
    //! define the section curve
    void setInputCurve(const std::vector<vec4f> *secCurveVerts, const std::vector<vec4f> *secVertsNormals = 0x0);
    //! define the section curve with c arrays
    void setInputCurve(const unsigned int numVerts,
		       const vec4f *secCurveVerts,
		       const vec4f *secVertsNormals = 0x0);
    //! define the rotational resolution (default is: 16)
    void setNRevolve(int n);
    //! define the starting angle
    void setStartAngle(const double a);
    //! define the revolve angle
    void setRevolveAngle(const double a);
  private:
    //! helper func to update norm_sec_2d after changing sections (called in updateSections())
    void calcSectionNormals2D();
    //! rebuild cache
    void rebuildGeometry();
    //! draw cache (update it in case)
    void drawGeometry();
    //! internal helper function
    void setNSec(const int newNSec);
    
    //! the input curve as a sequence of vec4f vertices
    std::vector<vec4f> inputCurve;
    //! the normals for the 2d input curve
    vec4f *inputCurveNormals;
    
    //! cached number of vertices in input curve (same as inputCurve.size() )
    int nSec;
    //! rotational segmentation
    int nRevolve;  
    
    //! used for glMultiDrawArrays:
    //! Specifies a pointer to the location where the indices are stored
    const GLvoid **indices;
    //! Points to an array of the elements counts.
    GLsizei *count;

    double startAngle, revolveAngle;
  };
  
//   /////////////
//   // Capsule //
//   /////////////
//   /**
//    * Reprglesentation of a capsule: a cylinder with spherical ends.
//    * Useful for drawing a line swept sphere (keyword: collision object)
//    */
//   class Capsule : protected Revolve
//   {
//   public:
//     /**
//      * definition of the capsule with the start point = (0,0,0); end point = (0,1,0); radius = 1; nRevolve = 32
//      */
//     Capsule();
//     /**
//      * definition of the capsule with a starting point \c v0 , an ending point \c v1 , the radius r
//      *
//      * \param start       defined the cartesian start point 
//      * \param end         defined the cartesian end point 
//      * \param radius      defines the radius
//      * \param resolution  defines the mesh resolution (default: 32) = the rotational
//      *                    segments (the spherical ends are also influenced).
//      *                    The value must be >= 3.
//      */
//     Capsule(const vec4f &start, const vec4f &end, const float radius, const unsigned short resolution = 32);
//     virtual ~Capsule();
//     virtual void draw();
//     void setRadius(const float radius);
//     void setStart(const vec4f &start);
//     void setEnd(const vec4f &end);

//   private:
//     void generateContour();

//     vec4f v0,v1;
//     float r;
//     unsigned short resolution;

//     mat4f transform;
//   };
 
  ////////////////////////////////////
  // Line Swept Sphere Volume - LSS //
  ////////////////////////////////////
  // optimized for a often changing length
  class LSS : public GLObject
  {
  public:
    LSS();
    /**
     * Definition of the LSS with the start point = (0,0,0);
     * end point = (0,1,0); radius = 1; resolution = 8
     */
    LSS(const unsigned short resolution);
    /**
     * Definition of the LSS with a starting point \c v0 , an ending point \c v1 ,
     * the radius \c r and the mesh \c resolution
     *
     * \param start       defines the cartesian start point 
     * \param end         defines the cartesian end point 
     * \param radius      defines the radius
     * \param resolution  defines the mesh resolution (default: 8) = the number of rotational
     *                    segments on a quarter circle (the spherical ends are also influenced).
     *                    The value must be >=1.
     */
    // LSS(const vec4f &start, const vec4f &end, const float radius, const unsigned short resolution = 8);
    // LSS(const unsigned short resolution = 8);
    virtual ~LSS();
    virtual void draw();
    virtual void draw(const float len, const float radius);
    virtual void draw(const mat4f transform, const float len, const float radius);
    void drawMidCircle(const float len, const float radius);
    // void setRadius(const float radius);
    void setResolution(const unsigned int res);
    // sets only the position (no shape change)
    // void setPosition(const vec4f &pos);
    // void setPoints(const vec4f &start, const vec4f &end);
    // void setStart(const vec4f &start);
    // void setEnd(const vec4f &end);
  private:
    // void updateTransform();//const vec4f &start, const vec4f &end);
    void generateContour();

    //! vertices of the circle on the x-y plane (the contour); also used for the normals
    vec4f *v;
    //! according normals (same as v)
//     vec4f *n;
    //! start- and endpoint of the line
    // vec4f v0, v1;
    //! radius
    // float r;
    //! length
    // float l;
    //! mesh resolution
    unsigned short resolution;
    //! the transformation matrix
    // mat4f transform;

    //! the geometry
    Extrusion shaft;
    Revolve taps;
  };

//   ///////////////////////////////////
//   // Rectangle Swept Sphere Volume //
//   ///////////////////////////////////
//   class RSS : public GLObject
//   {
//   public:
//     // default constructor: center = (0,0,0), xDir=(1,0,0), yDir=(0,1,0), xLen=1, yLen=1, radius=1, resolution=16
//     RSS();
//     RSS(const vec4f &center, const vec4f &xDir, const vec4f &yDir, const float xLen, const float yLen, const float radius, const unsigned short resolution = 16);
//     ~RSS();
//     void draw();
//     void draw(const mat4f &m);

//   private:
//     void generateCircleCurve();
//     void buildInternalObjects();

//     mat4f transform;
//     float xLen, yLen, r;
//     unsigned short resolution;

//     std::vector<vec4f> circleCurve;
//     std::vector<vec4f> circleCurveNormals;
// //     vec4f *circleCurveNormals;

//     Extrusion *side;
//     Revolve *edge;
//   };

  ///////////////////////////////////
  // Triangle Swept Sphere Volume //
  ///////////////////////////////////
  class TSS : public GLObject
  {
  public:
    // default constructor: p0 = (0,0,0), p1=(1,0,0), p2=(0,1,0), radius=1, resolution=16
    TSS();
    TSS(const vec4f &p0, const vec4f &p1, const vec4f &p2, const float radius, const unsigned short resolution = 16);
    ~TSS();
    // draw this object
    void draw();
    void draw(const mat4f &m);
    void drawMidCircle();

    void setResolution(const unsigned int resolution);
    void setRadius(const float radius);
    void setPoints(const vec4f &p0, const vec4f &p1, const vec4f &p2);

  private:
    void generateCircleCurve();
    void buildInternalObjects();
    
    vec4f p0,p1,p2;
//     mat4f transform;
    float r;
    unsigned short resolution;

//     std::vector<vec4f> circleCurve;
//     std::vector<vec4f> circleCurveNormals;

    // unit circle, also used for the normals
    vec4f *v;

    Extrusion *edge;
    Revolve *corners;
  };

}

void initGLExt();
#ifdef WIN32
extern "C" void glDrawRangeElements(GLenum mode, GLuint start, GLuint end, GLsizei count, GLenum type, const GLvoid *indices);
extern "C" void glMultiDrawElements(GLenum mode, const GLsizei *count, GLenum type, const GLvoid* *indices, GLsizei primcount);
extern "C" void glSecondaryColor3f(GLfloat r, GLfloat g, GLfloat b);
#endif//WIN32
#endif // __GL_OBJECTS_HPP__
