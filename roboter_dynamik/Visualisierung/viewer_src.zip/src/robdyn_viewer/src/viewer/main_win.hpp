/*
  Copyright (C) Thomas Buschmann, Institute of Applied Mechanics, TU-Muenchen
  All rights reserved.
  Contact: buschmann@amm.mw.tum.de
  
  main window class. 
  
*/

#ifndef __MAIN_WIN_HPP__
#define __MAIN_WIN_HPP__
#include <QtGui>
#include <list>
#include "viewer.hpp"
#include "lightSettings_win.hpp"
#include "ui_main_win.h"

class ViewerOptionsDialog;
class WriteVideoDialog;
class SnapshotDialog;

class MainWin: public QMainWindow, private Ui::MainWin 
{
  Q_OBJECT
  
  public:
  MainWin(QWidget *p,const QString conf="");
  ~MainWin();    
  
signals:
  void newTime(double);
		      
public slots:
  void quit();
  void switchCameraType(bool);
private slots:
  void reloadData(void);
  void getDataDir();
  void playPause(bool);
  void toggleShowLightSettings();
  void onShowViewerOptions();
  void onViewerOptionsChanged();
  void writeVideo();
  void writeSnapshot();
  void snapshotButton();
  void resetToDefaultViewerSettings();
  void viewerInitialized();
  void onNewTimeRange();
signals:
  void newDataDir(QString dir);
  
private:


  LightSettingsDialog *lightSettingsDialog;
  ViewerOptionsDialog* viewerOptionsDialog;
  WriteVideoDialog* writeVideoDialog;
  SnapshotDialog* snapshotDialog;

  //file/data menu
  QMenu *fileMenu;
  //viewer menu
  QMenu *viewerMenu;
  QVBoxLayout *vboxViewer;
  QString dataDir;
  
  QAction *quitAct;
  QAction *reloadDataAct;
  QAction *getDataDirAct;
  QAction *setupLightingAct;
  QAction *setupViewerOptionsAct;
  QAction *saveStillAct;
  QAction *saveVideoAct;
  QAction *switchCameraTypeAct;
  QAction *switchCameraRotationAct;

  void setDataDir(QString s);
  void createActions();
  void createMenus();
  void loadSettings();
  void saveSettings();     
};

#endif //__MAIN_WIN_HPP__
