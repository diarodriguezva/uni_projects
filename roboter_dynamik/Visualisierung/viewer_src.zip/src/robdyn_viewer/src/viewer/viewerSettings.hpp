/*
   Copyright (C) Markus Schwienbacher, Institute of Applied Mechanics, TU-Muenchen
   All rights reserved.
   Contact: schwienbacher@amm.mw.tum.de
*/

#ifndef __VIEWER_SETTINGS_HPP__
#define __VIEWER_SETTINGS_HPP__

struct LightSettings
{
  //! defines the colors of the light
  GLfloat a[4],d[4],s[4];
  //! defines the position of the light
  GLfloat p0[4], p1[4];
  //! defines which lights are on
  GLboolean l0, l1;
};

struct MaterialSettings
{
  //! defines the colors
  GLfloat e[4];
  GLfloat shininess;
};

struct BackgroundSettings
{
  //!defines the colors
  QColor bg;
  bool shaded;
};

struct ViewerSettings
{
  LightSettings ls;
  MaterialSettings ms;
  BackgroundSettings bs;
};

#endif // __VIEWER_SETTINGS_HPP__
