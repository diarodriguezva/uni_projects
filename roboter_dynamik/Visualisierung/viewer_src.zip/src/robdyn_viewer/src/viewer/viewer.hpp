#ifndef __VIEWER_HPP__
#define __VIEWER_HPP__
#include <QGLViewer/qglviewer.h>
#include <QGLViewer/vec.h>
#include <anim_interface.hpp>
#include <viewerSettings.hpp>
#include <QtOpenGL>

#include "selectionHit.hpp"



//!3D widget rendering options
struct ViewerOptions
{
  bool drawAxes;
  bool moveCamera;
  bool drawMultisampled;
  bool drawText2D;
  bool drawCornerAxis;
};

struct VideoOptions
{
  typedef enum{OUTPUT_PNG,OUTPUT_WMV1,OUTPUT_WMV2} OUTPUT_TYPE;
  typedef enum{VGA,SVGA,XGA,DV_PAL,CURRENT} OUTPUT_DIM;
  QString baseName;
  double tStart;
  double tEnd;
  int outputType;//video/png
  int outputDim;
};

class SelectionManager;
class SingleSelectionHit;
class NPendel;
namespace globj{class Cone;}

class Viewer : public QGLViewer
{
  Q_OBJECT

  public:
  Viewer(QWidget *p=0);
  virtual ~Viewer();
  // qglviewer::Vec dist;
  bool animateOld;
  bool shadeBackground;

  void getLightSettings(LightSettings &) const;
  void getMaterialSettings(MaterialSettings &) const;
  void getBackgroundSettings(BackgroundSettings &) const;
  void getViewerSettings(ViewerSettings &) const;

  QDomElement domElement(const QString& name, QDomDocument& document) const;
  void initFromDOMElement(const QDomElement& element);
  double getTMax(){return tMax;};
  double getTMaxMin(){return tMaxMin;}
  double getTMin(){return tMin;}
  SelectionManager *getSelectionManager(){return selectionManager;}

  bool getLoopAnimation();
  bool getCameraBallRotation();

  //!add view etc to wrl file (scene export)
  void addWrl(std::ofstream&out);

protected :
  void drawWithNames();
  void preDraw();
  void draw();
  void postDraw();
  void init();
  void animate();
  QString helpString() const;
  void endSelection(const QPoint& point);

  QString dataDir;
  double tMax;
  //! holds the minimum maximum time of all plugins (usefull when loading while still simulating and not all results are saved to disk)
  double tMaxMin;
  double tMin;

  double now;
  double animSpeed;

public slots:
  void loadData();
  void setDataDir(QString dir);
  inline QString & getDataDir(){return dataDir;}
  void setAnimSpeed(double x);
  void onNewTime(double now_);
  void writeVideo(const VideoOptions &opts);
  //! used for single snapshot
  void snapshot(const QSize sz, const QString name);
  //! used for animation snapshot
  // void snapshot(const QString name);
  void setDefaultLightAndMaterialParameters();
  void setLightSettings(const LightSettings &ls);
  void setMaterialSettings(const MaterialSettings &ms);
  void setBackgroundSettings(const BackgroundSettings &ms);
  void setViewerSettings(const ViewerSettings &ms);

  void setCameraMode(bool);
  void setViewerOptions(const ViewerOptions& opts);
  ViewerOptions &getViewerOptions();
  //!set time from now to now+ one frame
  void stepForward();
  //!set time from now to now- one frame
  void stepBackward();
  void refresh();
  void redraw();
  //! define if the animation should be replayed when at the end or paused/stopped
  void setLoopAnimation(bool loop=true);
  //! define the mouse input mode for viewpoint/camera rotation to the QGLViewer default "ball rotation" or rotation with the z-axis as up-vector
  void setCameraBallRotation(bool ballRotation=true);

  //! selection manager interface
  void handleSelectionChanged(const SingleSelectionHit &selected,
                              const SingleSelectionHit &deselected);

  // //! overload function
  // void setSceneCenter(const qglviewer::Vec &center);

signals:
  void newTime(double now);
  void newTimeRange();
  void objSelected(int);

private:
  ViewerOptions opts;
  void drawShadedBackground();
  void drawCornerAxis();
  void drawCameraSpinningVector();
  //!draw text in 2D over 3D scene
  void drawText2D(QPainter*p);
  //! Light enable parameter
  GLboolean l0, l1;
  //! Light Material parameter
  GLfloat la[4], ld[4], ls[4];
  //! Light Position parameter
  GLfloat lp0[4], lp1[4];
  //! global glMaterial parameter
  GLfloat me[4], mShin;

  QString copyrightText;
  int copyrightTextWidth;

  //! used for stippled rendering
  GLubyte *polyStipple;

  SelectionHit selectionHit;
  SelectionManager *selectionManager;
  //! number of selection hits from last selection.
  unsigned int oldNumHits;
  //!
  unsigned int oldHitIndex;
  //! where selectionHit was started last time.
  QPoint oldSelectionPoint;
  //! define if the
  bool loopAnimation;
  //! Mouse behaviour of viewport/camera rotation (ballRotation <-> z-axis=up-vector)
  bool cameraBallRotation;

  //! to save OpenGL states with n values for the viewer
  const QDomElement vectorDomElement(const float *vec, const unsigned short num, const QString &name, QDomDocument &doc) const;
  void vectorFromDomElement(float *vec, const unsigned short num, const QDomElement &domElement);

  //! used for setting the revolve around point without jumping the view:
  qglviewer::Vec oldRefPos;

  //
  QString timeStr;
  //offscreen rendering
  void renewFBO(const QSize sz);
  QGLFramebufferObject *fbo;
  int renderToFBO;
  int fboX,fboY;
  int oldViewport[4];
  int oldScissorBox[4];
  double pixelAspectRatio;

  void updateTimeRange();

  globj::Cone *cone;

  //
  NPendel *npendel;

};

#endif//__VIEWER_HPP__
