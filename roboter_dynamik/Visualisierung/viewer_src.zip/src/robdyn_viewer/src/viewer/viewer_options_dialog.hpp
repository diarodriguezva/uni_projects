#ifndef __VIEWER_OPTIONS_DIALOG_HPP__
#define __VIEWER_OPTIONS_DIALOG_HPP__


#include <QtGui>
#include <QDialog>
#include <QColorDialog>
#include <ui_viewer_options_dialog.h>
#include <viewer.hpp>


class ViewerOptionsDialog: public QDialog, private Ui::ViewerOptionsDialog
{
  Q_OBJECT
  
  public:

  ViewerOptionsDialog(QWidget *p);
  ~ViewerOptionsDialog();

  const ViewerOptions &getOptions();
  void setOptions(const ViewerOptions &);
private:
  ViewerOptions opts;
  
};

#endif //__VIEWER_OPTIONS_DIALOG_HPP__
