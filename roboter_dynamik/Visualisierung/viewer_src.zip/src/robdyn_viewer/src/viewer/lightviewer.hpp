/*
   Copyright (C) Markus Schwienbacher, Institute of Applied Mechanics, TU-Muenchen
   All rights reserved.
   Contact: schwienbacher@amm.mw.tum.de
*/

#ifndef __LIGHT_VIEWER_HPP__
#define __LIGHT_VIEWER_HPP__

#include <QGLViewer/qglviewer.h>
#include <QGLViewer/manipulatedFrame.h>
#include <QGLViewer/vec.h>
#include <QtGui>
#include <QtCore>

#include "viewerSettings.hpp"
#include "gl_objects.hpp"

//#define USE_TEXTURE

using namespace qglviewer;
using namespace globj;

class LightViewer : public QGLViewer
{
  Q_OBJECT

  struct vertex
  {
#ifdef USE_TEXTURE
    GLfloat t[2];
#endif
    GLfloat n[3];
    GLfloat v[3];
  };

public:
  LightViewer(QWidget *p);
  ~LightViewer();
  
  qglviewer::ManipulatedFrame* getLightFrame(const GLenum l);

  bool shadeBackground;

protected:
  void preDraw();
  void draw();
  void drawWithNames();
  void init();
  void postSelection(const QPoint& point);
  QString helpString() const;

private:
  void drawShadedBackground();

  //! Light enable parameter
  GLboolean l0, l1;
  //! Light Material parameter
  GLfloat la[4], ld[4], ls[4];
  //! Light Position parameter
  GLfloat lp0[4], lp1[4];
  //! global glMaterial parameter
  GLfloat me[4], mShin;

  Arrow *arrow;
  //  Arrow *arrowSelected;
  Sphere *sphere;
  //  Cylinder *cyl;
  //Cone *cone;
  
  qglviewer::ManipulatedFrame *light0, *light1;

  //  void drawLightArrow(const ManipulatedFrame *, const GLenum = GL_LIGHT0, const bool=false);
  //  void drawLightArrow(const ManipulatedFrame *, const bool=false);
  void drawLightArrow(const GLenum = GL_LIGHT0, const bool=false);


public slots:
  void setLightSettings(const LightSettings &);
  void setMaterialSettings(const MaterialSettings &);
  void setBackgroundSettings(const BackgroundSettings &);
  void setViewerSettings(const ViewerSettings &);

  void updateLight0Pos();
  void updateLight1Pos();

signals:
  void lightPosChanged(const GLenum, const Vec&);

};

#endif // __LIGHT_VIEWER_HPP__
