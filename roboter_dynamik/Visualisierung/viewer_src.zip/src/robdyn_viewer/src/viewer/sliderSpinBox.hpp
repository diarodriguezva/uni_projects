/*
  Copyright (C) Markus Schwienbacher, Institute of Applied Mechanics, TU-Muenchen
  All rights reserved.
  Contact: schwienbacher@amm.mw.tum.de
*/

#ifndef __SLIDER_SPINBOX_HPP__
#define __SLIDER_SPINBOX_HPP__

#include <QtGui/QDoubleSpinBox>
#include <QtGui/QHBoxLayout>
#include <QtGui/QSlider>
#include <QtGui/QWidget>
#include <QtGui/QMouseEvent>

class SliderSpinBox: public QWidget
{
  Q_OBJECT
  
  public:
  SliderSpinBox(QWidget *p);
  ~SliderSpinBox();
  
  void setMinimum(const double &);
  void setMaximum(const double &);
  //  void setPrecision(const int){}
  
  //! set the singleStep of the spinBox and the slider accordingly, the parameter \c ticks controls the number of ticks of the slider
  void setSingleStep(const double &step, const int ticks = 50);
  
  //! set the Range of the SpinBox (and the slider accordingly)
  void setRange(const double&, const double&);
  
  //! returns the current value of the DoubleSpinBox
  inline double value(void){return spinBox->value();}
  
  //! access these main-widgets only if absolutely necessary (e.g. for setSingleStep() ...)
  QSlider *slider;
  QDoubleSpinBox *spinBox;
  
signals:
  void valueChanged(double v);
			     
private slots:
  void sliderChanged(int);
  void spinBoxChanged(double);
			     
public slots:
  //! set the value of the SpinBox
  void setValue(const double&);
private:
  void setInternalValues(const double &v);
  double calcRatio();
  void makeConnections();
  QHBoxLayout *hboxLayout;
  //! specifies the ratio between Slider and SpinBox. If spinbox.min = 0 it is defined as: ratio=slider.max/spinBox.max
  double ratio;
  //! specifies the offset between the slider.min (slider.min is always 0!) and spinbox.min
  double offset;
  //! range of the spinBox (spinBox.max - spinBox.min)
  double len;
  
  double old_dv;
  int old_iv;
private slots:
  void test(int);
};


/**
 * custom slider, which overrides the default behaviour from exact positioning
 * of the cursor over the sliderbutton for slider movement to a more useful 
 * "click and drag"-behaviour 
 */
class MySlider : public QSlider
{
  Q_OBJECT
  public:
  MySlider(QWidget * parent = 0);
  ~MySlider();
protected:
  void mousePressEvent(QMouseEvent *ev);
};

#endif //__SLIDERSPINBOX_HPP__
