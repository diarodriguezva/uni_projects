/*
  Copyright (C) Markus Schwienbacher, Institute of Applied Mechanics, TU-Muenchen
  All rights reserved.
  Contact: schwienbacher@amm.mw.tum.de
*/

#include <cmath>
#include <iostream>
#include <QtDebug>
#include <QtGui/QStyleOptionSlider>

#include "sliderSpinBox.hpp"

using namespace std;

SliderSpinBox::SliderSpinBox(QWidget *parent):
  QWidget(parent)
{
  setObjectName(QString::fromUtf8("SliderSpinBox"));
  hboxLayout = new QHBoxLayout(this);
  hboxLayout->setContentsMargins(-1,0,0,0);
  slider = new MySlider(this);
  
//   slider->setPalette(QPalette(Qt::blue));
//   slider->setAutoFillBackground(true);

  slider->setObjectName(QString::fromUtf8("slider"));
  slider->setOrientation(Qt::Horizontal);
  slider->setTickPosition(QSlider::TicksBelow);
  hboxLayout->addWidget(slider);
  
  spinBox = new QDoubleSpinBox(this);
  spinBox->setDecimals(4);
  spinBox->setObjectName(QString::fromUtf8("spinBox"));
  hboxLayout->addWidget(spinBox);
  
  setRange(-5,5);
  old_dv=0;
  old_iv=0;
  makeConnections();
}

SliderSpinBox::~SliderSpinBox()
{
  delete hboxLayout;
  delete slider;
  delete spinBox;
}

void SliderSpinBox::makeConnections()
{
  connect(slider,SIGNAL(valueChanged(int)),
	  this, SLOT(sliderChanged(int)));
  connect(spinBox,SIGNAL(valueChanged(double)),
	  this, SLOT(spinBoxChanged(double)));
  
  //   connect(slider,SIGNAL(actionTriggered(int)),
  // 	  this,SLOT(test(int)));
  
}

void SliderSpinBox::test(int a)
{
  qDebug()<<"actionTriggered! ("<<a<<")\n";
}

double SliderSpinBox::calcRatio()
{
  return (spinBox->maximum()-spinBox->minimum())*std::pow(10.0, spinBox->decimals());
}

void SliderSpinBox::setMinimum(const double &min)
{
  // cout<<__PRETTY_FUNCTION__<<endl;

  spinBox->setMinimum(min);
  ratio = calcRatio();
  
  slider->setRange(0,(int)ratio);
}

void SliderSpinBox::setMaximum(const double &max)
{
  // cout<<__PRETTY_FUNCTION__<<endl;

  spinBox->setMaximum(max);
  ratio = calcRatio();
  
  slider->setRange(0,(int)ratio);
}

void SliderSpinBox::setSingleStep(const double &step, const int ticks)
{
  // cout<<__PRETTY_FUNCTION__<<endl;

  spinBox->setSingleStep(step);
  slider->setSingleStep((int)(ratio*step));
  slider->setTickInterval((int)(ratio/ticks));
}

void SliderSpinBox::setRange(const double &min, const double &max)
{
  // cout<<__PRETTY_FUNCTION__<<endl;

  const int dec=spinBox->decimals();
  len = max-min;
  ratio = len*std::pow(10.0, dec);
  
  spinBox->setRange(min,max);
  spinBox->setSingleStep((max-min)/100);
  
  slider->setRange(0,(int)ratio);
  slider->setTickInterval((int)(ratio/50.0));
  slider->setSingleStep((int)(ratio/50.0));

  // cout<<endl<<__PRETTY_FUNCTION__<<"old_dv="<<old_dv;

  // if(min>old_dv)
  //   old_dv=min;
  // if(max>old_dv)
  //   old_dv=max;

  // cout<<" new old_dv="<<old_dv<<endl;

  // // cout<<__PRETTY_FUNCTION__<<"old_iv="<<old_iv;
  // cout<<"old_iv="<<old_iv;
  // // // calculate new internal values
  // old_iv=((int)((old_dv - spinBox->minimum())*ratio/len));
  // cout<<" new old_iv="<<old_iv;
  // cout<<" old_iv2="<<slider->value()<<endl;
}

// for external signals
void SliderSpinBox::setValue(const double &dv)
{
  // cout<<__PRETTY_FUNCTION__<<endl;
  if(old_dv != dv)
    {
      setInternalValues(dv);
    }
}

void SliderSpinBox::setInternalValues(const double &dv)
{
  spinBox->blockSignals(true);
  slider->blockSignals(true);
  
  spinBox->setValue(dv);
  const int iv=((int)((dv - spinBox->minimum())*ratio/len));
  slider->setValue(iv);

  old_dv=dv;
  old_iv=iv;
  
  spinBox->blockSignals(false);
  slider->blockSignals(false);
}

// to change the spinBox and emit the valueChanged
void SliderSpinBox::sliderChanged(int iv)
{
  //   qDebug()<<"SliderSpinBox::sliderChanged()";
  if(iv!=old_iv)
    {
      double dv= ((double)iv / ratio * len) + spinBox->minimum();
      spinBox->blockSignals(true);
      spinBox->setValue(dv);
      spinBox->blockSignals(false);
      old_dv=dv;
      old_iv=iv;
      
      emit(valueChanged(dv));
    }
}

// to change the slider and emit the valueChanged
void SliderSpinBox::spinBoxChanged(double dv)
{
  if(old_dv!=dv)
    {
      const int iv=((int)((dv - spinBox->minimum())*ratio/len));
      slider->blockSignals(true);
      slider->setValue(iv);
      slider->blockSignals(false);
      old_dv=dv;
      old_iv=iv;
      
      emit(valueChanged(dv));
    }
}



MySlider::MySlider(QWidget * parent):
  QSlider(parent)
{}

MySlider::~MySlider(){}

void MySlider::mousePressEvent(QMouseEvent *ev)
{
  if (ev->button() == Qt::LeftButton)
    {
      ev->accept();

      QStyleOptionSlider opt;
      initStyleOption(&opt);
      const QStyleOptionSlider *slider = qstyleoption_cast<const QStyleOptionSlider *>(&opt);
      const QRect sliderRect = style()->subControlRect(QStyle::CC_Slider, &opt, QStyle::SC_SliderHandle, this);
      const QPoint center = sliderRect.center() - sliderRect.topLeft();
      int available = style()->pixelMetric(QStyle::PM_SliderSpaceAvailable, slider, this);
      const int pos = QStyle::sliderValueFromPosition(minimum(), maximum(), ev->x() - center.x(),available);
      setValue(pos);
    }
  QSlider::mousePressEvent(ev);
}
