#!/bin/bash
num_args=2
E_BADARG=65
E_OK=0

#echo "number of arguments= $#"
if [ $# -ne  $num_args ]
then 
    echo "usage $0 output_name input"
    exit $E_BADARG
fi

# Encode individual images to video
#mencoder mf://video/*.png -mf fps=25 -ovc lavc -lavcopts vcodec=mpeg4:vbitrate=8000 -oac copy -o output.avi
#mencoder mf://video2/*.png -mf fps=25 -ovc lavc -lavcopts vcodec=mpeg4:vbitrate=16000 -oac copy -o output.avi
command="mencoder mf://$2 -mf fps=25 -ovc lavc -lavcopts vcodec=wmv2:vbitrate=16000 -oac copy -o $1"
#echo "command: $command"
$command

exit $E_OK

