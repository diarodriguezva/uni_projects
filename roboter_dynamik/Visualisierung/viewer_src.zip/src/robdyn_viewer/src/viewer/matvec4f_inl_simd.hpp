#ifdef __SSE3__
# include <pmmintrin.h>
#endif
// #ifdef __SSE4_1__
// # include <smmintrin.h>
// #endif

// matvec4f code using the SIMD units (SSE2 needed!)


#define MASK3 (__m128)_mm_set_epi32(0x00000000,0xFFFFFFFF,0xFFFFFFFF,0xFFFFFFFF)
#define MASK2 (__m128)_mm_set_epi32(0x00000000,0x00000000,0xFFFFFFFF,0xFFFFFFFF)

///////////////////////////////////////////////////////////////////////////////
//
//                               M A T R I X
//
///////////////////////////////////////////////////////////////////////////////

// ============================================================================
// Constructors:
// ============================================================================

inline mat4f::mat4f(const mat4f& m) : _L1(m._L1), _L2(m._L2), _L3(m._L3), _L4(m._L4) {}

inline mat4f::mat4f(float m11, float m12, float m13, float m14,
		    float m21, float m22, float m23, float m24,
		    float m31, float m32, float m33, float m34,
		    float m41, float m42, float m43, float m44)
{
  _L1 = _mm_set_ps(m14, m13, m12, m11);
  _L2 = _mm_set_ps(m24, m23, m22, m21);
  _L3 = _mm_set_ps(m34, m33, m32, m31);
  _L4 = _mm_set_ps(m44, m43, m42, m41);
}

inline mat4f::mat4f(const float *arr) 
{
  _L1 = _mm_loadu_ps(arr);
  _L2 = _mm_loadu_ps(arr+4);
  _L3 = _mm_loadu_ps(arr+8);
  _L4 = _mm_loadu_ps(arr+12);
}


inline mat4f::mat4f(const vec4f &l1,
		    const vec4f &l2,
		    const vec4f &l3,
		    const vec4f &l4) :
  _L1(l1),_L2(l2),_L3(l3),_L4(l4)
{}
// ----------------------------------------------------------------------------
//  Func:   mat4f = mat4f
//  Desc:   Matrix assignment.
// ----------------------------------------------------------------------------
inline mat4f& mat4f::operator = (const mat4f& a)
{
  _L1 = a._L1; _L2 = a._L2; _L3 = a._L3; _L4 = a._L4;
  return *this;
}

// ============================================================================
// Accessing elements:
// ============================================================================
inline float& mat4f::operator () (int i, int j) {
  //   assert((0<=i) && (i<=3) && (0<=j) && (j<=3));
  return *(((float *)&m11) + (i<<2)+j);
}
inline vec4f& mat4f::operator () (int i) {
  //   assert((0<=i) && (i<=3));
  return *(((vec4f *)&m11) + i);
}

// ============================================================================
// Assignments
// ============================================================================
inline void mat4f::setL1(const vec4f &l){_L1 = l;}
inline void mat4f::setL2(const vec4f &l){_L2 = l;}
inline void mat4f::setL3(const vec4f &l){_L3 = l;}
inline void mat4f::setL4(const vec4f &l){_L4 = l;}


// ----------------------------------------------------------------------------
//  Func:  MatrixMult
//  Desc:  Matrix multiplication of A and B. Returns [A]*[B].
// ----------------------------------------------------------------------------
inline mat4f MatrixMult(const mat4f& A, const mat4f& B) {
  mat4f res;
  mat4f Bt(Transpose(B));
  vec4f B1(Bt._L1), B2(Bt._L2), B3(Bt._L3), B4(Bt._L4);
  res._L1 = A * B1;
  res._L2 = A * B2;
  res._L3 = A * B3;
  res._L4 = A * B4;
  res.transpose();
  return res;
}

// ============================================================================
// Operators and member functions:
// ============================================================================

// ----------------------------------------------------------------------------
//  Func:  mat4f * mat4f
//  Desc:  Matrix multiplication of A and B. Returns [A]*[B].
// ----------------------------------------------------------------------------
inline mat4f operator * (const mat4f& A, const mat4f& B)
{
  return MatrixMult(A, B);
}

// ----------------------------------------------------------------------------
//  Func:  mat4f + mat4f
//  Desc:  Matrix addition of A and B. Returns [A] + [B].
// ----------------------------------------------------------------------------
// works
inline mat4f operator + (const mat4f &A, const mat4f &B)
{
  mat4f res;
  res._L1 = _mm_add_ps(A._L1, B._L1);
  res._L2 = _mm_add_ps(A._L2, B._L2);
  res._L3 = _mm_add_ps(A._L3, B._L3);
  res._L4 = _mm_add_ps(A._L4, B._L4);
  return res;
}
// ----------------------------------------------------------------------------
//  Func:  mat4f - mat4f
//  Desc:  Matrix subtraction of A and B. Returns [A] - [B].
// ----------------------------------------------------------------------------
// works
inline mat4f operator - (const mat4f &A, const mat4f &B)
{
  mat4f res;
  res._L1 = _mm_sub_ps(A._L1, B._L1);
  res._L2 = _mm_sub_ps(A._L2, B._L2);
  res._L3 = _mm_sub_ps(A._L3, B._L3);
  res._L4 = _mm_sub_ps(A._L4, B._L4);
  return res;
}

// ----------------------------------------------------------------------------
//  Func:  + mat4f
//  Desc:  unary positive Matrix operation. Returns [A].
// ----------------------------------------------------------------------------
// unary +
inline mat4f operator + (const mat4f &A)
{
  return A;
}

// ----------------------------------------------------------------------------
//  Func:  - mat4f
//  Desc:  unary negative Matrix operation. Returns -[A].
// ----------------------------------------------------------------------------
// unary -
inline mat4f operator - (const mat4f &A)
{
  mat4f res;
  // SSE2
  __m128 masksign = (__m128)_mm_set_epi32( 0x80000000, 0x80000000, 0x80000000, 0x80000000 );
  res._L1 = _mm_xor_ps(masksign,A._L1);
  res._L2 = _mm_xor_ps(masksign,A._L2);
  res._L3 = _mm_xor_ps(masksign,A._L3);
  res._L4 = _mm_xor_ps(masksign,A._L4);
  return res;
}

// ----------------------------------------------------------------------------
//  Func:  mat4f * float
//  Desc:  Matrix scale operation. Returns scale*[A].
// ----------------------------------------------------------------------------
// works!
inline mat4f operator * (const mat4f &A, const float scale)
{
  mat4f res;
  const __m128 S = _mm_set1_ps(scale);
  res._L1 = _mm_mul_ps(A._L1, S);
  res._L2 = _mm_mul_ps(A._L2, S);
  res._L3 = _mm_mul_ps(A._L3, S);
  res._L4 = _mm_mul_ps(A._L4, S);
  return res;
}

// ----------------------------------------------------------------------------
//  Func:  float * mat4f
//  Desc:  Matrix scale operation. Returns scale*[A].
// ----------------------------------------------------------------------------
// works!
inline mat4f operator * (const float scale, const mat4f &A)
{
  mat4f res;
  const __m128 S = _mm_set1_ps(scale);
  res._L1=_mm_mul_ps(A._L1, S);
  res._L2=_mm_mul_ps(A._L2, S);
  res._L3=_mm_mul_ps(A._L3, S);
  res._L4=_mm_mul_ps(A._L4, S);
  return res;
}

// ----------------------------------------------------------------------------
//  Func:  this *= mat4f
//  Desc:  Matrix pre multiplication (for transformation to upper).
//         Returns [this] = [B]*[this].
// ----------------------------------------------------------------------------
// works!
inline mat4f& mat4f::operator *= (const mat4f &B)
{
  // make a transposed copy of this
  mat4f A( Transpose(*this) );
  vec4f B1(B._L1), B2(B._L2), B3(B._L3), B4(B._L4);
  _L1 = A * B1;
  _L2 = A * B2;
  _L3 = A * B3;
  _L4 = A * B4;
  return *this;
}

// ----------------------------------------------------------------------------
//  Func:  this *= float
//  Desc:  Matrix scale operation. Returns [this] * scale.
// ----------------------------------------------------------------------------
inline mat4f& mat4f::operator *= (const float scale)
{
  const __m128 S = _mm_set1_ps(scale);
  _L1 = _mm_mul_ps(_L1,S);
  _L2 = _mm_mul_ps(_L2,S);
  _L3 = _mm_mul_ps(_L3,S);
  _L4 = _mm_mul_ps(_L4,S);
  return *this;
}

// ----------------------------------------------------------------------------
//  Func:  this += float
//  Desc:  Matrix addition operation. Returns [this] + [B].
// ----------------------------------------------------------------------------
inline mat4f& mat4f::operator += (const mat4f &B)
{
  _L1 = _mm_add_ps(_L1, B._L1);
  _L2 = _mm_add_ps(_L2, B._L2);
  _L3 = _mm_add_ps(_L3, B._L3);
  _L4 = _mm_add_ps(_L4, B._L4);
  return *this;
}

// ----------------------------------------------------------------------------
//  Func:  this -= float
//  Desc:  Matrix subtraction operation. Returns [this] + [B].
// ----------------------------------------------------------------------------
inline mat4f& mat4f::operator -= (const mat4f &B)
{
  _L1 = _mm_sub_ps(_L1, B._L1);
  _L2 = _mm_sub_ps(_L2, B._L1);
  _L3 = _mm_sub_ps(_L3, B._L1);
  _L4 = _mm_sub_ps(_L4, B._L1);
  return *this;
}

// ----------------------------------------------------------------------------
//  Func:  transpose                            T
//  Desc:  transpose this Matrix. Returns [this]
// ----------------------------------------------------------------------------
inline void mat4f::transpose()
{
#if 1 // definitiv schneller (Faktor 2 ?)
  const __m128 xmm0 = _mm_unpacklo_ps(_L1,_L2);
  const __m128 xmm1 = _mm_unpacklo_ps(_L3,_L4);
  const __m128 xmm2 = _mm_unpackhi_ps(_L1,_L2);
  const __m128 xmm3 = _mm_unpackhi_ps(_L3,_L4);
#else
  // unpack_lo alternative
  __m128 xmm0 = _mm_shuffle_ps(_L2, _L2, 0x40);
  xmm0 = _mm_shuffle_ps(_L1, xmm0, 0xE4);
  xmm0 = _mm_shuffle_ps(xmm0,xmm0, 0xD8);

  __m128 xmm1 = _mm_shuffle_ps(_L4, _L4, 0x40);
  xmm1 = _mm_shuffle_ps(_L3, xmm1, 0xE4);
  xmm1 = _mm_shuffle_ps(xmm1,xmm1, 0xD8);

  // unpack_hi alternative
  __m128 xmm2 = _mm_shuffle_ps(_L2, _L2, 0x0E);
  xmm2 = _mm_shuffle_ps(xmm2, _L1,  0xE4);
  xmm2 = _mm_shuffle_ps(xmm2, xmm2, 0x72);

  __m128 xmm3 = _mm_shuffle_ps(_L2, _L2, 0x0E);
  xmm3 = _mm_shuffle_ps(xmm3, _L1,  0xE4);
  xmm3 = _mm_shuffle_ps(xmm3, xmm3, 0x72);

#endif
  _L1 = _mm_movelh_ps(xmm0,xmm1);
  _L2 = _mm_movehl_ps(xmm1,xmm0);
  _L3 = _mm_movelh_ps(xmm2,xmm3);
  _L4 = _mm_movehl_ps(xmm3,xmm2);
}

// ----------------------------------------------------------------------------
//  Func:  transpose                            T
//  Desc:  transpose this Matrix. Returns [this]
// ----------------------------------------------------------------------------
inline mat4f& mat4f::translate(const vec4f &p)
{
  m14=p.x;  m24=p.y;  m34=p.z;
  return *this;
}

// // ----------------------------------------------------------------------------
// //  Func:  determinant
// //  Desc:  Returns the matrix determinant. float = det[this].
// // ----------------------------------------------------------------------------
// float mat4f::determinant() {
//     __m128 Va,Vb,Vc;
//     __m128 r1,r2,r3,t1,t2,sum;
//     vec4f Det;
// #if 0//ori (ror not implemented in )
//     // First, Let's calculate the first four minterms of the first line
//     t1 = _L4; t2 = _mm_ror_ps(_L3,1); 
//     Vc = _mm_mul_ps(t2,_mm_ror_ps(t1,0));                   // V3'·V4
//     Va = _mm_mul_ps(t2,_mm_ror_ps(t1,2));                   // V3'·V4"
//     Vb = _mm_mul_ps(t2,_mm_ror_ps(t1,3));                   // V3'·V4^

//     r1 = _mm_sub_ps(_mm_ror_ps(Va,1),_mm_ror_ps(Vc,2));     // V3"·V4^ - V3^·V4"
//     r2 = _mm_sub_ps(_mm_ror_ps(Vb,2),_mm_ror_ps(Vb,0));     // V3^·V4' - V3'·V4^
//     r3 = _mm_sub_ps(_mm_ror_ps(Va,0),_mm_ror_ps(Vc,1));     // V3'·V4" - V3"·V4'

//     Va = _mm_ror_ps(_L2,1);     sum = _mm_mul_ps(Va,r1);
//     Vb = _mm_ror_ps(Va,1);      sum = _mm_add_ps(sum,_mm_mul_ps(Vb,r2));
//     Vc = _mm_ror_ps(Vb,1);      sum = _mm_add_ps(sum,_mm_mul_ps(Vc,r3));

//     // Now we can calculate the determinant:
//     Det = _mm_mul_ps(sum,_L1);
//     Det = _mm_add_ps(Det,_mm_movehl_ps(Det,Det));
//     Det = _mm_sub_ss(Det,_mm_shuffle_ps(Det,Det,1));
//     return Det[0];
// #endif
// }

// // ----------------------------------------------------------------------------
// //  Func:  determinant
// //  Desc:  Returns the matrix determinant. float = det[this].
// // ----------------------------------------------------------------------------
// inline float mat4f::determinant3() {
//   return 
//     m11*m22*m33 - m12*m21*m33 +
//     m12*m23*m31 - m13*m22*m31 + 
//     m13*m21*m32 - m11*m23*m32;
// }

// ============================================================================
// Stand alone constructors:
// ============================================================================

// ----------------------------------------------------------------------------
//  Func:  Transpose                                   T
//  Desc:  construct the transposed Matrix. Returns [A]
// ----------------------------------------------------------------------------
inline mat4f Transpose(const mat4f &A)
{
  mat4f res(A);
  res.transpose();
  return res;
}

// ----------------------------------------------------------------------------
//  Func:  IdentityMatrix
//  Desc:  constructs an identity Matrix. All elements are zero, the trace
//         elements are set to 1. Returns [I]
// ----------------------------------------------------------------------------
inline mat4f IdentityMatrix()
{
    mat4f res;
    res._L1 = _mm_set_ps(0.0f, 0.0f, 0.0f, 1.0f);
    res._L2 = _mm_set_ps(0.0f, 0.0f, 1.0f, 0.0f);
    res._L3 = _mm_set_ps(0.0f, 1.0f, 0.0f, 0.0f);
    res._L4 = _mm_set_ps(1.0f, 0.0f, 0.0f, 0.0f);
    return res;
}

///////////////////////////////////////////////////////////////////////////////
//
//                               V E C T O R
//
///////////////////////////////////////////////////////////////////////////////

// ============================================================================
// Constructors:
// ============================================================================

inline vec4f::vec4f(const vec4f& v) : vec(v.vec) {}
inline vec4f::vec4f(const float x, const float y, const float z, const float w) : vec(_mm_set_ps(w, z, y, x)) {}
inline vec4f::vec4f(const float *arr) : vec(_mm_loadu_ps(arr)) {}

inline vec4f::vec4f(const float f) { vec = _mm_set1_ps(f); }

// ============================================================================
// Operators and member functions:
// ============================================================================

// ----------------------------------------------------------------------------
//  Func:   vec4f = vec4f
//  Desc:   Vector assignment.
// ----------------------------------------------------------------------------
inline vec4f& vec4f::operator = (const vec4f& a) { vec = a.vec; return *this; }


// ----------------------------------------------------------------------------
//  Func:   MatVecMult
//  Desc:   Vector multiplication with matrix. [r] = [M]*[v].
// ----------------------------------------------------------------------------
//(tested! -> ok)
inline void MatVecMult(const mat4f& Mat, const vec4f& Vec, vec4f& res)
{
#ifdef __SSE3__ // use SSE3's _mm_hadd_ps - much faster (twice as fast)
  // elementwise product
  __m128 xmm0 = _mm_mul_ps(Mat._L1, Vec.vec);
  __m128 xmm1 = _mm_mul_ps(Mat._L2, Vec.vec);
  __m128 xmm2 = _mm_mul_ps(Mat._L3, Vec.vec);
  __m128 xmm3 = _mm_mul_ps(Mat._L4, Vec.vec);
  xmm0 = _mm_hadd_ps(xmm0,xmm1);
  xmm2 = _mm_hadd_ps(xmm2,xmm3);
  res.vec = _mm_hadd_ps(xmm0,xmm2);
#else
  // 1) dot product for every element of the resulting vector
  // 1a) elementwise product
  __m128 xmm0 = _mm_mul_ps(Mat._L1, Vec.vec);
  __m128 xmm1 = _mm_mul_ps(Mat._L2, Vec.vec);
  __m128 xmm2 = _mm_mul_ps(Mat._L3, Vec.vec);
  __m128 xmm3 = _mm_mul_ps(Mat._L4, Vec.vec);
  // 1b) reverse order and add element-wise
  xmm0 = _mm_add_ps(_mm_shuffle_ps(xmm0, xmm0, 0x1B), xmm0);
  xmm1 = _mm_add_ps(_mm_shuffle_ps(xmm1, xmm1, 0x1B), xmm1);
  xmm2 = _mm_add_ps(_mm_shuffle_ps(xmm2, xmm2, 0x1B), xmm2);
  xmm3 = _mm_add_ps(_mm_shuffle_ps(xmm3, xmm3, 0x1B), xmm3);
  // 1c) exchange upper and lower and build the final sum (every element carries the result)
  xmm0 = _mm_add_ps(_mm_shuffle_ps(xmm0, xmm0, 0xB1), xmm0);
  xmm1 = _mm_add_ps(_mm_shuffle_ps(xmm1, xmm1, 0xB1), xmm1);
  xmm2 = _mm_add_ps(_mm_shuffle_ps(xmm2, xmm2, 0xB1), xmm2);
  xmm3 = _mm_add_ps(_mm_shuffle_ps(xmm3, xmm3, 0xB1), xmm3);

  // result: identical performance!
# if 1 // ori with shuffle
  // 2) combine the final vector:
  // 2a) intermix step 1
  xmm0 = _mm_shuffle_ps(xmm0, xmm1, 0xA0); // intermix step 1
  xmm1 = _mm_shuffle_ps(xmm2, xmm3, 0xA0);
  // 2b) intermix step 2
  xmm0 = _mm_shuffle_ps(xmm0, xmm0, 0xCC); // intermix step 2
  xmm1 = _mm_shuffle_ps(xmm1, xmm1, 0xCC);
  // 2c) final intermix step 3 ->result
  res.vec = _mm_shuffle_ps(xmm0,xmm1,0xE4); // intermix step 3
# else // variante mit unpack_lo
  // 2) combine the final vector:
  xmm0 = _mm_unpacklo_ps(xmm0, xmm1);
  xmm1 = _mm_unpackhi_ps(xmm2, xmm3);
  res.vec = _mm_shuffle_ps(xmm0, xmm1, 0xE4);
# endif
#endif
}

// ----------------------------------------------------------------------------
//  Func:   MatVecMult
//  Desc:   Vector multiplication with matrix. Returns [Mat]*[Vec].
// ----------------------------------------------------------------------------
//(tested! -> ok)
inline vec4f MatVecMult(const mat4f& Mat, const vec4f& Vec)
{
#if 1
  vec4f res;
  MatVecMult(Mat,Vec,res);
  return res;
#else

  // take advantage of the SSE 4.1 intrinsic dot product
  // warning! slower (on Core2Duo E4800 [host:bunsen] and gcc4.3.2 not as efficient as SSE alone!!!)

// #ifdef __SSE4_1__
//   __m128 xmm0 = _mm_dp_ps(Mat._L1, Vec.vec, 0xF1);
//   __m128 xmm1 = _mm_dp_ps(Mat._L2, Vec.vec, 0xF2);
//   __m128 xmm2 = _mm_dp_ps(Mat._L3, Vec.vec, 0xF4);
//   __m128 xmm3 = _mm_dp_ps(Mat._L4, Vec.vec, 0xF8);

//   xmm0 = _mm_add_ps(xmm0, xmm1);
//   xmm1 = _mm_add_ps(xmm2, xmm3);

//   const vec4f res( _mm_add_ps(xmm0,xmm1) );
// #else

  // 1) dot product for every element of the resulting vector
  // 1a) elementwise product
  __m128 xmm0 = _mm_mul_ps(Mat._L1, Vec.vec);
  __m128 xmm1 = _mm_mul_ps(Mat._L2, Vec.vec);
  __m128 xmm2 = _mm_mul_ps(Mat._L3, Vec.vec);
  __m128 xmm3 = _mm_mul_ps(Mat._L4, Vec.vec);
  // 1b) reverse order and add element-wise
  xmm0 = _mm_add_ps(_mm_shuffle_ps(xmm0, xmm0, 0x1B), xmm0);
  xmm1 = _mm_add_ps(_mm_shuffle_ps(xmm1, xmm1, 0x1B), xmm1);
  xmm2 = _mm_add_ps(_mm_shuffle_ps(xmm2, xmm2, 0x1B), xmm2);
  xmm3 = _mm_add_ps(_mm_shuffle_ps(xmm3, xmm3, 0x1B), xmm3);
  // 1c) exchange upper and lower and build the final sum (every element carries the result)
  xmm0 = _mm_add_ps(_mm_shuffle_ps(xmm0, xmm0, 0xB1), xmm0);
  xmm1 = _mm_add_ps(_mm_shuffle_ps(xmm1, xmm1, 0xB1), xmm1);
  xmm2 = _mm_add_ps(_mm_shuffle_ps(xmm2, xmm2, 0xB1), xmm2);
  xmm3 = _mm_add_ps(_mm_shuffle_ps(xmm3, xmm3, 0xB1), xmm3);

  // 2) combine the final vector:
  // 2a) intermix step 1
  xmm0 = _mm_shuffle_ps(xmm0, xmm1, 0xA0); // intermix step 1
  xmm1 = _mm_shuffle_ps(xmm2, xmm3, 0xA0);
  // 2b) intermix step 2
  xmm0 = _mm_shuffle_ps(xmm0, xmm0, 0xCC); // intermix step 2
  xmm1 = _mm_shuffle_ps(xmm1, xmm1, 0xCC);
  // 2c) final intermix step 3 ->result
  const vec4f res( _mm_shuffle_ps(xmm0,xmm1,0xE4) ); // intermix step 3

// #endif

  return res;
#endif
}

// ----------------------------------------------------------------------------
//  Func:   MatVecMult3
//  Desc:   Vector multiplication with matrix. [r] = [M]*[v].
// ----------------------------------------------------------------------------
//(not tested! -> ok)
inline void MatVecMult3(const mat4f& Mat, const vec4f& Vec, vec4f& res)
{
  // 1) dot product for every element of the resulting vector
  // 1a) elementwise product
  __m128 v = _mm_and_ps(Vec.vec, MASK3);
  __m128 xmm0 = _mm_mul_ps(Mat._L1, v);
  __m128 xmm1 = _mm_mul_ps(Mat._L2, v);
  __m128 xmm2 = _mm_mul_ps(Mat._L3, v);
#ifdef __SSE3__ // use SSE3's _mm_hadd_ps - twice as fast!
  xmm0 = _mm_hadd_ps(xmm0,xmm1);//!
  xmm1 = _mm_setzero_ps();
  xmm2 = _mm_hadd_ps(xmm2,xmm1);
  res.vec = _mm_hadd_ps(xmm0,xmm2);
#else
  // 1b) reverse order and add element-wise
  xmm0 = _mm_add_ps(_mm_shuffle_ps(xmm0, xmm0, 0x1B), xmm0);
  xmm1 = _mm_add_ps(_mm_shuffle_ps(xmm1, xmm1, 0x1B), xmm1);
  xmm2 = _mm_add_ps(_mm_shuffle_ps(xmm2, xmm2, 0x1B), xmm2);
  // 1c) exchange upper and lower and build the final sum (every element carries the result)
  xmm0 = _mm_add_ps(_mm_shuffle_ps(xmm0, xmm0, 0xB1), xmm0);
  xmm1 = _mm_add_ps(_mm_shuffle_ps(xmm1, xmm1, 0xB1), xmm1);
  xmm2 = _mm_add_ps(_mm_shuffle_ps(xmm2, xmm2, 0xB1), xmm2);

  // result: identical performance!? at least for 
  __m128 xmm3=_mm_setzero_ps();
# if 0 // ori with shuffle
  // 2) combine the final vector:
  // 2a) intermix step 1
  #warning TODO
  xmm0 = _mm_shuffle_ps(xmm0, xmm1, 0xA0); // intermix step 1
  // std::cout<<"xmm0"<<vec4f(xmm0)<<std::endl;
  xmm1 = _mm_shuffle_ps(xmm2, xmm3, 0xA0);
  // std::cout<<"xmm1"<<vec4f(xmm1)<<std::endl;
  // 2b) intermix step 2
  xmm0 = _mm_shuffle_ps(xmm0, xmm0, 0xCC); // intermix step 2
  xmm1 = _mm_shuffle_ps(xmm1, xmm1, 0xCC);
  // 2c) final intermix step 3 ->result
  res.vec = _mm_shuffle_ps(xmm0,xmm1,0xE4); // intermix step 3
# else // variante mit unpack_lo
  // 2) combine the final vector:
  xmm0 = _mm_unpacklo_ps(xmm0, xmm1);
  xmm1 = _mm_unpackhi_ps(xmm2, xmm3);
  res.vec = _mm_shuffle_ps(xmm0, xmm1, 0xE4);
# endif
#endif
}

// ----------------------------------------------------------------------------
//  Func:   MatVecMult2
//  Desc:   Vector multiplication with matrix. [r] = [M]*[v].
// ----------------------------------------------------------------------------
//(tested! -> ok)
inline void MatVecMult2(const mat4f& Mat, const vec4f& Vec, vec4f& res)
{
  // 1) dot product for every element of the resulting vector
  // 1a) elementwise product
  __m128 v = _mm_and_ps(Vec.vec, MASK2);
  __m128 xmm0 = _mm_mul_ps(Mat._L1, v);
  __m128 xmm1 = _mm_mul_ps(Mat._L2, v);
#ifdef __SSE3__i // use SSE3's _mm_hadd_ps - almost identical (but still faster)
  xmm0 = _mm_hadd_ps(xmm0,xmm1);
  res.vec = _mm_and_ps(_mm_hadd_ps(xmm0,xmm0), MASK2);
#else
  // 1b) reverse order and add element-wise (both elements carries the result)
  xmm0 = _mm_add_ps(_mm_shuffle_ps(xmm0, xmm0, 0xA1), xmm0);
  xmm1 = _mm_add_ps(_mm_shuffle_ps(xmm1, xmm1, 0xA1), xmm1);
  // 1c) mix together -> (xmm0.x, 0.0, xmm1.x, 0.0)
  xmm0=_mm_shuffle_ps(xmm0,xmm1,0xCC);
  // 2) combine the final vector:
  res.vec=_mm_shuffle_ps(xmm0,xmm0,0xF8);
#endif
}

// ----------------------------------------------------------------------------
//  Func:   MatVecMult as operator
//  Desc:   Vector multiplication with matrix. Returns [Mat]*[Vec].
// ----------------------------------------------------------------------------
// (tested! -> ok)
inline vec4f operator * (const mat4f &Mat, const vec4f &Vec)
{
  return MatVecMult(Mat, Vec);
}

// Dot Product
// ----------------------------------------------------------------------------
//  Func:   dot4
//  Desc:   Scalar Vector Product. Returns float = [a]*[b].
// ----------------------------------------------------------------------------
inline float dot4(const vec4f &a, const vec4f &b)
{
  // take advantage of the SSE 4.1 intrinsic dot product
  // warning! slower (on Core2Duo E4800 [host:bunsen] and gcc4.3.2 not as efficient as SSE alone!!!)

// #ifdef __SSE4_1__
//   __m128 t=_mm_dp_ps(a,b,0xFF);
// #else
  __m128 xmm0 = _mm_mul_ps(a,b);
#ifdef __SSE3__ // faster
  // __m128 xmm0;
  xmm0 = _mm_hadd_ps(xmm0,xmm0);
  xmm0 = _mm_hadd_ps(xmm0,xmm0);
#else
  xmm0 = _mm_add_ps(_mm_movehl_ps(xmm0,xmm0),xmm0);
  xmm0 = _mm_add_ss(_mm_shuffle_ps(xmm0,xmm0,1), xmm0);
#endif
  return *(float *)&xmm0;
}

// ----------------------------------------------------------------------------
//  Func:   dot3
//  Desc:   Scalar Vector Product which takes only the first three values into
//          account. Returns float = [a]*[b].
// ----------------------------------------------------------------------------
// this function is a little bit slower, then dot4(...)!
inline float dot3(const vec4f &a, const vec4f &b)
{
  // take advantage of the SSE 4.1 intrinsic dot product
  // warning! slower (on Core2Duo E4800 [host:bunsen] and gcc4.3.2 not as efficient as SSE alone!!!)

// #ifdef __SSE4_1__
//   __m128 t=_mm_dp_ps(a,b,0x7F);
// #else
#ifdef __SSE3__ // slightly faster
  __m128 xmm0 = _mm_and_ps(a.vec,MASK3);
  __m128 xmm1 = _mm_and_ps(b.vec,MASK3);
  xmm0 = _mm_mul_ps(xmm0,xmm1);
  xmm0 = _mm_hadd_ps(xmm0,xmm0);
  xmm0 = _mm_hadd_ps(xmm0,xmm0);
#else
  __m128 xmm0 = _mm_mul_ps(a,b);
  xmm0 = _mm_add_ss(_mm_shuffle_ps(xmm0,xmm0,1), _mm_add_ps(_mm_movehl_ps(xmm0,xmm0),xmm0));
#endif
// #endif

  return *(float *)&xmm0;
}

// //(tested! -> ok)
// #warning TODO split dot product in dot3 and dot4
// inline float operator * (const vec4f &A, const vec4f &B)
// {
//   // take advantage of the SSE 4.1 intrinsic dot product
//   // warning! slower (on Core2Duo E4800 [host:bunsen] and gcc4.3.2 not as efficient as SSE alone!!!)
// #ifdef __SSE4_1__
// # if 0
//   // for all 4 components:
//   __m128 t=_mm_dp_ps(A,B,0xFF);
// # else
//   // for 3 components (result in all 4 components)
//   __m128 t=_mm_dp_ps(A,B,0x7F);
// # endif
// #else
//   __m128 r = _mm_mul_ps(A,B);
//   r = _mm_add_ps(_mm_movehl_ps(r,r),r);
//   __m128 t = _mm_add_ss(_mm_shuffle_ps(r,r,1), r);
// #endif
//   return *(float *)&t;
// }

// ----------------------------------------------------------------------------
//  Func:   vec4f % vec4f
//  Desc:   Cross product of two 3D Vectors. Returns [res] = [a]x[b]
// ----------------------------------------------------------------------------
// Cross Product (tested! -> ok)
inline vec4f operator % (const vec4f &a, const vec4f &b)
{
  return cross(a,b);

//   vec4f m1, m2;
//   __m128 xmm0,xmm1;
//   xmm0 = _mm_shuffle_ps(a,a, _MM_SHUFFLE(3,1,0,2));
//   xmm1 = _mm_shuffle_ps(b,b, _MM_SHUFFLE(3,0,2,1));
//   m2 = _mm_mul_ps(xmm0,xmm1);
//   xmm0 = _mm_shuffle_ps(a,a, _MM_SHUFFLE(3,0,2,1));
//   xmm1 = _mm_shuffle_ps(b,b, _MM_SHUFFLE(3,1,0,2));
//   m1 = _mm_mul_ps(xmm0,xmm1);
//   return m1-m2;
}

// inline vec4f  cross (const vec4f &a, const vec4f &b)
// {
// //   vec4f m1, m2;
//   __m128 xmm0,xmm1;
//   __m128 xmm2,xmm3;
//   xmm0 = _mm_shuffle_ps(a,a, _MM_SHUFFLE(3,1,0,2));
//   xmm1 = _mm_shuffle_ps(b,b, _MM_SHUFFLE(3,0,2,1));
// //   m2 = _mm_mul_ps(xmm0,xmm1);
//   xmm2 = _mm_mul_ps(xmm0,xmm1);
//   xmm0 = _mm_shuffle_ps(a,a, _MM_SHUFFLE(3,0,2,1));
//   xmm1 = _mm_shuffle_ps(b,b, _MM_SHUFFLE(3,1,0,2));
// //   m1 = _mm_mul_ps(xmm0,xmm1);
//   xmm3 = _mm_mul_ps(xmm0,xmm1);
// //   return m1-m2;
//   return _mm_sub_ps(xmm3,xmm2);
// }

inline vec4f  cross (const vec4f &a, const vec4f &b)
{
  __m128 xmm0 = _mm_mul_ps(_mm_shuffle_ps(a,a, _MM_SHUFFLE(3,1,0,2)),
			   _mm_shuffle_ps(b,b, _MM_SHUFFLE(3,0,2,1)));
  __m128 xmm1 = _mm_mul_ps(_mm_shuffle_ps(a,a, _MM_SHUFFLE(3,0,2,1)),
			   _mm_shuffle_ps(b,b, _MM_SHUFFLE(3,1,0,2)));
  return _mm_sub_ps(xmm1,xmm0);
}

// ----------------------------------------------------------------------------
//  Func:   vec4f | vec4f
//  Desc:   Vector elements product.
// ----------------------------------------------------------------------------
inline vec4f operator | (const vec4f &A, const vec4f &B)
{
  return _mm_mul_ps(A.vec, B.vec);
}

// ----------------------------------------------------------------------------
//  Func:   scale(vec4f,float)
//  Desc:   Vector scale.
// ----------------------------------------------------------------------------
inline vec4f scale (const vec4f &v, const float s)
{
  return _mm_mul_ps(v.vec, _mm_set1_ps(s));
}

// ----------------------------------------------------------------------------
//  Func:   vec4f * float
//  Desc:   Vector scale.
// ----------------------------------------------------------------------------
inline vec4f operator * (const vec4f &v, const float s)
{
  return _mm_mul_ps(v.vec, _mm_set1_ps(s));
}

// ----------------------------------------------------------------------------
//  Func:   float * vec4f
//  Desc:   Vector scale.
// ----------------------------------------------------------------------------
inline vec4f operator * (const float s, const vec4f &v)
{
  return _mm_mul_ps(v.vec, _mm_set1_ps(s));
}

// ----------------------------------------------------------------------------
//  Func:   +vec4f (unary +)
//  Desc:   Returns v
// ----------------------------------------------------------------------------
inline vec4f operator + (const vec4f &v)
{
  return v;
}

// ----------------------------------------------------------------------------
//  Func:   vec4f + vec4f
//  Desc:   Vector addition. Returns [a] + [b]
// ----------------------------------------------------------------------------
inline vec4f operator + (const vec4f &a, const vec4f &b)
{
  //   return vec4f(_mm_add_ps(a.vec, b.vec)); 
  return _mm_add_ps(a.vec, b.vec);
}

// ----------------------------------------------------------------------------
//  Func:   -vec4f (unary -)
//  Desc:   Returns the negative [v]
// ----------------------------------------------------------------------------
inline vec4f operator - (const vec4f &A)
{
  // SSE2
  __m128 masksign = (__m128)_mm_set_epi32( 0x80000000, 0x80000000, 0x80000000, 0x80000000 );
  return _mm_xor_ps(masksign,A);
}

// ----------------------------------------------------------------------------
//  Func:   vec4f - vec4f
//  Desc:   Vector substraction. Returns [a] - [b]
// ----------------------------------------------------------------------------
inline vec4f operator - (const vec4f &A, const vec4f &B)
{
  return _mm_sub_ps(A.vec, B.vec);
}

// ----------------------------------------------------------------------------
//  Func:   vec4f *= mat4f
//  Desc:   Matrix-Vector-Multiplication. Returns [Mat] * [this]
// ----------------------------------------------------------------------------
inline vec4f& vec4f::operator *= (const mat4f &Mat)
{
  MatVecMult(Mat, *this, *this);
  return *this;
}

// ----------------------------------------------------------------------------
//  Func:   vec4f *= float
//  Desc:   Vector in place scale. Returns [this]*s
// ----------------------------------------------------------------------------
inline vec4f& vec4f::operator *= (const float s)
{
  __m128 t = _mm_set1_ps(s);
  vec = _mm_mul_ps(vec,t);
  return *this;
}

// ----------------------------------------------------------------------------
//  Func:   vec4f |= vec4f
//  Desc:   Vector elements multiplication in place. Returns [this]*[b]
// ----------------------------------------------------------------------------
inline vec4f& vec4f::operator |= (const vec4f &b)
{
  vec = _mm_mul_ps(vec, b.vec);
  return *this;
}

// ----------------------------------------------------------------------------
//  Func:   vec4f += vec4f
//  Desc:   Vector addition in place. Returns [this]+[b]
// ----------------------------------------------------------------------------
inline vec4f& vec4f::operator += (const vec4f &b)
{
  vec = _mm_add_ps(vec, b.vec);
  return *this;
}

// ----------------------------------------------------------------------------
//  Func:   vec4f -= vec4f
//  Desc:   Vector addition in place. Returns [this]-[b]
// ----------------------------------------------------------------------------
inline vec4f& vec4f::operator -= (const vec4f &b)
{
  vec = _mm_sub_ps(vec, b.vec);
  return *this;
}

// ----------------------------------------------------------------------------
//  Func:   float = vec4f.length4()
//  Desc:   Returns the length of this vector in 4d space
// ----------------------------------------------------------------------------
inline float vec4f::length4() const
{
  vec4f r = _mm_mul_ps(vec,vec);
  r = _mm_add_ps(_mm_movehl_ps(r,r),r);
  __m128 t0 = _mm_add_ss(_mm_shuffle_ps(r,r,1), r);
  t0 = _mm_sqrt_ss(t0);
  return *(float *)&t0;
}

// ----------------------------------------------------------------------------
//  Func:   float = length4(vec4f)
//  Desc:   Returns the length of this vector in 4d space
// ----------------------------------------------------------------------------
inline float length4(const vec4f& v)
{
  return v.length4();
}


// ----------------------------------------------------------------------------
//  Func:   float = vec4f.length3()
//  Desc:   Returns the length of this vector in 3d space (only )
// ----------------------------------------------------------------------------
inline float vec4f::length3() const
{
  vec4f r = _mm_and_ps(_mm_mul_ps(vec,vec), MASK3);
  r = _mm_add_ps(_mm_movehl_ps(r,r),r);
  __m128 t0 = _mm_add_ss(_mm_shuffle_ps(r,r,1), r);
  t0 = _mm_sqrt_ss(t0);
  return *(float *)&t0;
}

// ----------------------------------------------------------------------------
//  Func:   float = length3(vec4f)
//  Desc:   Returns the length of this vector in 3d space (only )
// ----------------------------------------------------------------------------
inline float length3(const vec4f &v)
{
  return v.length3();
}

// ----------------------------------------------------------------------------
//  Func:   vec4f.normalize4()
//  Desc:   Normalizes this vector in all 4 dimensions and returns it.
// ----------------------------------------------------------------------------
inline vec4f& vec4f::normalize4()
{
  __m128 t = _mm_mul_ps(vec, vec);
  t = _mm_add_ps(_mm_movehl_ps(t,t),t);
  t = _mm_add_ss(_mm_shuffle_ps(t,t,1), t);
  t = _mm_sqrt_ss(t);
  vec = _mm_div_ps(vec, _mm_shuffle_ps(t,t,0x00));
  return *this;
}

// ----------------------------------------------------------------------------
//  Func:   vec4f = normalize4(vec4f)
//  Desc:   Returns the normalized vector.
// ----------------------------------------------------------------------------
inline vec4f normalize4(const vec4f &v)
{
  vec4f res(v);
  __m128 t = _mm_mul_ps(res.vec, res.vec);
  t = _mm_add_ps(_mm_movehl_ps(t,t),t);
  t = _mm_add_ss(_mm_shuffle_ps(t,t,1), t);
  t = _mm_sqrt_ss(t);
  res.vec = _mm_div_ps(res.vec, _mm_shuffle_ps(t,t,0x00));
  return res;
}

// ----------------------------------------------------------------------------
//  Func:   vec4f.normalize3()
//  Desc:   Normalizes this vector in the first 3 dimensions and returns it.
//          The 4th component (w) is set to zero!
// ----------------------------------------------------------------------------
inline vec4f& vec4f::normalize3()
{
  vec = _mm_and_ps(vec, MASK3);
  __m128 t = _mm_mul_ps(vec, vec);
  t = _mm_add_ps(_mm_movehl_ps(t,t),t);
  t = _mm_add_ss(_mm_shuffle_ps(t,t,1), t);
  t = _mm_sqrt_ss(t);
  vec = _mm_div_ps(vec, _mm_shuffle_ps(t,t,0x00));
  return *this;
}

// ----------------------------------------------------------------------------
//  Func:   vec4f = normalize3(vec4f)
//  Desc:   Returns the normalized vector (only the first 3). The 4th component
//          (w) is set to zero!
// ----------------------------------------------------------------------------
inline vec4f normalize3(const vec4f &v)
{
  vec4f res(v);
  res.vec = _mm_and_ps(res.vec, MASK3);
  __m128 t = _mm_mul_ps(res.vec, res.vec);
  t = _mm_add_ps(_mm_movehl_ps(t,t),t);
  t = _mm_add_ss(_mm_shuffle_ps(t,t,1), t);
  t = _mm_sqrt_ss(t);
  res.vec = _mm_div_ps(res.vec, _mm_shuffle_ps(t,t,0x00));
  return res;
}
