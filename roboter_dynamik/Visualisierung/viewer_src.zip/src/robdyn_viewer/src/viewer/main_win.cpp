#include <iostream>
#include <QtGui>
#include <qlistwidget.h>
#include <QDateTime>

#include "viewer.hpp"
#include "main_win.hpp"
#include "viewer_options_dialog.hpp"
#include "write_video_dialog.hpp"
#include "snapshot_dialog.hpp"


using namespace std;


MainWin::MainWin(QWidget* parent, const QString conf):
  QMainWindow(parent)
{
  setupUi(this);
  
  //foobar timeControl->setEnabled(false);
  
  statusBar()->hide();
  
  lightSettingsDialog = 0x0;
  
  viewerOptionsDialog=new ViewerOptionsDialog(this);
  writeVideoDialog=new WriteVideoDialog(0);
  snapshotDialog=new SnapshotDialog(0);
  
  timeSlider->setRange(0,0);
  timeSlider->spinBox->setSuffix(" s");
  
  
  //setWindowIcon(QIcon(":icons/rc/icon.gif"));

  createActions();
  createMenus();
  
  // viewer
  connect(viewer, SIGNAL(viewerInitialized()),
	  this, SLOT(viewerInitialized()));
  connect(viewer,SIGNAL(newTimeRange()),
	  this,SLOT(onNewTimeRange()));

  show();
  setEnabled(true);
  loopAnimationButton->setChecked(viewer->getLoopAnimation());
  
  //animation play/pause etc.
  connect(playPauseButton, SIGNAL(toggled(bool)),
	  this, SLOT(playPause(bool)));
  connect(stepForwardButton, SIGNAL(clicked()),
	  viewer, SLOT(stepForward()));
  connect(stepBackwardButton, SIGNAL(clicked()),
	  viewer, SLOT(stepBackward()));
  connect(loopAnimationButton, SIGNAL(toggled(bool)),
	  viewer, SLOT(setLoopAnimation(bool)));
  connect(animSpeedSpinBox, SIGNAL(valueChanged(double)),
  	  viewer, SLOT(setAnimSpeed(double)));
  
  //time management
  connect(viewer, SIGNAL(newTime(double)),
    	  timeSlider, SLOT(setValue(double))); 
  
  connect(timeSlider, SIGNAL(valueChanged(double)),
  	  viewer, SLOT(onNewTime(double)));  
  
  connect(viewerOptionsDialog, SIGNAL(accepted()),
	  this, SLOT(onViewerOptionsChanged()));
  
  //video
  connect(writeVideoDialog, SIGNAL(accepted()),
	  this, SLOT(writeVideo()));
  //snapshot
  connect(snapshotDialog, SIGNAL(accepted()),
	  this, SLOT(writeSnapshot()));
  
  loadSettings();
  setDataDir(dataDir);

}

MainWin::~MainWin()
{
  saveSettings();
  
  //actions
  delete quitAct;
  delete reloadDataAct;
  delete getDataDirAct;
  delete setupLightingAct;
  delete setupViewerOptionsAct;
  delete saveStillAct;
  delete saveVideoAct;
  delete switchCameraTypeAct;
  delete switchCameraRotationAct;
  //menus
  delete fileMenu;
  delete viewerMenu;
  //dialogs
  delete viewerOptionsDialog;
  delete lightSettingsDialog;
  delete writeVideoDialog;
  delete snapshotDialog;
}  

void MainWin::loadSettings()
{
  QSettings settings("am2b", "anim");
}

void MainWin::saveSettings()
{
  QSettings settings("am2b", "anim");
}

void MainWin::createActions()
{
  quitAct = new QAction(QIcon(":/icons/rc/app-exit.png"),tr("&Quit"), this);
  quitAct->setShortcut(Qt::CTRL+Qt::Key_Q);
  connect(quitAct, SIGNAL(triggered()), this, SLOT(quit()));
  
  reloadDataAct = new QAction(QIcon(":/icons/rc/reload.png"),tr("&Reload data"), this);
  reloadDataAct->setShortcut(Qt::CTRL+Qt::Key_R);
  connect(reloadDataAct, SIGNAL(triggered()), this, SLOT(reloadData()));
  
  getDataDirAct = new QAction(QIcon(":/icons/rc/data_source.png"),tr("&Set data directory"), this);
  connect(getDataDirAct,SIGNAL(triggered()),
	  this, SLOT(getDataDir()));
  
  
  setupLightingAct=new QAction(tr("Setup &lighting"),this);
  connect(setupLightingAct,SIGNAL(triggered()),
	  this, SLOT(toggleShowLightSettings()));
  
  setupViewerOptionsAct=new QAction(tr("Setup &viewer options"),this);
  connect(setupViewerOptionsAct,SIGNAL(triggered()),
	  viewerOptionsDialog,SLOT(show()));
    
  saveStillAct=new QAction(tr("Export still &Image"),this);
  connect(saveStillAct,SIGNAL(triggered()),
	  this, SLOT(snapshotButton()));
  
  saveVideoAct=new QAction(tr("Export &video"),this);
  connect(saveVideoAct,SIGNAL(triggered()),
	  writeVideoDialog,SLOT(show()));
  

  // camera
  switchCameraTypeAct=new QAction(tr("Perspective Camera"), this);
  switchCameraTypeAct->setCheckable(true);
  // do this in viewerInitialized, after the viewer was initialized:
  // switchCameraTypeAct->setChecked(viewer->camera()->type()==Camera::PERSPECTIVE);
  connect(switchCameraTypeAct, SIGNAL(toggled(bool)),
	  this, SLOT(switchCameraType(bool)));

  switchCameraRotationAct=new QAction(tr("Camera Ball Rotation"), this);
  switchCameraRotationAct->setCheckable(true);
  // do this in viewerInitialized, after the viewer was initialized:
  // switchCameraRotationAct->setChecked(viewer->getCameraBallRotation());
  connect(switchCameraRotationAct, SIGNAL(toggled(bool)),
	  viewer, SLOT(setCameraBallRotation(bool)));
}

void MainWin::createMenus()
{
  fileMenu = menuBar()->addMenu(tr("&File/Data"));
  fileMenu->addAction(reloadDataAct);
  fileMenu->addAction(getDataDirAct);
  fileMenu->addAction(saveStillAct);
  fileMenu->addAction(saveVideoAct);
  fileMenu->addAction(quitAct);
  
  viewerMenu=menuBar()->addMenu(tr("&Viewer"));
  viewerMenu->addAction(setupLightingAct);
  viewerMenu->addAction(setupViewerOptionsAct);
  viewerMenu->addAction(switchCameraTypeAct);
  viewerMenu->addAction(switchCameraRotationAct);
  
}


void MainWin::quit()
{
  int ret = QMessageBox::warning(this, tr("Robot Animation"),
				 tr("Really Quit?"),
				 QMessageBox::Yes | QMessageBox::No);
  switch(ret) 
    {
    case QMessageBox::Yes:
      QApplication::quit();
      break;
    case QMessageBox::No:
      //qDebug()<<"quit aborted\n";
      break;
    default:
      //qDebug()<<"unknown return value from quit message box\n";
      break;
    }
}


void MainWin::onNewTimeRange()
{
  //cout<<"MainWin::onNewTimeRange()"<<endl;
  timeSlider->setRange(viewer->getTMin(), viewer->getTMaxMin());
  timeSlider->spinBox->setSingleStep(0.01);
  timeSlider->slider->setSingleStep(10);
}

void MainWin::reloadData(void)
{
  viewer->loadData();
  viewer->updateGL();
  if(viewer->getTMaxMin() == viewer->getTMin() )
    ;//foobar timeControl->setEnabled(false);
  else
    {
      timeControl->setEnabled(true);
      
      onNewTimeRange();
    }
}

void MainWin::getDataDir()
{
  QFileDialog::Options options = QFileDialog::DontResolveSymlinks | QFileDialog::ShowDirsOnly;
  QString dir;
  dir = QFileDialog::getExistingDirectory(this,
					  tr("get data directory"),
					  dataDir,
					  options);
  if (!dir.isEmpty())
    {
      dataDir=dir;
      viewer->setDataDir(dir);
    }
}


void MainWin::playPause(bool x)
{
  if(viewer->animationIsStarted()!=x)
    viewer->toggleAnimation();
  if(x)
    playPauseButton->setIcon(QIcon(":/icons/rc/media-playback-pause.png"));
  else
    playPauseButton->setIcon(QIcon(":/icons/rc/media-playback-start.png"));
}


void MainWin::viewerInitialized()
{
  disconnect(viewer, SIGNAL(viewerInitialized()),
 	     this, SLOT(viewerInitialized()));
  
  // sync viewer options
  viewerOptionsDialog->setOptions(viewer->getViewerOptions());
  // sync dataDir
  dataDir=viewer->getDataDir();
  // sync switches
  switchCameraTypeAct->setChecked(viewer->camera()->type()==Camera::PERSPECTIVE);
  switchCameraRotationAct->setChecked(viewer->getCameraBallRotation());
}

void MainWin::switchCameraType(bool perspectiveCam)
{
  //   QGLViewer::Type t = viewer->camera()->type();
  //   viewer->camera()->setType(viewer->camera()->type()==Camera::PERSPECTIVE?Camera::ORTHOGRAPHIC:Camera::PERSPECTIVE);
  viewer->camera()->setType(perspectiveCam?Camera::PERSPECTIVE:Camera::ORTHOGRAPHIC);
  viewer->updateGL();
}

void MainWin::toggleShowLightSettings()
{
  if(!lightSettingsDialog)
    {
      qDebug()<<__PRETTY_FUNCTION__<<"first Start of LightSettings";
      ViewerSettings vs;
      viewer->getViewerSettings(vs);
      lightSettingsDialog=new LightSettingsDialog(this, vs);
      
      connect(lightSettingsDialog, SIGNAL(settingsChanged(const LightSettings &)),
	      viewer, SLOT(setLightSettings(const LightSettings &)));
      connect(lightSettingsDialog, SIGNAL(settingsChanged(const MaterialSettings &)),
	      viewer, SLOT(setMaterialSettings(const MaterialSettings &)));
      connect(lightSettingsDialog, SIGNAL(settingsChanged(const BackgroundSettings &)),
	      viewer, SLOT(setBackgroundSettings(const BackgroundSettings &)));
      connect(lightSettingsDialog, SIGNAL(settingsChanged(const ViewerSettings &)),
	      viewer, SLOT(setViewerSettings(const ViewerSettings &)));
      connect(lightSettingsDialog, SIGNAL(requestResetToDefaults()),
	      this, SLOT(resetToDefaultViewerSettings()));
      
      lightSettingsDialog->exec();
    }
  else
    {
      qDebug()<<__PRETTY_FUNCTION__<<"toggle Visibility of LightSettings to: "<<!lightSettingsDialog->isVisible();
      if(lightSettingsDialog->isVisible())
	lightSettingsDialog->accept();
      else
	lightSettingsDialog->exec();
    }
}

void MainWin::setDataDir(QString s)
{
  viewer->setDataDir(s);
}

void MainWin::onShowViewerOptions()
{
  viewerOptionsDialog->setOptions(viewer->getViewerOptions());
  viewerOptionsDialog->show();
}

void MainWin::onViewerOptionsChanged()
{
  qDebug()<<__PRETTY_FUNCTION__;
  viewer->setViewerOptions(viewerOptionsDialog->getOptions());
}

void MainWin::writeVideo()
{
  qDebug()<<__PRETTY_FUNCTION__;
  viewer->writeVideo(writeVideoDialog->getOpts());
}

void MainWin::snapshotButton()
{
  snapshotDialog->setSize(viewer->size());
  snapshotDialog->setWindowSize(viewer->size());
  snapshotDialog->show();
}

void MainWin::writeSnapshot()
{
  viewer->snapshot(snapshotDialog->getSize(),
		   snapshotDialog->getName());
}


void MainWin::resetToDefaultViewerSettings()
{
  viewer->setDefaultLightAndMaterialParameters();
  viewer->updateGL();
  ViewerSettings vs;
  viewer->getViewerSettings(vs);
  lightSettingsDialog->setViewerSettings(vs);
}

