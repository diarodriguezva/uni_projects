#ifndef __MAT_VEC_4FLOATS__HPP__
#define __MAT_VEC_4FLOATS__HPP__

#if defined( USE_SIMD ) && ( __SSE2__ )
//# warning using SIMD units!
# include <xmmintrin.h>
# pragma pack(push,16)
#else
# warning not using SIMD units!
#endif

/**
   define custom new/delete for appropriate mem alignment needet
   by SIMD-units
*/
#if defined(USE_SIMD)&&(__SSE2__)//&&(__QNXNTO__)
# define ALIGNED_NEW_DELETE(__class__)                          \
  void* operator new[](size_t allocSize) {                      \
    return _mm_malloc(allocSize*sizeof(__class__), 16);         \
  }                                                             \
  void operator delete[](void *p){_mm_free(p);}                 \
  void* operator new (size_t allocSize) {                       \
    return _mm_malloc(allocSize*sizeof(__class__), 16);         \
  }                                                             \
  void operator delete(void* p){_mm_free(p);}
#else
# define ALIGNED_NEW_DELETE(__class__)
#endif


class vec4f;
class mat4f;

////////////
// Matrix //
////////////

/**
 * A Matrix with 4x4 floats
 */
class mat4f
{
public:
  union {
#if defined( USE_SIMD ) && ( __SSE2__)
    struct {
      __m128 _L1, _L2, _L3, _L4;
    };
#else
    struct {
      float _L1[4], _L2[4], _L3[4], _L4[4];
    };
    float  m[16];

#endif
    struct {
      float  m11, m12, m13, m14;
      float  m21, m22, m23, m24;
      float  m31, m32, m33, m34;
      float  m41, m42, m43, m44;
    };
  };
  
  // Constructors and convertions:
  
  mat4f() {}
  mat4f(const mat4f& m);
  mat4f(float m11, float m12, float m13, float m14,
	float m21, float m22, float m23, float m24,
	float m31, float m32, float m33, float m34,
	float m41, float m42, float m43, float m44);
  mat4f(const float* arr);
  mat4f(const vec4f &l1, const vec4f &l2, const vec4f &l3, const vec4f &l4);
  
  mat4f& operator = (const mat4f& a);
  
  // Accessing elements:
  float& operator () (int i, int j);
  vec4f& operator () (int i);

  //! new and delete operators for memory aligned allocation
  ALIGNED_NEW_DELETE(mat4f);

  /**
     returns the memory adress.
     convinient for OpenGL e.g.
     \code
     mat4f transform(...);
     glMultMatrixf(transform);
     \endcode
     ( instead of:
     \code
     glMultMatrixf((GLfloat*)&transform.m11);
     \endcode
     )
  */
  operator const float * () const {
    return &m11;
  }
  
  vec4f getQuaternion();
  
  // Operators and member functions:
  friend mat4f operator * (const mat4f&, const mat4f&);
  friend vec4f operator * (const mat4f&, const vec4f&);
  friend mat4f operator + (const mat4f&, const mat4f&);
  friend mat4f operator - (const mat4f&, const mat4f&);
  friend mat4f operator + (const mat4f&);
  friend mat4f operator - (const mat4f&);
  friend mat4f operator * (const mat4f&, const float);
  friend mat4f operator * (const float, const mat4f&);
  
  mat4f& operator *= (const mat4f&);
  mat4f& operator *= (const float);
  mat4f& operator += (const mat4f&);
  mat4f& operator -= (const mat4f&);
  
  // assignments
  void setL1(const vec4f &l);
  void setL2(const vec4f &l);
  void setL3(const vec4f &l);
  void setL4(const vec4f &l);
  
  void    transpose();    // transposes the matrix
  //   float   inverse();      // Inverses the matrix and returns the determinant
  
  //   float   determinant();  // Returns the determinant
  float   determinant3() const  // Returns the determinant
  {
    return 
      m11*m22*m33 - m12*m21*m33 +
      m12*m23*m31 - m13*m22*m31 + 
      m13*m21*m32 - m11*m23*m32;
  }
  //   float   minValue();     // Returns the minimum absolute value of the matrix
  //   float   maxValue();     // Returns the maximum absolute value of the matrix
  
  mat4f &translate(float x, float y, float z){m14=x; m24=y; m34=z; return *this;}
  mat4f &translate(float *p){m14=p[0]; m24=p[1]; m34=p[2]; return *this;}
  mat4f &translate(const vec4f &p);
  
#if defined(_INC_IOSTREAM) || defined(_IOSTREAM_H_) || defined(_GLIBCXX_IOSTREAM)
  /* Output */
  friend std::ostream & operator<<(std::ostream & os, const mat4f &a) 
  {
    /* To use: cout << "Elements of vec4f are: " << vec; */ 
#if defined( USE_SIMD ) && ( __SSE2__)
    float *fp = (float*)&a._L1;
#else
    const float *fp = &a.m11;
#endif
    os<<"{\n";
    os.precision(4);
    os.setf(std::ios::fixed, std::ios::floatfield);
    os.setf(std::ios::right, std::ios::adjustfield);
    //     os<<std::scientific;
    for(int i=0; i<4; ++i)
      {
	os << " { " <<std::showpos<< *fp << ", " << *(fp+1) << ", " << *(fp+2) << ", " << *(fp+3) <<" }\n";
	fp += 4;
      }
    os<<"}\n";
    return os;
  }
#endif
};

// Stand alone constructors:
// mat4f ZeroMatrix();
mat4f IdentityMatrix();
mat4f Transpose(const mat4f &);
// mat4f TranslateMatrix(const float dx, const float dy, const float dz);
// mat4f ScaleMatrix(const float a, const float b, const float c);
// mat4f ScaleMatrix(const float a);
// mat4f RotateXMatrix(const float rads);
// mat4f RotateYMatrix(const float rads);
// mat4f RotateZMatrix(const float rads);


////////////
// Vector //
////////////

/**
 * A Vector with 4 floats
 */

class vec4f
{
public:
  union {
#if defined( USE_SIMD ) && ( __SSE2__)
    struct {
      __m128 vec;
    };
#else
    struct {
      float vec[4];
    };
#endif
    struct {
      float   x, y, z, w;
    };
  };
  
  // Constructors and convertions:
  
  vec4f() {}
  vec4f(const vec4f& v);
  vec4f(const float x, const float y, const float z, const float w=1.0f);
  vec4f(const float *arr);
  vec4f(const float f);
#if defined( USE_SIMD ) && ( __SSE2__)
  vec4f(const __m128 &m) : vec(m) {}
  operator __m128() const { return vec; }
  vec4f& operator = (const __m128 &a) { vec = a; return *this; }
#endif
  
  vec4f& operator = (const vec4f& a);
  //     vec4f& operator = (const vec3f&);
  
  // Accessing elements
  float& operator () (int i) {
    //     assert((0<=i) && (i<=3));
    return *(((float *)&vec) + i);
  }

  //! new and delete operators for memory aligned allocation
  ALIGNED_NEW_DELETE(vec4f);

  /** returns the memory adress.
      
      convinient for OpenGL e.g.
      \code
      vec4f pos;
      glVertex3fv(pos);
      \endcode
      ( instead of:
      \code
      glVertex3fv((GLfloat*)&pos.x);
      \endcode
      )
      
  */
  operator const float * () const {
    return &x;
  }
  
  // Operators and member functions:
  friend vec4f operator * (const vec4f&, const mat4f&);
  //   friend float operator * (const vec4f&, const vec4f&);          // Dot Product
  friend float dot4(const vec4f&, const vec4f&);
  friend float dot3(const vec4f&, const vec4f&);
  friend vec4f cross(const vec4f&, const vec4f&);
  friend vec4f scale (const vec4f&, const float);                // Scale Vector

  friend vec4f operator % (const vec4f&, const vec4f&);          // Cross Product
  friend vec4f operator | (const vec4f&, const vec4f&);          // Elements Product
  friend vec4f operator * (const vec4f&, const float);           // Scale Vector
  friend vec4f operator * (const float, const vec4f&);           // Scale Vector
  friend vec4f operator + (const vec4f&);
  friend vec4f operator + (const vec4f&, const vec4f&);
  friend vec4f operator - (const vec4f&);
  friend vec4f operator - (const vec4f&, const vec4f&);
  //   friend vec4f operator ~ (const vec4f&);                        // Normalize
  
  vec4f& operator *= (const mat4f&);
  vec4f& operator *= (const float);
  vec4f& operator |= (const vec4f&);
  vec4f& operator += (const vec4f&);
  vec4f& operator -= (const vec4f&);
  
  float length4() const;
  float length3() const;
  friend float length4(const vec4f&);
  friend float length3(const vec4f&);
  vec4f& normalize4();
  vec4f& normalize3();
  friend vec4f normalize4(const vec4f&);
  friend vec4f normalize3(const vec4f&);
  
#if defined(_INC_IOSTREAM) || defined(_IOSTREAM_H_) || defined(_GLIBCXX_IOSTREAM)
  /* Output */
  friend std::ostream & operator<<(std::ostream & os, const vec4f &a) 
  {
#if 0 // ori
    /* To use: cout << "Elements of vec4f are: " << vec; */ 
    float *fp = (float*)&a;
    os << "[0]:" << *fp				\
       << " [1]:" << *(fp+1)			\
       << " [2]:" << *(fp+2)			\
       << " [3]:" << *(fp+3);
    return os;
#else
    /* To use: cout << "Elements of vec4f are: " << vec; */ 
    float *fp = (float*)&a;
    os << "{ " << *fp
       << ", " << *(fp+1)
       << ", " << *(fp+2)
       << ", " << *(fp+3)
       <<" }";
    return os;
#endif
  }
  //   /* Output */
  //   friend ostream & operator<<(ostream & os, const F32vec4 &a) 
  //   {
  //     /* To use: cout << "Elements of F32vec4 fvec are: " << fvec; */ 
  //     float *fp = (float*)&a;
  //     os << "[3]:" << *(fp+3) 
  //        << " [2]:" << *(fp+2) 
  //        << " [1]:" << *(fp+1) 
  //        << " [0]:" << *fp;
  //     return os;
  //   }
#endif
  
};

#include <cmath>

inline vec4f mat4f::getQuaternion()
{
  vec4f q;
  
  const float tr = m11 + m22 + m33;
    
    if (tr > 0.0f) { 
      const float S = sqrt(tr+1.0) * 2; // S=4*qw 
      q.x = (m32 - m23) / S;
      q.y = (m12 - m31) / S; 
      q.z = (m21 - m12) / S; 
      q.w = 0.25f * S;
    } else if ((m11 > m22)&(m11 > m33)) { 
      const float S = sqrt(1.0 + m11 - m22 - m33) * 2; // S=4*qx 
      q.x = 0.25 * S;
      q.y = (m12 + m21) / S; 
      q.z = (m13 + m31) / S; 
      q.w = (m31 - m23) / S;
    } else if (m22 > m33) { 
      const float S = sqrt(1.0 + m22 - m11 - m33) * 2; // S=4*qy
      q.x = (m12 + m21) / S; 
      q.y = 0.25 * S;
      q.z = (m23 + m32) / S; 
      q.w = (m13 - m31) / S;
    } else { 
      const float S = sqrt(1.0 + m33 - m11 - m22) * 2; // S=4*qz
      q.x = (m13 + m31) / S;
      q.y = (m23 + m32) / S;
      q.z = 0.25 * S;
      q.w = (m21 - m12) / S;
    }
  return q;
}


#if defined( USE_SIMD ) && ( __SSE2__)
# include "matvec4f_inl_simd.hpp"
# pragma pack(pop) 
#else
# include "matvec4f_inl.hpp"
#endif

#endif //__MAT_VEC_4FLOATS__HPP__
