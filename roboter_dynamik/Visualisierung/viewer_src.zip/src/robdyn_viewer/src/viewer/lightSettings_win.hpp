/*
   Copyright (C) Markus Schwienbacher, Institute of Applied Mechanics, TU-Muenchen
   All rights reserved.
   Contact: schwienbacher@amm.mw.tum.de
*/

#ifndef __LIGHT_SETTINGS_WIN_HPP__
#define __LIGHT_SETTINGS_WIN_HPP__


#include <QtGui>
#include <QDialog>
#include <QColorDialog>
#include "lightviewer.hpp"
#include "viewerSettings.hpp"
#include "ui_lightSettingsDialog.h"

class LightSettingsDialog: public QDialog, private Ui::lightSettingsDialog
{
  Q_OBJECT
  
public:
  LightSettingsDialog(QWidget *p, ViewerSettings &vs);
  ~LightSettingsDialog();
  
  ViewerSettings vs;
  ViewerSettings oldVs;
  
private:
  inline double average(const GLfloat *v){return (v[0]+v[1]+v[2])/3.0;};
  void setupSliders();
  void setSliderValues(const ViewerSettings &);
  void initLightViewer();
  void saveOldStates();
  
signals:
  void settingsChanged(const LightSettings &);
  void settingsChanged(const MaterialSettings &);
  void settingsChanged(const BackgroundSettings &);
  void settingsChanged(const ViewerSettings &);
  
  void requestResetToDefaults();
			       
public slots:
  void setViewerSettings(const ViewerSettings &);
  
  void accept();
  void reject();
  void init();
	     
private slots:
  void setLightPos(const GLenum, const Vec&);
  
  void setLightAmbient(double);
  void setLightDiffuse(double);
  void setLightSpecular(double);
  
  void setMaterialEmission(double);
  void setMaterialShininess(double);
  
  void selectBGColor();
  void setBGShaded(int);
  
  void resetToDefaults();
};

#endif //__LIGHT_SETTINGS_WIN_HPP__
