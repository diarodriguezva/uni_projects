/*
   Copyright (C) Markus Schwienbacher, Institute of Applied Mechanics, TU-Muenchen
   All rights reserved.
   Contact: schwienbacher@amm.mw.tum.de
*/

#include "lightSettings_win.hpp"

LightSettingsDialog::LightSettingsDialog(QWidget *p, ViewerSettings &vs_):
  QDialog(p)
{
  setupUi(this);
  
  this->vs=vs_;
  this->oldVs=vs_;
  //saveOldStates();
  
  setupSliders();
  initLightViewer();
  init();
}

LightSettingsDialog::~LightSettingsDialog(){}

void LightSettingsDialog::initLightViewer()
{
  lightViewerWidget->setViewerSettings(vs);
  lightViewerWidget->updateGL();
  
  colorSelectorButton->setPalette(QPalette(vs.bs.bg));
  colorSelectorButton->setAutoFillBackground(true);
  
  shadedBGCheckBox->setChecked(vs.bs.shaded);
  
  setSliderValues(vs);
}

void LightSettingsDialog::init()
{
  qDebug()<<__PRETTY_FUNCTION__;
  
  // light Settings
  connect(lAmbSlider, SIGNAL(valueChanged(double)),
	  this,SLOT(setLightAmbient(double)));
  connect(lDiffSlider, SIGNAL(valueChanged(double)),
	  this,SLOT(setLightDiffuse(double)));
  connect(lSpecSlider, SIGNAL(valueChanged(double)),
	  this,SLOT(setLightSpecular(double)));
  
  connect(lightViewerWidget,SIGNAL(lightPosChanged(const GLenum, const Vec&)),
	  this,SLOT(setLightPos(const GLenum, const Vec&)));
  
  connect(this, SIGNAL(settingsChanged(const LightSettings &)),
	  lightViewerWidget,SLOT(setLightSettings(const LightSettings &)));
  
  // global material Settings
  connect(mEmisSlider, SIGNAL(valueChanged(double)),
	  this,SLOT(setMaterialEmission(double)));
  connect(mShinSlider, SIGNAL(valueChanged(double)),
	  this,SLOT(setMaterialShininess(double)));
  
  connect(this, SIGNAL(settingsChanged(const MaterialSettings &)),
	  lightViewerWidget,SLOT(setMaterialSettings(const MaterialSettings &)));
  
  connect(colorSelectorButton,SIGNAL(clicked()),
	  this,SLOT(selectBGColor()));
  connect(resetToDefaultsButton,SIGNAL(clicked()),
	  this,SLOT(resetToDefaults()));
  
  connect(shadedBGCheckBox,SIGNAL(stateChanged(int)),
	  this,SLOT(setBGShaded(int)));
  
  setSizeGripEnabled ( false );
}

void LightSettingsDialog::setLightAmbient(double v)
{
  vs.ls.a[0]=v;  vs.ls.a[1]=v;  vs.ls.a[2]=v;
  emit(settingsChanged(vs.ls));
}

void LightSettingsDialog::setLightDiffuse(double v)
{
  vs.ls.d[0]=v;  vs.ls.d[1]=v;  vs.ls.d[2]=v;
  emit(settingsChanged(vs.ls));
}

void LightSettingsDialog::setLightSpecular(double v)
{
  vs.ls.s[0]=v;  vs.ls.s[1]=v;  vs.ls.s[2]=v;
  emit(settingsChanged(vs.ls));
}

void LightSettingsDialog::setLightPos(const GLenum l, const Vec &p)
{
  qDebug()<<__PRETTY_FUNCTION__;
  if(l==GL_LIGHT0)
    {
      vs.ls.p0[0]=p[0]; vs.ls.p0[1]=p[1]; vs.ls.p0[2]=p[2]; 
      emit(settingsChanged(vs.ls));
    }
  else if(l==GL_LIGHT1)
    {
      vs.ls.p1[0]=p[0]; vs.ls.p1[1]=p[1]; vs.ls.p1[2]=p[2]; 
      emit(settingsChanged(vs.ls));
    }
  else
    qDebug()<<__PRETTY_FUNCTION__<<"light not supported!";
}

void LightSettingsDialog::setMaterialEmission(double v)
{
  vs.ms.e[0]=v;  vs.ms.e[1]=v;  vs.ms.e[2]=v; vs.ms.e[3]=1.0f;
  emit(settingsChanged(vs.ms));
}

void LightSettingsDialog::setMaterialShininess(double v)
{
  vs.ms.shininess=v;
  emit(settingsChanged(vs.ms));
}

void LightSettingsDialog::setSliderValues(const ViewerSettings &vs_)
{
  // LightSettings
  lAmbSlider->setValue(average(vs_.ls.a));
  lDiffSlider->setValue(average(vs_.ls.d));
  lSpecSlider->setValue(average(vs_.ls.s));
  
  // MaterialSettings
  mEmisSlider->setValue(average(vs_.ms.e));
  mShinSlider->setValue(vs_.ms.shininess);
}

void LightSettingsDialog::setupSliders()
{
  const double s=0.01;
  
  // LightSettings
  lAmbSlider->setRange(0,1);
  lDiffSlider->setRange(0,1);
  lSpecSlider->setRange(0,1);
  
  lAmbSlider->setSingleStep(s);
  lDiffSlider->setSingleStep(s);
  lSpecSlider->setSingleStep(s);
  
  // MaterialSettings
  mEmisSlider->setRange(0,1);
  mShinSlider->setRange(0,128);

  mEmisSlider->setSingleStep(s);
  mShinSlider->setSingleStep(1);
}

void LightSettingsDialog::reject()
{
  hide();
  setViewerSettings(oldVs);
  emit(settingsChanged(oldVs));
  QDialog::reject();
}

void LightSettingsDialog::accept()
{
  oldVs = vs;
  
  QDialog::accept();
}


void LightSettingsDialog::selectBGColor()
{
  QColor color = QColorDialog::getColor(lightViewerWidget->backgroundColor(), this);
  if (color.isValid()) {
    colorSelectorButton->setPalette(QPalette(color));
    vs.bs.bg=color;
    lightViewerWidget->setBackgroundColor(color);
    lightViewerWidget->updateGL();
    
    emit(settingsChanged(vs.bs));
  } else {
    qDebug()<<__PRETTY_FUNCTION__<<": have invalid color!";
  }

}

void LightSettingsDialog::setBGShaded(int s)
{
  bool b;

  if(s==Qt::Checked)
    b = true;
  else if(s==Qt::Unchecked)
    b = false;
  else return;
  
  vs.bs.shaded = b;
  lightViewerWidget->shadeBackground = b;
  lightViewerWidget->updateGL();
  emit(settingsChanged(vs.bs));
}

void LightSettingsDialog::resetToDefaults()
{
  qDebug()<<__PRETTY_FUNCTION__;
  emit(requestResetToDefaults());
  //     viewer->setDefaultLightAndMaterialParameters();
  //     viewer->updateGL();
  //     initLightViewer();
}

void LightSettingsDialog::setViewerSettings(const ViewerSettings &vs_)
{
  this->vs = vs_;
  initLightViewer();
}
