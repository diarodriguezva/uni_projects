#include <snapshot_dialog.hpp>


SnapshotDialog::SnapshotDialog(QWidget *p):
  QDialog(p)
{
  setupUi(this);
  
  connect(nameButton,SIGNAL(clicked()),
 	  this, SLOT(askForName()));

  connect(ratioCheckBox,SIGNAL(stateChanged(int)),
          this, SLOT(fixedRatio(int)));
  // connect(scaleSpinBox,SIGNAL(valueChanged(double)),
  //         this,SLOT(scaleChange(double)));

  fixedRatio(ratioCheckBox->checkState());

  name="snapshot.png";
  nameLineEdit->setText(name);
}

SnapshotDialog::~SnapshotDialog()
{
  
}

void SnapshotDialog::setSize(const QSize sz)
{
  size=sz;
  heightSpinBox->setValue(sz.height());
  widthSpinBox->setValue(sz.width());
}


void SnapshotDialog::setWindowSize(const QSize sz)
{
  windowSize=sz;
}

void SnapshotDialog::fixedRatio(int state)
{
  switch(state)
    {
    case Qt::Checked:
      heightSpinBox->setDisabled(true);
      widthSpinBox->setDisabled(true);
      scaleSpinBox->setDisabled(false);
      break;
    case Qt::Unchecked:
      heightSpinBox->setDisabled(false);
      widthSpinBox->setDisabled(false);
      scaleSpinBox->setDisabled(true);
      break;
    default:
      qDebug()<<"?? "<<__FILE__<<" "<<__LINE__;
    }
}

void SnapshotDialog::scaleChange(double v)
{
  heightSpinBox->setValue(windowSize.height()*v);
  widthSpinBox->setValue(windowSize.width()*v);
}


void SnapshotDialog::askForName()
{
  QString name2 = QFileDialog::getSaveFileName(this, tr("snapshot filename"),"./");
  if(!name2.isEmpty())
    name=name2;
  nameLineEdit->setText(name);
}

void SnapshotDialog::accept()
{
  //if(ratioCheckBox->isChecked())
  // scaleChange(scaleSpinBox->value());
  if(ratioCheckBox->isChecked())
    {
      size.setHeight(heightSpinBox->value()*scaleSpinBox->value());
      size.setWidth(widthSpinBox->value()*scaleSpinBox->value());
    }
  else
    {
      size.setHeight(heightSpinBox->value());
      size.setWidth(widthSpinBox->value());      
    }

  name=nameLineEdit->text();

  hide();
  emit accepted();
}
