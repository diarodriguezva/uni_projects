#include <ctime>
#include <viewer_config.hpp>
#include "viewer.hpp"
#include <iostream>
#include "selectionManager.hpp"
#include <sstream>
#include <cassert>
#include <QtGui>
#include <QGLViewer/domUtils.h>
#include <dbg.hpp>
#include <stdlib.h>
#include <gl_objects.hpp>
#include <QtOpenGL>
#include <limits>
#include <npendel.hpp>

using namespace qglviewer;
using namespace std;

//disable 2D text and coordinate system
#define DRAW_ONLY_PLUGINS

#define GLCHECKERROR                                                    \
  { GLenum err = glGetError();                                          \
    switch(err)                                                         \
      {                                                                 \
      case GL_INVALID_ENUM:                                             \
        qWarning()<<__PRETTY_FUNCTION__<<" L:"<<__LINE__<<", glGetError: GL_INVALID_ENUM"; \
        break;                                                          \
      case GL_INVALID_VALUE:                                            \
        qWarning()<<__PRETTY_FUNCTION__<<" L:"<<__LINE__<<", glGetError: GL_INVALID_VALUE"; \
        break;                                                          \
      case GL_INVALID_OPERATION:                                        \
        qWarning()<<__PRETTY_FUNCTION__<<" L:"<<__LINE__<<", glGetError: GL_INVALID_OPERATION"; \
        break;                                                          \
      case GL_STACK_OVERFLOW:                                           \
        qWarning()<<__PRETTY_FUNCTION__<<" L:"<<__LINE__<<", glGetError: GL_STACK_OVERFLOW"; \
        break;                                                          \
      case GL_STACK_UNDERFLOW:                                          \
        qWarning()<<__PRETTY_FUNCTION__<<" L:"<<__LINE__<<", glGetError: GL_STACK_UNDERFLOW"; \
        break;                                                          \
      case GL_OUT_OF_MEMORY:                                            \
        qWarning()<<__PRETTY_FUNCTION__<<" L:"<<__LINE__<<", glGetError: GL_OUT_OF_MEMORY"; \
        break;                                                          \
      default:                                                          \
        if(err!=0)                                                      \
          qWarning()<<__PRETTY_FUNCTION__<<" L:"<<__LINE__<<", glGetError:"<<err; \
      }}

Viewer::Viewer(QWidget *p):
  QGLViewer(p),
  cameraBallRotation(true),
  pixelAspectRatio(1.0),
  cone(0x0)
{
  setAnimationPeriod(16.6); // 60Hz

  //disable glClear on Painter::begin()
  setAutoFillBackground(false);
  opts.drawAxes=true;
  opts.moveCamera=false;
  opts.drawText2D=true;
  opts.drawMultisampled=true;

  now=tMax=tMaxMin=0;
  dataDir="";
  animSpeed=1.0;
  animateOld=false;
  setSceneRadius(5.0);

  copyrightText = tr("\xa9")+ QString::fromUtf8("2011 Lehrstuhl für Angewandte Mechanik, TUM");
  copyrightTextWidth = fontMetrics().width(copyrightText);

  renderToFBO=0;
  fbo=0x0;

  polyStipple=new GLubyte[32*4];
  unsigned int *t=(unsigned int *)polyStipple;
  for(int i=0; i<16; i++)
    {
      *t++=0x55555555;
      *t++=0xaaaaaaaa;
    }

  selectionHit.numNames=0;
  selectionHit.names=0x0;

  selectionManager = new SelectionManager();
  connect(selectionManager,
          SIGNAL(selectionChanged(const SingleSelectionHit &,
                                  const SingleSelectionHit &)),
          this,
          SLOT(handleSelectionChanged(const SingleSelectionHit &,
                                      const SingleSelectionHit &)));

  cone = new globj::Cone(0.075, 0.3, 12);
  npendel= new NPendel();
}

Viewer::~Viewer()
{
  saveStateToFile();
  delete fbo;
  delete[] polyStipple;
  delete selectionManager;
  delete cone;
  delete npendel;
}


void Viewer::renewFBO(const QSize sz)
{
  if(renderToFBO)
    {
      qDebug()<<__PRETTY_FUNCTION__<<" can't call when render to fbo active!";
      return ;
    }
  if(fbo)
    delete fbo;
  makeCurrent();
  fboX=sz.width();
  fboY=sz.height();
#if 0
  fbo = new QGLFramebufferObject(fboX, fboY,//size
                                 //                              QGLFramebufferObject::Depth,//attach a depth buffer
                                 QGLFramebufferObject::CombinedDepthStencil,//attach a depth and stencil buffer
                                 GL_TEXTURE_2D//target is 2d texture
                                 );//format
#else
  QGLFramebufferObjectFormat fbo_format;
  fbo_format.setAttachment(QGLFramebufferObject::CombinedDepthStencil);
  // format.setInternalTextureFormat(GL_TEXTURE_2D);
  // format.
  fbo_format.setSamples(16);
  fbo=new QGLFramebufferObject(sz, fbo_format);
#endif
}

void Viewer::setDefaultLightAndMaterialParameters()
{
  //DBG;
  // default light parameters
  l0=l1=true;

  GLfloat a=0.1f;
  GLfloat d=0.75f;
  GLfloat s=0.3f;

  la[0]=a; la[1]=a; la[2]=a; la[3]=1;
  ld[0]=d; ld[1]=d; ld[2]=d; ld[3]=1;
  ls[0]=s; ls[1]=s; ls[2]=s; ls[3]=1;

  lp0[0]=-1.0; lp0[1]= 1.0; lp0[2]=0.75; lp0[3]=0.0f;
  lp1[0]= 1.0; lp1[1]=-1.0; lp1[2]=-0.1; lp1[3]=0.0f;

  // default material parameters
  GLfloat e=0.0f;
  me[0]=e; me[1]=e; me[2]=e; me[3]=1;
  mShin=32;

  shadeBackground=true;
  setBackgroundColor(QColor(51,51,102));
}

void Viewer::preDraw()
{

  if(renderToFBO)
    {
      assert(fbo);
      glGetIntegerv(GL_VIEWPORT, oldViewport);
      //       glGetIntegerv(GL_SCISSOR_BOX, oldScissorBox);
      glViewport( 0, 0, fboX, fboY);
      glScissor(0,0,fboX,fboY);

      camera()->setScreenWidthAndHeight(fboX*pixelAspectRatio,fboY);
      fbo->bind();
    }
  // else
  //   {

  // glGetIntegerv(GL_VIEWPORT, oldViewport);

  //   cout<<"viewport:"<<oldViewport[0]<<", "<<oldViewport[1]<<", "<<oldViewport[2]<<", "<<oldViewport[3]<<"\n";

#ifndef NO_STENCIL
  // fill the stencil buffer
  glEnable(GL_STENCIL_TEST);
  glClearStencil(0);
  glClear(GL_STENCIL_BUFFER_BIT);
  // only draw into the stencil buffer by incrementing the values:
  glStencilFunc(GL_NEVER, 0x0, 0x0);
  glStencilOp(GL_INCR, GL_INCR, GL_INCR);

  startScreenCoordinatesSystem(true);
  glNormal3f(0.0, 0.0, 1.0);
  glEnable(GL_POLYGON_STIPPLE);
  glPolygonStipple(polyStipple);

  glBegin(GL_QUADS);
  glVertex2i(width(), height());
  glVertex2i(0, height());
  glVertex2i(0, 0);
  glVertex2i(width(), 0);
  glEnd();

  glDisable(GL_POLYGON_STIPPLE);
  stopScreenCoordinatesSystem();

  glStencilFunc(GL_NOTEQUAL, 0x1, 0x1);
  glStencilOp(GL_KEEP, GL_KEEP, GL_KEEP);

  glDisable(GL_STENCIL_TEST);
  // }
#endif
  // static Vec oldRefPos(0,0,0);
  if(opts.moveCamera)
    {
      AnimInterface *p=npendel;
      if(p!=0x0)
        {
          double ref[3];
          p->getRefPos(ref, now);
          //      ref[0]=0.0;
          //      ref[1]=0.0;
          //      ref[2]=0.0;
          const Vec nowRefPos(ref[0],ref[1],ref[2]);
#if 1
          if(camera()->type()==Camera::ORTHOGRAPHIC)
            {
              camera()->setType(Camera::PERSPECTIVE);
              setSceneCenter(nowRefPos);
              camera()->setType(Camera::ORTHOGRAPHIC);
            }
          else
            setSceneCenter(nowRefPos);
#else
          Viewer::setSceneCenter(nowRefPos);
#endif
          //           camera()->setRevolveAroundPoint(nowRefPos);
          const Vec deltaRefPos = nowRefPos - oldRefPos;
          camera()->setPosition(camera()->position() + deltaRefPos);
          oldRefPos=nowRefPos;

          //      cout<<"nowRefPos="<<nowRefPos<<", deltaRefPos="<<deltaRefPos<<", oldRefPos="<<oldRefPos<<endl;

        }
    }

  // setup up-vector
  if(!cameraBallRotation)
    {
      static Vec oldPlaneNormal(1,0,0);
      const Vec currUpVec=camera()->upVector();
      const Vec currViewDir=camera()->viewDirection();
      Vec planeNormal = Vec(0,0,1) ^ currViewDir;
      if(planeNormal.squaredNorm() < 0.0001f)
        planeNormal=oldPlaneNormal;
      else
        oldPlaneNormal=planeNormal;
      Vec upVec=(camera()->upVector());
      upVec.projectOnPlane(planeNormal);
      camera()->setUpVector(upVec,false);
    }

  // GL_PROJECTION matrix
  camera()->loadProjectionMatrix();
  // GL_MODELVIEW matrix
  camera()->loadModelViewMatrix();

  if(shadeBackground)
    {
      // only clear the depth buffer (the color is overdrawn by the shaded background)
      glClear(GL_DEPTH_BUFFER_BIT);
      drawShadedBackground();
    }
  else
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

#ifndef WIN32
#warning FIXME: GL_MULTISAMPLE on win32
  if(opts.drawMultisampled)
    glEnable(GL_MULTISAMPLE);
  else
    glDisable(GL_MULTISAMPLE);
#endif//WIN32
  emit drawNeeded();
}

void Viewer::drawWithNames()
{
  glPushAttrib(GL_ENABLE_BIT);
  glDisable(GL_LIGHTING);
  glPushName(0);
  npendel->drawWithNames(now);
  glPopName();
  // glEnable(GL_LIGHTING);
  glPopAttrib();
}

// void Viewer::setSceneCenter(const qglviewer::Vec &center)
// {
//   if(QGLViewer::camera()->type()==Camera::ORTHOGRAPHIC)
//     {
//       QGLViewer::camera()->setType(Camera::PERSPECTIVE);
//       QGLViewer::setSceneCenter(center);
//       QGLViewer::camera()->setType(Camera::ORTHOGRAPHIC);
//     }
//   else
//     QGLViewer::setSceneCenter(center);
// }

void drawOutlineText(QPainter*p,
                     QString text,
                     QFont font_,
                     int x, int y,
                     QColor c0, QColor c1)
{
  QPen old_pen=p->pen();
  QFont old_font=p->font();
  QBrush old_brush=p->brush();
  QPainterPath textPath;
  QFont font(font_);

  font.setStyleStrategy(QFont::ForceOutline);
  textPath.addText(x, y, font, text);

  p->setBrush(QBrush(c0,Qt::SolidPattern));

  p->setPen(QPen(c1, 1, Qt::SolidLine, Qt::RoundCap,
                 Qt::RoundJoin));

  p->drawPath(textPath);

  p->setBrush(old_brush);
  p->setPen(old_pen);
}

void Viewer::drawText2D(QPainter*p)
{
  setlocale(LC_NUMERIC,"C");

  QPointF text_pos;
  //   QPen old_pen=p->pen();
  //   QFont old_font=p->font();
#if 1
  QFont font("Times", 14, QFont::Bold);
  font.setStyleHint(QFont::Times, QFont::OpenGLCompatible);
#else
  QFont font;
  font.setPointSize(14);
  font.setStyleHint(QFont::TypeWriter, QFont::OpenGLCompatible);
#endif
  QColor c;

  const QColor bg = backgroundColor();
  if((bg.red()+bg.green()+bg.blue())*0.333333f < 128.0f)
    c=Qt::white;
  else
    c=Qt::black;

  p->save();
  p->setPen(QPen(c));
  //p->setFont(QFont("Times", 12, QFont::Bold));
  p->setFont(font);


  // timestamp upper left corner
  text_pos.setX(10);
  text_pos.setY(20);
  //time text

  QFont timeFont("Monospace",12);
  p->setFont(timeFont);

  char valText[16];
  snprintf(valText,16,"%#06.4f",(double)now);

  // timeStr = tr("time: %1 [s]").arg(now,6,'e',6,'0');
  timeStr=tr("time: %1 [s]").arg(valText);
  p->drawText(text_pos,timeStr);
  p->setFont(font);

  // Copyright Text
  int h=p->fontMetrics().height();
  QRect rect(0,p->device()->height(),p->device()->width(),-(h<<1));
  p->drawText(rect, Qt::AlignCenter, copyrightText);

  p->restore();
}

void Viewer::draw()
{
  glPushMatrix();
  glLoadIdentity();

  // setup Light
  if(l0)
    {
      glEnable(GL_LIGHT0);
      glLightfv(GL_LIGHT0, GL_DIFFUSE, ld);
      glLightfv(GL_LIGHT0, GL_AMBIENT, la);
      glLightfv(GL_LIGHT0, GL_SPECULAR, ls);
      glLightfv(GL_LIGHT0, GL_POSITION, lp0);
    }
  else
    glDisable(GL_LIGHT0);

  if(l1)
    {
      glEnable(GL_LIGHT1);
      glLightfv(GL_LIGHT1, GL_DIFFUSE, ld);
      glLightfv(GL_LIGHT1, GL_AMBIENT, la);
      glLightfv(GL_LIGHT1, GL_SPECULAR, ls);
      glLightfv(GL_LIGHT1, GL_POSITION, lp1);
    }
  else
    glDisable(GL_LIGHT1);

  glPopMatrix();

  glEnable(GL_DEPTH_TEST);

  // setup global Material
  glMaterialfv(GL_FRONT_AND_BACK, GL_EMISSION, me);
  glMaterialf(GL_FRONT_AND_BACK, GL_SHININESS, mShin);

  // draw revolveAroundPoint
  glPushMatrix();
  glDisable(GL_LIGHTING);
  Vec rap=camera()->revolveAroundPoint();
  glDepthRange(0,0.1);
  glColor3f(1,0,0);
  glPointSize(4.0f);
  glEnable(GL_STENCIL_TEST);
  glBegin(GL_POINTS);
  glVertex3fv(rap);
  glEnd();

  glDisable(GL_STENCIL_TEST);
  glDepthRange(0,1);
  glBegin(GL_POINTS);
  glVertex3fv(rap);
  glEnd();
  glEnable(GL_LIGHTING);
  glPopMatrix();

  npendel->draw(now);

}
#include <QGLFormat>
void Viewer::postDraw()
{
  QGLViewer::postDraw();
  //DBG;

  //   printf("postDraw textIsEnabled()=%d\n",(long)textIsEnabled());

  animateOld=animationIsStarted();

  if(opts.drawAxes)
    {
      const float axLen=0.1f;
      npendel->drawAxes(now,axLen,false);
      glDepthRange(0,0.1);
      npendel->drawAxes(now, axLen, true);
      glDepthRange(0,1);
    }

  /*
    {
    QGLFormat f=format();
    printf("QGLformat:\n");
    printf("accum %d, alpha %d, depth %d, hasOverlay %d, sampleBuffers %d, samples %d\n",(long)f.accum(),(long)f.alpha(),(long)f.depth(),(long)f.hasOverlay(),(long)f.sampleBuffers(),(long)f.samples());
    printf("\n");
    }
  */

  if(opts.drawCornerAxis)
    drawCornerAxis();
  // glDisable(GL_MULTISAMPLE);

  // draw 2D elements
  if(opts.drawText2D)
    {
      if(!renderToFBO)
        {
          QPainter p(this);
          drawText2D(&p);
        }
      else
        {
          QPainter p(fbo);
          drawText2D(&p);
        }
    }

  //GLCHECKERROR;
  GLenum err = glGetError();
# if defined (__SUNOS__)
  __PRETTY_FUNCTION__;
# endif /*__SUNOS__*/
  switch(err)
    {
    case GL_INVALID_ENUM:
      qWarning()<<__PRETTY_FUNCTION__<<" L:"<<__LINE__<<", glGetError: GL_INVALID_ENUM";
      break;
    case GL_INVALID_VALUE:
      qWarning()<<__PRETTY_FUNCTION__<<" L:"<<__LINE__<<", glGetError: GL_INVALID_VALUE";
      break;
    case GL_INVALID_OPERATION:
      qWarning()<<__PRETTY_FUNCTION__<<" L:"<<__LINE__<<", glGetError: GL_INVALID_OPERATION";
      break;
    case GL_STACK_OVERFLOW:
      qWarning()<<__PRETTY_FUNCTION__<<" L:"<<__LINE__<<", glGetError: GL_STACK_OVERFLOW";
      break;
    case GL_STACK_UNDERFLOW:
      qWarning()<<__PRETTY_FUNCTION__<<" L:"<<__LINE__<<", glGetError: GL_STACK_UNDERFLOW";
      break;
    case GL_OUT_OF_MEMORY:
      qWarning()<<__PRETTY_FUNCTION__<<" L:"<<__LINE__<<", glGetError: GL_OUT_OF_MEMORY";
      break;
//# ifdef WIN32
 //   case GL_TABLE_TOO_LARGE:
  //    qWarning()<<__PRETTY_FUNCTION__<<" L:"<<__LINE__<<", glGetError: GL_TABLE_TOO_LARGE";
  //    break;
//# endif /*__WIN32__*/
    default:
      if(err!=0)
        qWarning()<<__PRETTY_FUNCTION__<<" L:"<<__LINE__<<", glGetError:"<<err;
    }

  // break cameras rotation
  if(camera()->frame()->isSpinning())
    {
      Quaternion q = camera()->frame()->spinningQuaternion();
      const float angle = q.angle();
      if(angle>0.001f)
        {
          const Vec ax = q.axis();
          // break factor
          const float f=0.95;
          const double s = sin(angle * 0.5 * f);
          q.setValue( s*ax[0], s*ax[1], s*ax[2], cos(angle * 0.5 * f) );
          camera()->frame()->setSpinningQuaternion(q);
        }
      else
        {
          camera()->frame()->stopSpinning();
        }
    }

  if(renderToFBO)
    {
      // all OpenGL rendering after this line is not shown on the picture!
      fbo->release();
      camera()->setScreenWidthAndHeight(width(),height());
      glViewport(0,0,width(),height());
      glScissor(0,0,width(),height());
    }
}

//! rebuilds the default shaded CATIA V5 background
void Viewer::drawShadedBackground()
{
  // disable writing to the depth buffer
  // GLbool depthTest=glIsEnabled(GL_DEPTH_TEST);
  glPushAttrib(GL_ENABLE_BIT);
  glDisable(GL_DEPTH_TEST);

  const GLfloat f1=0.12;
  const GLfloat f2=0.6;
  const QColor bg =backgroundColor();
  const GLfloat c0[3]={(GLfloat)bg.redF(), (GLfloat)bg.greenF(), (GLfloat)bg.blueF()};
  const GLfloat c1[3]={c0[0]*(1-f1)+f1, c0[1]*(1-f1)+f1, c0[2]*(1-f1)+f1};
  const GLfloat c2[3]={c0[0]*(1-f2)+f2, c0[1]*(1-f2)+f2, c0[2]*(1-f2)+f2};
  // defines the position of the color c1 in the middle (pos = 0..1)
  const GLfloat pos=0.3;

  glDisable(GL_LIGHTING);

  startScreenCoordinatesSystem(true);

  glNormal3f(0.0, 0.0, 1.0);
  glBegin(GL_QUAD_STRIP);
  glColor3f(c0[0], c0[1], c0[2]);
  glVertex2i(width(),height());
  glVertex2i(0,height());
  glColor3f(c1[0], c1[1], c1[2]);
  glVertex2i(width(),(GLint)(height()*pos));
  glVertex2i(0,(GLint)(height()*pos));
  glColor3f(c2[0], c2[1], c2[2]);
  glVertex2i(width(),0);
  glVertex2i(0,0);
  glEnd();

  stopScreenCoordinatesSystem();

  // glEnable(GL_LIGHTING);
  // glEnable(GL_DEPTH_TEST);
  glPopAttrib();
}

//! Draws an axis in the lower left corner of the viewport.
//! Adopted from the cornerAxis example from libQGLviewer.
//! Hint: draw it after clearing the depth-buffer. edit: not needed
void Viewer::drawCornerAxis()
{
  glPushAttrib(GL_ENABLE_BIT);

  // The viewport and the scissor are changed to fit the lower left
  // corner. Original values are saved.
  int viewport[4], scissor[4];
  glGetIntegerv(GL_VIEWPORT, viewport);
  glGetIntegerv(GL_SCISSOR_BOX, scissor);

  //   printf("drawCornerAxis: viewport={%d,%d,%d,%d}\n",viewport[0],viewport[1],viewport[2],viewport[3]);
  //   printf("drawCornerAxis: scissor={%d,%d,%d,%d}\n",scissor[0],scissor[1],scissor[2],scissor[3]);
  // Axis viewport size, in pixels
  const int size = 128;
  glViewport(0,0,size,size);
  glScissor(0,0,size+4,size+8);
  glEnable(GL_SCISSOR_TEST);

  // Tune for best line rendering
  glDisable(GL_LIGHTING);

  glMatrixMode(GL_PROJECTION);
  glPushMatrix();
  glLoadIdentity();
  glOrtho(-1, 1, -1, 1, -1, 1);

  glMatrixMode(GL_MODELVIEW);
  glPushMatrix();
  glLoadIdentity();
  glMultMatrixd(camera()->orientation().inverse().matrix());

  glEnable(GL_BLEND);
  glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

  const GLfloat len = 0.6f;

  /*
  // draws a white contour behind
  #if 0
  glDepthRange(0,0.0001);

  // disable GL_LINE_SMOOTH when anti aliasing is enabled in graphics card driver dialog!
  //  glEnable(GL_LINE_SMOOTH);

  const GLfloat len1 = len+0.1f;
  glLineWidth(1.0);
  glColor3f(1.0, 1.0, 1.0);

  glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);

  // x
  glPushMatrix();
  glRotatef(90,0,1,0);
  glTranslatef(0,0,len);
  cone->draw();
  glPopMatrix();

  // y
  glPushMatrix();
  glRotatef(90,-1,0,0);
  glTranslatef(0,0,len);
  cone->draw();
  glPopMatrix();

  // z
  glPushMatrix();
  glTranslatef(0,0,len);
  cone->draw();
  glPopMatrix();

  glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);

  glLineWidth(3.0);

  glBegin(GL_LINES);
  {
  glVertex3f(0.0, 0.0, 0.0);
  glVertex3f(len1, 0.0, 0.0);

  glVertex3f(0.0, 0.0, 0.0);
  glVertex3f(0.0, len1, 0.0);

  glVertex3f(0.0, 0.0, 0.0);
  glVertex3f(0.0, 0.0, len1);
  }
  glEnd();

  glDisable(GL_LINE_SMOOTH);

  glClear(GL_DEPTH_BUFFER_BIT);
  #endif
  */

  glDepthRange(0,0.0001);

  static GLubyte bitmapX_1[] = /* 8x9 x front */
    {
      0x00, 0, 0, 0, /*          */
      0x42, 0, 0, 0, /*  *    *  */
      0x42, 0, 0, 0, /*  *    *  */
      0x24, 0, 0, 0, /*   *  *   */
      0x18, 0, 0, 0, /*    **    */
      0x24, 0, 0, 0, /*   *  *   */
      0x42, 0, 0, 0, /*  *    *  */
      0x42, 0, 0, 0, /*  *    *  */
      0x00, 0, 0, 0  /*          */
    };

  static GLubyte bitmapY_1[] = /* 8x12 y front */
    {
      0x00, 0, 0, 0, /*          */
      0x3c, 0, 0, 0, /*   ****   */
      0x02, 0, 0, 0, /*       *  */
      0x02, 0, 0, 0, /*       *  */
      0x3e, 0, 0, 0, /*   *****  */
      0x42, 0, 0, 0, /*  *    *  */
      0x42, 0, 0, 0, /*  *    *  */
      0x42, 0, 0, 0, /*  *    *  */
      0x42, 0, 0, 0, /*  *    *  */
      0x42, 0, 0, 0, /*  *    *  */
      0x42, 0, 0, 0, /*  *    *  */
      0x00, 0, 0, 0  /*          */
    };

  static GLubyte bitmapZ_1[] = /* 8x9 z front */
    {
      0x00, 0, 0, 0, /*          */
      0x7e, 0, 0, 0, /*  ******  */
      0x40, 0, 0, 0, /*  *       */
      0x20, 0, 0, 0, /*   *      */
      0x10, 0, 0, 0, /*    *     */
      0x08, 0, 0, 0, /*     *    */
      0x04, 0, 0, 0, /*      *   */
      0x7e, 0, 0, 0, /*  ******  */
      0x00, 0, 0, 0  /*          */
    };

  // glEnable(GL_BLEND);
  // // glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
  // glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
  // // glBlendEquation(GL_FUNC_REVERSE_SUBTRACT);

  // x
  // glColor3f(1.0, 1.0, 1.0);
  glColor3f(0.0, 0.0, 0.0);
  // glColor3f(0.5, 0.0, 0.0);
  // glColor4f(1.0, 1.0, 1.0, 0.5);
  glRasterPos3f(0.9, 0, 0);
  glBitmap(8, 9, -2.0, -6.0, 0.0, 0.0, bitmapX_1);

  // vec4f crc;
  // glGetFloatv(GL_CURRENT_RASTER_COLOR, &crc.x);
  // cout<<"crc="<<crc<<endl;


  // y
  // glColor3f(0.0, 0.75, 0.0);
  // glColor3f(0.0, 0.0, 0.0);
  // glColor3f(1.0, 1.0, 1.0);
  // glColor3f(0.0, 0.4, 0.0);
  // glColor4f(1.0, 1.0, 1.0, 0.2);
  glRasterPos3f(0, 0.9, 0);
  glBitmap(8, 12, -2.0, -3.0, 0.0, 0.0, bitmapY_1);


  // z1
  // glColor3f(0.0, 0.0, 0.0);
  // glColor3f(1.0, 1.0, 1.0);
  // glColor3f(0.0, 0.0, 0.5);
  // glColor4f(1.0, 1.0, 1.0, 0);
  glRasterPos3f(0, 0, 0.9);
  glBitmap(8, 9, -2.0, -6.0, 0.0, 0.0, bitmapZ_1);


  // // z2
  // glColor3f(0.0, 0.0, 0.0);
  // // glColor3f(1.0, 1.0, 1.0);
  // glRasterPos3f(0, 0, 0.9);
  // glBitmap(8, 9, -8.0, -7.0, 0.0, 0.0, bitmapZ_1);

  // // glColor4f(1.0, 1.0, 1.0, 0.75);
  // glColor4f(0.7, 0.7, 1.0, 0.55);
  // glRasterPos3f(0, 0, 0.9);
  // glBitmap(8, 9, -8.0, -7.0, 0.0, 0.0, bitmapZ_22);

  // glBlendEquation(GL_FUNC_ADD);

#if 1 // background
  static GLubyte bitmapX_2[] = /* 8x9 x back */
    {
      0xe7, 0, 0, 0, /* ***  *** */
      0xe7, 0, 0, 0, /* *#*  *#* */
      0xff, 0, 0, 0, /* *#****#* */
      0xff, 0, 0, 0, /* **#**#** */
      0x7e, 0, 0, 0, /*  **##**  */
      0xff, 0, 0, 0, /* **#**#** */
      0xff, 0, 0, 0, /* *#****#* */
      0xe7, 0, 0, 0, /* *#*  *#* */
      0xe7, 0, 0, 0  /* ***  *** */
    };

  static GLubyte bitmapY_2[] = /* 8x12 y back */
    {
      0x7e, 0, 0, 0, /*  ******  */
      0x7f, 0, 0, 0, /*  *####** */
      0x7f, 0, 0, 0, /*  *****#* */
      0x7f, 0, 0, 0, /*  *****#* */
      0xff, 0, 0, 0, /* **#####* */
      0xff, 0, 0, 0, /* *#****#* */
      0xe7, 0, 0, 0, /* *#*  *#* */
      0xe7, 0, 0, 0, /* *#*  *#* */
      0xe7, 0, 0, 0, /* *#*  *#* */
      0xe7, 0, 0, 0, /* *#*  *#* */
      0xe7, 0, 0, 0, /* *#*  *#* */
      0xe7, 0, 0, 0  /* ***  *** */
    };

  static GLubyte bitmapZ_21[] = /* 8x9 z back */
    {
      0xff, 0, 0, 0, /* ******** */
      0xff, 0, 0, 0, /* *######* */
      0xff, 0, 0, 0, /* *#****** */
      0xf8, 0, 0, 0, /* **#**    */
      0x7c, 0, 0, 0, /*  **#**   */
      0x3e, 0, 0, 0, /*   **#**  */
      0xff, 0, 0, 0, /* *****#** */
      0xff, 0, 0, 0, /* *######* */
      0xff, 0, 0, 0  /* ******** */
    };

  // static GLubyte bitmapZ_22[] = /* 8x9 z back */
  //   {
  //     0xff, 0, 0, 0, /* ******** */
  //     0xff, 0, 0, 0, /* *######* */
  //     0xff, 0, 0, 0, /* *#****** */
  //     0x70, 0, 0, 0, /*  *#*     */
  //     0x38, 0, 0, 0, /*   *#*    */
  //     0x1c, 0, 0, 0, /*    *#*   */
  //     0xfe, 0, 0, 0, /* *****#*  */
  //     0xff, 0, 0, 0, /* *######* */
  //     0xff, 0, 0, 0  /* ******** */
  //   };

  // glColorMask(GL_FALSE,GL_FALSE,GL_FALSE,GL_FALSE);

  // x back
  glColor4f(1.0, 1.0, 1.0, 0.5);
  // glColor4f(1.0, 0.7, 0.7, 0.25);
  // glColor3f(1.0, 1.0, 1.0);
  glRasterPos3f(0.9, 0, 0);
  glBitmap(8, 9, -2.0, -6.0, 0.0, 0.0, bitmapX_2);
  // y back
  // glColor4f(1.0, 1.0, 1.0, 0.75);
  // glColor4f(0.7, 1.0, 0.7, 0.25);
  glRasterPos3f(0, 0.9, 0);
  glBitmap(8, 12, -2.0, -3.0, 0.0, 0.0, bitmapY_2);
  // z back
  // glColor4f(1.0, 1.0, 1.0, 0.75);
  // glColor4f(0.7, 0.7, 1.0, 0.25);
  glRasterPos3f(0, 0, 0.9);
  glBitmap(8, 9, -2.0, -6.0, 0.0, 0.0, bitmapZ_21);

  // glColorMask(GL_TRUE,GL_TRUE,GL_TRUE,GL_TRUE);

#endif // background

  glDepthRange(0,0.0002);

#if 1 // cone
  const GLfloat c1 = 0.95f;
  // cone cap color
  const GLfloat c2 = 0.75f;
  // line color
  const GLfloat c3 = 1.0f;
  // base color (lower saturation b0<c0..2)
  const GLfloat b0 = 0.0f;

  const GLfloat colx1[4]={c1,b0,b0,1.0f};
  const GLfloat coly1[4]={b0,c1,b0,1.0f};
  const GLfloat colz1[4]={b0,b0,c1,1.0f};

  const GLfloat colx2[4]={c2,b0,b0,1.0f};
  const GLfloat coly2[4]={b0,c2,b0,1.0f};
  const GLfloat colz2[4]={b0,b0,c2,1.0f};
  // draw cones:
  // x
  glPushMatrix();
  glRotatef(90,0,1,0);
  glTranslatef(0,0,len);
  cone->draw(colx1, colx2);
  glPopMatrix();

  // y
  glPushMatrix();
  glRotatef(90,-1,0,0);
  glTranslatef(0,0,len);
  cone->draw(coly1, coly2);
  glPopMatrix();

  // z
  glPushMatrix();
  glTranslatef(0,0,len);
  cone->draw(colz1, colz2);
  glPopMatrix();

  glLineWidth(2.0);
  glBegin(GL_LINES);
  {
    glColor3f(c3, b0, b0);
    glVertex3f(0.0, 0.0, 0.0);
    glVertex3f(len, 0.0, 0.0);

    glColor3f(b0, c3, b0);
    glVertex3f(0.0, 0.0, 0.0);
    glVertex3f(0.0, len, 0.0);

    glColor3f(b0, b0, c3);
    glVertex3f(0.0, 0.0, 0.0);
    glVertex3f(0.0, 0.0, len);
  }
  glEnd();

  glDisable(GL_BLEND);
#endif // cone

  glMatrixMode(GL_PROJECTION);
  glPopMatrix();

  glMatrixMode(GL_MODELVIEW);
  glPopMatrix();
  // glEnable(GL_LIGHTING);

  glPopAttrib();

  // restore viewport and scissor values.
  glScissor(scissor[0],scissor[1],scissor[2],scissor[3]);
  glViewport(viewport[0],viewport[1],viewport[2],viewport[3]);
  glDepthRange(0.0f,1.0f);
}

//! draws the spinning vector of the camera
void Viewer::drawCameraSpinningVector()
{
  Quaternion q = camera()->frame()->spinningQuaternion();
  Quaternion o = camera()->orientation();
  const Vec ax = q.axis();

  const Vec rap = camera()->revolveAroundPoint();
  // defines the length of the drawn vector on screen
  const float pr = 30.0f*camera()->pixelGLRatio(rap);
  const Vec e = o*(pr*ax) + rap;

  // draw the revolveAroundPoint
  glDisable(GL_LIGHTING);
  glPointSize(4);
  glColor3f(1,0,0);
  glBegin(GL_POINTS);
  glVertex3fv(rap);
  glEnd();

  // draw the actual Vector
  glLineWidth(2.0);
  glColor3f(0,0,0);
  glBegin(GL_LINES);
  glVertex3f(rap.x, rap.y, rap.z);
  glColor3f(1,1,0);
  glVertex3f(e.x, e.y, e.z);
  glEnd();
  glEnable(GL_LIGHTING);
}

void Viewer::animate()
{
  const double sec_per_frame=animationPeriod()*1e-3;
  const double dt=animSpeed*sec_per_frame;
  double now_loc=now+dt;
  //cout<<"\n Viewer::animate(): now_loc= "<<now_loc<<" getTMin()= "<<getTMin()<<endl;
  if(now_loc<getTMin())
    now_loc=getTMin();

  if(loopAnimation)
    {
      if(now_loc>=tMaxMin)
        now_loc=0;
      if(now_loc<0)
        now_loc=tMax-1;
    }
  else
    {
      if(now_loc>tMaxMin)
	{
	  toggleAnimation();
	  now_loc=tMaxMin;
	  // emit(animationStopped());
	}
    }
  now = now_loc;

  emit newTime(now_loc);
}

void Viewer::init()
{
  // for selection use shift and left mouse button!
  //mouse bindings
  // setMouseBinding(Qt::NoModifier | Qt::LeftButton, SELECT, true);

  initGLExt();

  // remove default shortcuts
  setShortcut(EXIT_VIEWER,      0);
  //  setShortcut(FULL_SCREEN,      0);
  setShortcut(CAMERA_MODE,      0); // disable useless "revolve or fly"
  setShortcut(STEREO,           0);
  setShortcut(ANIMATION,        0);

  setMouseBinding(Qt::ControlModifier | Qt::LeftButton, FRAME, TRANSLATE);
  setMouseBinding(Qt::ControlModifier | Qt::RightButton, FRAME, ROTATE);


  // Absolutely needed for MouseGrabber
  setMouseTracking(true);

  glMatrixMode(GL_MODELVIEW);
  glLoadIdentity();
  //reset to default OpenGL state
  glDisable(GL_LIGHT0);
  glDisable(GL_LIGHT1);
  glDisable(GL_LIGHT2);
  glDisable(GL_LIGHT3);
  glDisable(GL_LIGHT4);
  glDisable(GL_LIGHT5);
  glDisable(GL_LIGHT6);
  glDisable(GL_LIGHT7);
  glDisable(GL_LIGHTING);
  glDisable(GL_DEPTH_TEST);

  glEnable(GL_DEPTH_TEST);
  glEnable(GL_NORMALIZE);

  //light
  glEnable(GL_LIGHTING);
  setAutoBufferSwap(true);


  npendel->init(".");

  const GLfloat white[4]={1,1,1,1};
  glMaterialfv(GL_FRONT, GL_AMBIENT_AND_DIFFUSE, white);
  glMaterialfv(GL_FRONT, GL_SPECULAR, white);

  setDefaultLightAndMaterialParameters();

  // Restore previous viewer state.
  restoreStateFromFile();

  glSecondaryColor3f(10.0f, -10.0f, -10.0f);
  emit viewerInitialized();
}

QString Viewer::helpString() const
{
  QString text("<h2>Animations-Programm zur Vorlesung RoboterDynamik</h2>");
  text+="<h3> Autoren </h3>";
  text+=QString::fromUtf8("<li> Thomas Buschmann");
  text+="<li> Markus Schwienbacher ";
  text+="<h3> Information</h3>";
  text+=QString::fromUtf8("Einfaches Programm zur Visualisierung der Bewegung einfacher Mehrkörpersysteme ");
  text+="basierend auf QT und QGLViewer \n";
  text+="Fragen / Anregungen /Fehler bitte an  thomas.buschmann@tum.de";
  return text;
}

void Viewer::handleSelectionChanged(const SingleSelectionHit &selected, const SingleSelectionHit &deselected)
{
  cout<<__PRETTY_FUNCTION__<<": d.n="<<deselected.numNames<<endl;
  // deselection
  if(deselected.numNames > 0)
    {
      AnimInterface *pl = npendel;//pm.getPlugin(deselected.names[0]);
      if(pl)
        {
          selectionHit.numNames = 0;
          selectionHit.names=0x0;
          selectionHit.time=now;
          pl->setSelectedObj(-1);
          pl->setSelectionHit(selectionHit);
        }
    }
  // selection
  if(selected.numNames > 0)
    {
      AnimInterface *pl = npendel;//pm.getPlugin(selected.names[0]);
      if(pl)
        {
          selectionHit.numNames = selected.numNames;
          selectionHit.names = selected.names;
          selectionHit.time = now;

          pl->setSelectedObj(selected.names[1]);
          pl->setSelectionHit(selectionHit);

          // used for modifyable/creation plugins
          ManipulatedFrame *mf=pl->getManipulator();
          setManipulatedFrame(mf);
          // avoid a camera position jump, the first plugin can change the camera position:
          if(selectionHit.names[0]==0)
            {
              double ref[3];
              pl->getRefPos(ref, now);
              const Vec nowRefPos(ref[0],ref[1],ref[2]);

#if 1 // still buggy when in Camera::ORTHOGRAPHIC mode
              if(camera()->type()==Camera::ORTHOGRAPHIC)
                {
                  camera()->setType(Camera::PERSPECTIVE);
                  camera()->setRevolveAroundPoint(nowRefPos);
                  // setSceneCenter(nowRefPos);
                  camera()->setType(Camera::ORTHOGRAPHIC);
                }
              else
                camera()->setRevolveAroundPoint(nowRefPos);
              // setSceneCenter(nowRefPos);
#else
              setSceneCenter(nowRefPos);
#endif

              // camera()->setRevolveAroundPoint(nowRefPos);

              // const Vec deltaRefPos = nowRefPos - oldRefPos;

              oldRefPos=nowRefPos;
            }
        }
    }
  else
    setManipulatedFrame(0x0);
}

void Viewer::endSelection(const QPoint& point)
{
  // Flush GL buffers
  glFlush();

  // Get the number of objects that were seen through the pick matrix frustum. Reset GL_RENDER mode.
  GLint nbHits = glRenderMode(GL_RENDER);

  bool found;
  selectionHit.hitPoint=camera()->pointUnderPixel(point, found);
  oldSelectionPoint=point;

  // engage the selection manager to parse the OpenGL select buffer, which sends a selectionChanged(...) signal
  selectionManager->setFromSelectionBuffer(nbHits, selectBuffer(), true);

}



void Viewer::setDataDir(QString dir)
{
  dataDir=dir;
  //pm.forall(&AnimInterface::setDataDir,dataDir);
  npendel->setDataDir(dataDir);
}

void Viewer::updateTimeRange()
{
  //if(pm.num()>0)
    {
      tMaxMin=numeric_limits<double>::max();
      tMin=numeric_limits<double>::max();

      //for(int i=0;i<pm.num();i++)
        {
          AnimInterface*p=npendel;//pm.getPlugin(i);
          assert(0x0!=p);
          tMaxMin=min(p->getTMax(),tMaxMin);
          tMin=min(p->getTMin(),tMin);
          //           cout.precision(15);
          //           cout<<"\ni= "<<i<<" p->getTMax()= "<<p->getTMax()<<"\n";
          //           cout<<"tMaxMin= "<<tMaxMin<<"\n";
          //           cout<<"p->getTMin()= "<<p->getTMin()<<"\n";
          //           cout<<"tMin= "<<tMin<<"\n";
        }
    }
  // else
  //   {
  //     tMin=0;
  //     tMaxMin=0;
  //   }
  //   cout<<"\nViewer::updateTimeRange RESULT: tMaxMin= "<<tMaxMin<<" tMin= "<<tMin<<"\n";
}

#if 1 // new version
void Viewer::loadData(void)
{
  //for(int i=0;i<pm.num();i++)
    {
      AnimInterface*p=npendel;//pm.getPlugin(i);
      assert(0x0!=p);
      // not necessary because we have already set the dataDir on plugin load or on setDataDir(...) call
      // p->setDataDir(dataDir);
      p->loadData();
    }
  updateTimeRange();
}
#else //old version 2009-10-11 21:26:44 +0200
void Viewer::loadData(void)
{
  //DBG;
  double tmp;
  double minimum_tMax=-10;
  int obj=0;
  tMax=0;
  tMin=1e20;

  if(pm.num()>0)
    {
      for(int i=0;i<pm.num();i++)
        {
          AnimInterface*p=pm.getPlugin(i);
          assert(0x0!=p);
          p->setDataDir(dataDir);
          //assume time steps are the same for all plugins!![FIXME!]
          p->loadData();
          tmp=p->getTMax();
          if(obj==0)
            {
              tMax=tmp;
              minimum_tMax=tmp;
            }
          else
            if(AnimInterface::ANIM_TMAX_NONE!=tmp)
              {
                tMax=max(tMax,tmp);
                minimum_tMax=min(minimum_tMax,tmp);
              }
          if(p->getTMin()<tMin)
            tMin=p->getTMin();
          obj++;
        }
      tMaxMin=minimum_tMax;
    }
  else
    {
      tMin=0;
      tMaxMin=0;
    }

  cout<<"\n Viewer::loadData: tMaxMin= "<<tMaxMin<<" tMin= "<<tMin<<"\n";
}
#endif


// void Viewer::removePlugin(QString name)
// {
//   //DBG;
//   pm.delPlugin(name);
// }


//THIS FUNCTION IS NEVER CALLED!!
void Viewer::onNewTime(double now_)
{
  //   qDebug()<<"Viewer::onNewTime( "<<now_<<")";
  if(now!=now_)
    {
      now=now_;
      if(!animationIsStarted())
        {
          updateGL();
        }
    }
}

void Viewer::setAnimSpeed(double x)
{
  animSpeed=x;
}

class ImageWriter : public QThread
{
public:
  ImageWriter(){}
  virtual void run();
  void setImage(const QImage img, const QString &fileName);
private:
  QImage img;
  QString fileName;
};

void ImageWriter::run()
{
  if(img.isNull())
    QMessageBox::critical(0,"writeVideo", "img.isNull() [==> snapshot too large?]");
  else
    {
      if(!img.save(fileName))
        QMessageBox::critical(0,"writeVideo", "saving failed\n"
                              "possible cause: unknown extension/format\n"
                              "known formats are: \n"
                              "png, jpg, jpeg, tiff, bmp, ppm, xpm, xbm");
    }
}

void ImageWriter::setImage(const QImage img_, const QString &fileName_)
{
  // copy data
  img=img_.convertToFormat(QImage::Format_RGB32);
  fileName=QString(fileName_);
}


/*!
  write video sequence
  TODO: use QProcess interface to encode parallel to writing stills
*/
void Viewer::writeVideo(const VideoOptions &opts)
{
  double now_merk=now;
  double deltaNow=1.0/25.0;//25 fps
  Vec cam_merk;
  Vec cam;
  Vec cref;
  QString command;

  cam_merk=camera()->position();

  QSize sz=size();
  QSize videoSize;
  QString snapshotBaseName;
  QString snapshotName="";
  QString infoMsg;

  switch(opts.outputDim)
    {
    case VideoOptions::VGA:
      //resize(640,480);
      videoSize=QSize(640,480);
      infoMsg="using VGA format (640x480)";
      pixelAspectRatio=1.0;
      break;
    case VideoOptions::SVGA:
      //resize(800,600);
      videoSize=QSize(800,600);
      infoMsg="using SVGA format (800x600)";
      pixelAspectRatio=1.0;
      break;
    case VideoOptions::XGA:
      //resize(1024,768);
      videoSize=QSize(1024,768);
      infoMsg="using XGA format (1024x768)";
      pixelAspectRatio=1.0;
      break;
    case VideoOptions::DV_PAL://720x576
      videoSize=QSize(720,576);
      pixelAspectRatio=1.090909;
      infoMsg="using DV-PAL format (720x576)";
      break;
    case VideoOptions::CURRENT:
      videoSize=size();
      infoMsg=QString("using current size (%1x%2)").arg(sz.width()).arg(sz.height());
      break;
    default:
      infoMsg=QString("ILLEGAL size!, using current size as fallback (%1x%2)").arg(sz.width()).arg(sz.height());
    }

  QString oldname=snapshotFileName();
  setSnapshotFileName(opts.baseName);
  snapshotBaseName=opts.baseName;
  int part=0;
  QString base_dir=opts.baseName;

  base_dir.truncate(base_dir.lastIndexOf('/')+1);

  if(base_dir.startsWith("./"))
    {
      QDir dir;
      base_dir.remove(0,2);

      base_dir=dir.currentPath()+base_dir;
      qDebug()<<" currentDir= "<<dir.currentPath();
    }
  if(!base_dir.endsWith('/'))
    base_dir+="/";

  int loop=0;
  int nFrames=10;
  double end=opts.tEnd;
  double start=opts.tStart;

  if(start<tMin)
    start=tMin;
  if(end>tMaxMin)
    end=tMaxMin;

  int num_frames= static_cast<int>((end-start)/deltaNow);
  bool writing_canceled=false;
  QString prog_msg;
  prog_msg=QString("writing video...\n%1").arg(infoMsg);

  QProgressDialog progress(this);
  progress.setCancelButtonText(tr("&Cancel"));
  progress.setRange(0, num_frames);
  progress.setWindowTitle(tr("Export Video"));

  // fbo prepare
  renderToFBO=0;
  // we don't need the alpha channel in video mode
  renewFBO(videoSize);

  int frameNo=0;

  QString labelText2;

  clock_t clk_start=clock();
  clock_t clk_endLast=clk_start;
  int lastLoop=loop;

  clock_t clk_sumImg=0;
  // #define NUM_SAVE_THREADS 4
#ifdef NUM_SAVE_THREADS
  ImageWriter imgWriter[NUM_SAVE_THREADS];
#endif
  for(now=start;now<=end;now+=deltaNow)
    {
      progress.setLabelText(tr("writing frame no. %1 ...\n%2").arg(loop).arg(labelText2));
      progress.setValue(loop);
      qApp->processEvents();
      if(progress.wasCanceled())
        {
          //cout<<"\n *** was canceled"<<endl;
          writing_canceled=true;
          break;
        }
      loop++;

      renderToFBO=1;
      updateGL();
      renderToFBO=0;

      setSnapshotFormat("PNG");
      setSnapshotQuality(95);
      QString frameNoStr=QString("%1").arg(frameNo,4,10,QChar('0'));
      snapshotName=QString("%1_%2.png").arg(snapshotBaseName).arg(frameNoStr);

      clock_t clk_startImg=clock();
#ifdef NUM_SAVE_THREADS
      // save within threads (is not more efficient)
      // search for the first free imageWriter thread:
      int takeThread=-1;
      for(int i=0;i<NUM_SAVE_THREADS;i++)
        {
          if(!imgWriter[i].isRunning())
            {
              // printf("FOUND finished THREAD %d in the pool!\n",(long)i);
              takeThread=i;
              break;
            }
        }
      if(takeThread==-1)
        {
          // printf("TOO FEW THREADS in the pool!\n");
          takeThread=0;
          // if(imgWriter[takeThread].isRunning())
          imgWriter[takeThread].wait();
        }
      // printf("taking thread number: %d\n",(long)takeThread);
      imgWriter[takeThread].setImage(fbo->toImage(), snapshotName);
      imgWriter[takeThread].start();
#else // default
      QImage img=fbo->toImage();
      // get rid of the alpha channel
      img=img.convertToFormat(QImage::Format_RGB32);

      if(img.isNull())
        QMessageBox::critical(0,"writeVideo", "img.isNull() [==> snapshot too large?]");
      else
        {
          if(!img.save(snapshotName))
            QMessageBox::critical(0,"writeVideo", "saving failed\n"
                                  "possible cause: unknown extension/format\n"
                                  "known formats are: \n"
                                  "png, jpg, jpeg, tiff, bmp, ppm, xpm, xbm");
        }
#endif
      clock_t clk_endImg=clock();
      clk_sumImg+=clk_endImg-clk_startImg;

      if((0 == (loop%nFrames))|| (now+deltaNow>=opts.tEnd))
        {
          clock_t clk_end=clock();
          double elapsedTime=(clk_end-clk_start)/(double)CLOCKS_PER_SEC;
          clock_t clk_deltaTime=clk_end-clk_endLast;
          int deltaFrames = loop-lastLoop;

          double writeVideoFPS=CLOCKS_PER_SEC/(double)clk_deltaTime*deltaFrames;
          labelText2=tr("writing Video with %1 fps\ntime elapsed: %2 s\nestimated time left: %3 s").arg(writeVideoFPS).arg(elapsedTime).arg(round(elapsedTime*(num_frames/(double)loop-1.0)));
          // printf("writeVideoFPS=%f\n",writeVideoFPS);


          clk_endLast=clk_end;
          lastLoop=loop;

          // update the viewport itself
          updateGL();
          if(VideoOptions::OUTPUT_WMV1 == opts.outputType)
            {
              QString vcodecOpts("wmv1:vbitrate=8000");
              if(opts.outputDim == VideoOptions::DV_PAL)
                vcodecOpts.append(":aspect=4/3");
              //qDebug()<<" loop = "<<loop<<" encoding\n";
              command=QString("mencoder mf://%1*.png -mf type=png:fps=25 -ovc lavc -lavcopts vcodec=%3"
                              " -of lavf -o %1/__clip_%2.wmv").arg(base_dir).arg(part).arg(vcodecOpts);

              //qDebug()<<"encoding command: "<<command<<"\n";
              system(command.toAscii());
              command=QString("rm -f %1/*.png").arg(base_dir);
              system(command.toAscii());

              part++;
            }
          else if(VideoOptions::OUTPUT_WMV2 == opts.outputType)
            {
              //qDebug()<<" loop = "<<loop<<" encoding\n";
              QString vcodecOpts("wmv2:vbitrate=8000");
              if(opts.outputDim == VideoOptions::DV_PAL)
                vcodecOpts.append(":aspect=4/3");
              command=QString("mencoder mf://%1*.png -mf type=png:fps=25 -ovc lavc -lavcopts vcodec=%3"
                              " -oac copy -o %1/__clip_%2.wmv").arg(base_dir).arg(part).arg(vcodecOpts);

              //qDebug()<<"encoding command: "<<command<<"\n";
              system(command.toAscii());
              command=QString("rm -f %1/*.png").arg(base_dir);
              system(command.toAscii());

              part++;
            }
        }

      frameNo++;
    }

  double timeSingleImg=clk_sumImg/(double)(CLOCKS_PER_SEC*num_frames);
  printf("image saving took: sum %g sec, mean: %g sec\n",(clk_sumImg/(double)(CLOCKS_PER_SEC)),timeSingleImg);

  delete fbo;
  fbo=0x0;

  if((VideoOptions::OUTPUT_WMV1 == opts.outputType) ||
     (VideoOptions::OUTPUT_WMV2 == opts.outputType))
    {
      if(false == writing_canceled)
        {
          //concatenate
          command="cat ";
          for(int i=0;i<part;i++)
            command+=QString(" %1/__clip_%2.wmv ").arg(base_dir).arg(i);
          command+=QString(" > %1/__tmp.wmv").arg(base_dir);
          //qDebug()<<" cat command= "<<command<<"\n";
          system(command.toAscii());
          //fix index
          QString out=opts.baseName.section('/',-1);
          out+=".avi";
          command=QString("mencoder -forceidx -oac copy -ovc copy %1/__tmp.wmv -o %1/%2").arg(base_dir).arg(out);
          //qDebug()<<" idx command = "<<command<<"\n";
          system(command.toAscii());
        }

      command="rm -f ";
      for(int i=0;i<part;i++)
        command+=QString(" %1/__clip_%2.wmv ").arg(base_dir).arg(i);
      command+=QString("  %1/__tmp.wmv").arg(base_dir);
      command+=QString("  %1/*.png").arg(base_dir);
      system(command.toAscii());
    }
  now=now_merk;
  updateGL();
#ifdef NUM_SAVE_THREADS
  // let the working threads finish their work
  for(int i=0;i<NUM_SAVE_THREADS;i++)
    if(imgWriter[i].isRunning())
      imgWriter[i].wait();
#endif
}


void Viewer::snapshot(const QSize sz, const QString name)
{
  //qDebug()<<"sz= "<<sz<<" name= "<<name;
  renderToFBO=0;
  renewFBO(sz);
  renderToFBO=1;
  updateGL();
  renderToFBO=0;
  QImage img=fbo->toImage();
  // get rid of the alpha channel
  img=img.convertToFormat(QImage::Format_RGB32);

  if(img.isNull())
    QMessageBox::critical(0,"Snapshot", "img.isNull() [==> snapshot too large?]");
  else if(!img.save(name))
    QMessageBox::critical(0,"Snapshot", "saving failed\n"
                          "possible cause: unknown extension/format\n"
                          "known formats are: \n"
                          "png, jpg, jpeg, tiff, bmp, ppm, xpm, xbm");
}

/*
// used for animation snapshot
void Viewer::snapshot(const QString name)
{
if(renderToFBO==0)
{
QMessageBox::critical(0,"Snapshot", "renderToFBO==0 [==> fbo renewed?]");
return;
}
updateGL();
QImage img=fbo->toImage();
if(img.isNull())
QMessageBox::critical(0,"Snapshot", "img.isNull() [==> snapshot too large?]");
else
{
if(!img.save(name))
QMessageBox::critical(0,"Snapshot", "saving failed\n"
"possible cause: unknown extension/format\n"
"known formats are: \n"
"png, jpg, jpeg, tiff, bmp, ppm, xpm, xbm");
}
}
*/

void Viewer::setLightSettings(const LightSettings &ls)
{
  //DBG;
  l0=ls.l0;
  if(l0)
    {
      memcpy(this->la, ls.a, 4*sizeof(GLfloat));
      memcpy(this->ld, ls.d, 4*sizeof(GLfloat));
      memcpy(this->ls, ls.s, 4*sizeof(GLfloat));
      memcpy(this->lp0, ls.p0, 4*sizeof(GLfloat));
    }

  l1=ls.l1;
  if(l1)
    {
      memcpy(this->lp1, ls.p1, 4*sizeof(GLfloat));
    }

  updateGL();
}

void Viewer::setMaterialSettings(const MaterialSettings &ms)
{
  //DBG;
  memcpy(this->me, ms.e, 4*sizeof(GLfloat));
  this->mShin = ms.shininess;

  updateGL();
}

void Viewer::setBackgroundSettings(const BackgroundSettings &bs)
{
  this->makeCurrent();
  setBackgroundColor(bs.bg);
  shadeBackground=bs.shaded;

  updateGL();
}

void Viewer::setViewerSettings(const ViewerSettings &vs)
{
  // LightSettings
  l0=vs.ls.l0;
  if(l0)
    {
      memcpy(this->la, vs.ls.a, 4*sizeof(GLfloat));
      memcpy(this->ld, vs.ls.d, 4*sizeof(GLfloat));
      memcpy(this->ls, vs.ls.s, 4*sizeof(GLfloat));
      memcpy(this->lp0, vs.ls.p0, 4*sizeof(GLfloat));
    }

  l1=vs.ls.l1;
  if(l1)
    {
      memcpy(this->lp1, vs.ls.p1, 4*sizeof(GLfloat));
    }

  // MaterialSettings
  memcpy(this->me, vs.ms.e, 4*sizeof(GLfloat));
  this->mShin = vs.ms.shininess;

  // BackgroundSettings
  setBackgroundColor(vs.bs.bg);
  shadeBackground = vs.bs.shaded;

  updateGL();
}



void Viewer::getLightSettings(LightSettings &ls) const
{
  //DBG;
  ls.l0=l0;
  ls.l1=l1;
  memcpy(ls.a, this->la, 4*sizeof(GLfloat));
  memcpy(ls.d, this->ld, 4*sizeof(GLfloat));
  memcpy(ls.s, this->ls, 4*sizeof(GLfloat));
  memcpy(ls.p0, this->lp0, 4*sizeof(GLfloat));
  memcpy(ls.p1, this->lp1, 4*sizeof(GLfloat));
}

void Viewer::getMaterialSettings(MaterialSettings &ms) const
{
  memcpy(ms.e, this->me, 4*sizeof(GLfloat));
  ms.shininess=this->mShin;

}

void Viewer::getViewerSettings(ViewerSettings &vs) const
{
  getLightSettings(vs.ls);
  getMaterialSettings(vs.ms);
  vs.bs.bg = backgroundColor();
  vs.bs.shaded = shadeBackground;
}

void Viewer::vectorFromDomElement(float *v, const unsigned short n, const QDomElement &de)
{
  //DBG;
  if(!de.isNull())
    {
      for(unsigned short i=0;i<n;i++)
        {
          const QString attribute=tr("v%1").arg(i);
          if(de.hasAttribute(attribute))
            {
              const QString s = de.attribute(attribute);
              bool ok;
              s.toFloat(&ok);
              if (ok)
                v[i] = s.toFloat();
              else
                {
                  qWarning()<<__PRETTY_FUNCTION__<<"Bad float syntax for attribute \""<<attribute<<"\" in initialization of \""<<de.tagName()+"\".";
                  v[i]=0;
                }
            }
        }
    }
}

const QDomElement Viewer::vectorDomElement(const float *v, const unsigned short n, const QString &name, QDomDocument &doc) const
{
  //DBG;
  QDomElement de = doc.createElement(name);
  string prefix("v");
  for(unsigned short i=0; i<n; i++)
    {
      de.setAttribute(tr("v%1").arg(i), QString::number(v[i]));
    }
  return de;
}


QDomElement Viewer::domElement(const QString& name, QDomDocument& document) const
{
  //DBG;
  // de is the top node "QGLViewer" in file ".qglviewer.xml"
  QDomElement de = QGLViewer::domElement(name, document);

  // save some data into the already existing "State"-Child
  const QString nodeString("State");
  QDomElement stateNode = de.firstChildElement(nodeString);

  if(stateNode.isNull())
    {
      qDebug()<<__PRETTY_FUNCTION__<<"QDomElement"<<nodeString<<"not found!";
    }
  else
    {
      stateNode.setAttribute("drawAxes",(opts.drawAxes?"true":"false"));
      stateNode.setAttribute("moveCamera",(opts.moveCamera?"true":"false"));
      stateNode.setAttribute("drawMultisampled",(opts.drawMultisampled?"true":"false"));
      stateNode.setAttribute("drawText2D",(opts.drawText2D?"true":"false"));
      stateNode.setAttribute("drawCornerAxis",(opts.drawCornerAxis?"true":"false"));
      stateNode.setAttribute("shadeBackground",(shadeBackground?"true":"false"));
      stateNode.setAttribute("loopAnimation",(loopAnimation?"true":"false"));
      stateNode.setAttribute("cameraBallRotation",(cameraBallRotation?"true":"false"));

      stateNode.appendChild(vectorDomElement(la, 4, "lightAmbient", document));
      stateNode.appendChild(vectorDomElement(ld, 4, "lightDiffuse", document));
      stateNode.appendChild(vectorDomElement(ls, 4, "lightSpecular", document));
      stateNode.setAttribute("light0", l0);
      stateNode.appendChild(vectorDomElement(lp0, 4, "light0_Pos", document));
      stateNode.setAttribute("light1", l1);
      stateNode.appendChild(vectorDomElement(lp1, 4, "light1_Pos", document));

      stateNode.appendChild(vectorDomElement(me, 4, "materialEmission", document));
      stateNode.setAttribute("materialShininess", mShin);
    }

  // save dataDir (for next session) into a new Childnode of "QGLViewer"
  const QString simDataDirNodeString("SimDataDir");
  QDomElement simDataDirNode = document.createElement(simDataDirNodeString);
  simDataDirNode.setAttribute("dir", dataDir);
  de.appendChild(simDataDirNode);

  return de;
}

void Viewer::initFromDOMElement(const QDomElement& element)
{
  //DBG;
  QGLViewer::initFromDOMElement(element);

  const QString nodeString("State");
  QDomElement stateNode = element.firstChildElement(nodeString);
  if(stateNode.isNull())
    {
      qDebug()<<__PRETTY_FUNCTION__<<"QDomElement"<<nodeString<<"not found!";
    }
  else
    {
      opts.drawAxes=DomUtils::boolFromDom(stateNode,"drawAxes", true);
      opts.moveCamera=DomUtils::boolFromDom(stateNode,"moveCamera", true);
      opts.drawMultisampled=DomUtils::boolFromDom(stateNode,"drawMultisampled", true);

      opts.drawText2D=DomUtils::boolFromDom(stateNode,"drawText2D", true);
      opts.drawCornerAxis=DomUtils::boolFromDom(stateNode,"drawCornerAxis", true);

      shadeBackground=DomUtils::boolFromDom(stateNode,"shadeBackground", true);
      loopAnimation=DomUtils::boolFromDom(stateNode,"loopAnimation", true);
      cameraBallRotation=DomUtils::boolFromDom(stateNode,"cameraBallRotation", true);

      // light
      vectorFromDomElement(la, 4, stateNode.firstChildElement("lightAmbient"));
      vectorFromDomElement(ld, 4, stateNode.firstChildElement("lightDiffuse"));
      vectorFromDomElement(ls, 4, stateNode.firstChildElement("lightSpecular"));

      vectorFromDomElement(lp0, 4, stateNode.firstChildElement("light0_Pos"));
      vectorFromDomElement(lp1, 4, stateNode.firstChildElement("light1_Pos"));

      // material
      vectorFromDomElement(me, 4, stateNode.firstChildElement("materialEmission"));
      mShin=DomUtils::floatFromDom(stateNode, "materialShininess", 32);
    }

  // get simulation data directory
  const QString simDataDirNodeString("SimDataDir");
  QDomElement simDataDirNode = element.firstChildElement(simDataDirNodeString);
  if(simDataDirNode.isNull())
    {
      qDebug()<<__PRETTY_FUNCTION__<<"QDomElement"<<simDataDirNodeString<<"not found!";
      return;
    }
  else
    {
      QString dirAttrib("dir");
      if(simDataDirNode.hasAttribute(dirAttrib))
        {
          dataDir = simDataDirNode.attribute(dirAttrib);
        }
      else
        {
          qDebug()<<__PRETTY_FUNCTION__<<"QDomElement"<<simDataDirNodeString<<" has no attribute \""<<dirAttrib<<"\"!";
        }
    }
}


void Viewer::setCameraMode(bool move)
{
  //DBG;
  opts.moveCamera=move;
}


void Viewer::setViewerOptions(const ViewerOptions& opts_)
{
  //DBG;
  opts=opts_;
  printf("moveCamera= %d, drawAxes= %d, drawMultisampled= %d, drawText2D= %d, drawCornerAxis= %d\n",
         (int)(opts.moveCamera),
         (int)(opts.drawAxes),
         (int)(opts.drawMultisampled),
         (int)(opts.drawText2D),
         (int)(opts.drawCornerAxis));

}

ViewerOptions & Viewer::getViewerOptions()
{
  return opts;
}

void Viewer::stepForward()
{
  const double sec_per_frame=animationPeriod()*1e-3;
  const double dt=animSpeed*sec_per_frame;
  double now_loc=now+dt;

  if(now_loc>=tMaxMin)
    now_loc=0;
  if(now_loc<0)
    now_loc=tMax-1;
  now = now_loc;
  emit newTime(now_loc);
  updateGL();
}

void Viewer::stepBackward()
{
  const double sec_per_frame=animationPeriod()*1e-3;
  const double dt=animSpeed*sec_per_frame;
  double now_loc=now-dt;

  if(now_loc>tMaxMin)
    now_loc=tMin;
  if(now_loc<tMin)
    now_loc=tMaxMin;
  now = now_loc;
  emit newTime(now_loc);
  updateGL();
}

void Viewer::setLoopAnimation(bool loop)
{
  loopAnimation=loop;
}

bool Viewer::getLoopAnimation(){ return loopAnimation; }

void Viewer::setCameraBallRotation(bool ballRotation)
{
  cameraBallRotation=ballRotation;
}

bool Viewer::getCameraBallRotation(){ return cameraBallRotation; }

void Viewer::refresh()
{
  updateTimeRange();
  emit newTimeRange();
  updateGL();
}

void Viewer::redraw()
{
  updateGL();
}

void Viewer::addWrl(ofstream&out)
{
  Vec pos=camera()->position();
  Vec axis;
  float angle;
  camera()->orientation().getAxisAngle(axis,angle);
  //add current camera view
  out<<"Viewpoint {\n";
  out<<"position      "<<pos[0]<<" "<<pos[1]<<" "<<pos[2]<<"\n";
  out<<"orientation   "<<axis[0]<<" "<<axis[1]<<" "<<axis[2]<<" "<<angle<<"\n";
  out<<"fieldOfView   "<<camera()->fieldOfView()<<"\n";
  out<<"description   \"Current Viewpoint\"\n";
  out<<"}\n";
}
