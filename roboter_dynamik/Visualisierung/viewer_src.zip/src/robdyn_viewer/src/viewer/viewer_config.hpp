#ifndef __VIEWER_CONFIG__HPP__
#define __VIEWER_CONFIG__HPP__

#ifndef __GNUC__
#define __PRETTY_FUNCTION__ __func__
#endif
#endif//__VIEWER_CONFIG__HPP__
