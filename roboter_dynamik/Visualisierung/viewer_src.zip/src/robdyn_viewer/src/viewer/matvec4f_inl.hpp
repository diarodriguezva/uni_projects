#include <cmath>

// serial matvec4f code

///////////////////////////////////////////////////////////////////////////////
//
//                               M A T R I X
//
///////////////////////////////////////////////////////////////////////////////

// ============================================================================
// Constructors:
// ============================================================================

inline mat4f::mat4f(const mat4f& m)
{
  float *m0 = _L1;
  const float *m1 = &m.m11;
  for (int i=0;i<16;i++,m0++,m1++)
    *m0=*m1;
}

inline mat4f::mat4f(float m11_, float m12_, float m13_, float m14_,
		    float m21_, float m22_, float m23_, float m24_,
		    float m31_, float m32_, float m33_, float m34_,
		    float m41_, float m42_, float m43_, float m44_)
{
  m11 = m11_;  m12 = m12_;  m13 = m13_;  m14 = m14_;
  m21 = m21_;  m22 = m22_;  m23 = m23_;  m24 = m24_;
  m31 = m31_;  m32 = m32_;  m33 = m33_;  m34 = m34_;
  m41 = m41_;  m42 = m42_;  m43 = m43_;  m44 = m44_;
}

inline mat4f::mat4f(const float *arr) 
{
  const float *a=arr;
  float *m=&m11;
  for(int i=0;i<16;i++,m++,a++)
    *m=*a;
}

inline mat4f::mat4f(const vec4f &l1,
		    const vec4f &l2,
		    const vec4f &l3,
		    const vec4f &l4)
{
//   m11=l1.x;  m12=l1.y;  m13=l1.z;  m14=l1.w;
//   m21=l2.x;  m22=l2.y;  m23=l2.z;  m24=l2.w;
//   m31=l3.x;  m32=l3.y;  m33=l3.z;  m34=l3.w;
//   m41=l4.x;  m42=l4.y;  m43=l4.z;  m44=l4.w;

  _L1[0]=l1.x;  _L1[1]=l1.y;  _L1[2]=l1.z;  _L1[3]=l1.w;
  _L2[0]=l2.x;  _L2[1]=l2.y;  _L2[2]=l2.z;  _L2[3]=l2.w;
  _L3[0]=l3.x;  _L3[1]=l3.y;  _L3[2]=l3.z;  _L3[3]=l3.w;
  _L4[0]=l4.x;  _L4[1]=l4.y;  _L4[2]=l4.z;  _L4[3]=l4.w;
}

// ----------------------------------------------------------------------------
//  Func:   mat4f = mat4f
//  Desc:   Matrix assignment.
// ----------------------------------------------------------------------------
inline mat4f& mat4f::operator = (const mat4f& a)
{
  float *m0=_L1;
  const float *m1=&a.m11;
  for(int i=0;i<16;i++,m0++,m1++)
    *m0=*m1;
  return *this;
}

// ============================================================================
// Accessing elements:
// ============================================================================
inline float& mat4f::operator () (int i, int j) {
  //   assert((0<=i) && (i<=3) && (0<=j) && (j<=3));
  return *(((float *)&m11) + (i<<2)+j);
}
inline vec4f& mat4f::operator () (int i) {
  //   assert((0<=i) && (i<=3));
  return *(((vec4f *)&m11) + i);
}

// ============================================================================
// Assignments
// ============================================================================
inline void mat4f::setL1(const vec4f &v){float *l=_L1; l[0]=v.x; l[1]=v.y; l[2]=v.z; l[3]=v.w;}
inline void mat4f::setL2(const vec4f &v){float *l=_L2; l[0]=v.x; l[1]=v.y; l[2]=v.z; l[3]=v.w;}
inline void mat4f::setL3(const vec4f &v){float *l=_L3; l[0]=v.x; l[1]=v.y; l[2]=v.z; l[3]=v.w;}
inline void mat4f::setL4(const vec4f &v){float *l=_L4; l[0]=v.x; l[1]=v.y; l[2]=v.z; l[3]=v.w;}


// ============================================================================
// Operators and member functions:
// ============================================================================

// // ----------------------------------------------------------------------------
// //  Func:  MatrixMult
// //  Desc:  Matrix multiplication of A and B. Returns [A]*[B].
// // ----------------------------------------------------------------------------
// inline mat4f MatrixMult(const mat4f& A, const mat4f& B) {
//     mat4f res;
//     const float *a=&A.m[0];
//     const float *b=&B.m[0];

//     res.m[ 0] = a[ 0]*b[ 0] + a[ 1]*b[ 4] + a[ 2]*b[ 8] + a[ 3]*b[12];
//     res.m[ 1] = a[ 0]*b[ 1] + a[ 1]*b[ 5] + a[ 2]*b[ 9] + a[ 3]*b[13];
//     res.m[ 2] = a[ 0]*b[ 2] + a[ 1]*b[ 6] + a[ 2]*b[10] + a[ 3]*b[14];
//     res.m[ 3] = a[ 0]*b[ 3] + a[ 1]*b[ 7] + a[ 2]*b[11] + a[ 3]*b[15];

//     res.m[ 4] = a[ 4]*b[ 0] + a[ 5]*b[ 4] + a[ 6]*b[ 8] + a[ 7]*b[12];
//     res.m[ 5] = a[ 4]*b[ 1] + a[ 5]*b[ 5] + a[ 6]*b[ 9] + a[ 7]*b[13];
//     res.m[ 6] = a[ 4]*b[ 2] + a[ 5]*b[ 6] + a[ 6]*b[10] + a[ 7]*b[14];
//     res.m[ 7] = a[ 4]*b[ 3] + a[ 5]*b[ 7] + a[ 6]*b[11] + a[ 7]*b[15];

//     res.m[ 8] = a[ 8]*b[ 0] + a[ 9]*b[ 4] + a[10]*b[ 8] + a[11]*b[12];
//     res.m[ 9] = a[ 8]*b[ 1] + a[ 9]*b[ 5] + a[10]*b[ 9] + a[11]*b[13];
//     res.m[10] = a[ 8]*b[ 2] + a[ 9]*b[ 6] + a[10]*b[10] + a[11]*b[14];
//     res.m[11] = a[ 8]*b[ 3] + a[ 9]*b[ 7] + a[10]*b[11] + a[11]*b[15];

//     res.m[12] = a[12]*b[ 0] + a[13]*b[ 4] + a[14]*b[ 8] + a[15]*b[12];
//     res.m[13] = a[12]*b[ 1] + a[13]*b[ 5] + a[14]*b[ 9] + a[15]*b[13];
//     res.m[14] = a[12]*b[ 2] + a[13]*b[ 6] + a[14]*b[10] + a[15]*b[14];
//     res.m[15] = a[12]*b[ 3] + a[13]*b[ 7] + a[14]*b[11] + a[15]*b[15];

//     return res;
// }

// // ----------------------------------------------------------------------------
// //  Func:  MatrixMult
// //  Desc:  Matrix multiplication of A and B. Res = [A]*[B].
// // ----------------------------------------------------------------------------
// inline void MatrixMult(const mat4f& A, const mat4f& B, mat4f &res)
// {
//   const float *a=A.m;
//   //copy in case &res == &A
//   if(&A==&res)
//     {
//       mat4f Temp(A);
//       a = Temp.m;
//     }

//   const float *b=&B.m[0];
//   //copy in case &res == &B
//   if(&B==&res)
//     {
//       mat4f Temp(B);
//       b = Temp.m;
//     }

//   res.m[ 0] = a[ 0]*b[ 0] + a[ 1]*b[ 4] + a[ 2]*b[ 8] + a[ 3]*b[12];
//   res.m[ 1] = a[ 0]*b[ 1] + a[ 1]*b[ 5] + a[ 2]*b[ 9] + a[ 3]*b[13];
//   res.m[ 2] = a[ 0]*b[ 2] + a[ 1]*b[ 6] + a[ 2]*b[10] + a[ 3]*b[14];
//   res.m[ 3] = a[ 0]*b[ 3] + a[ 1]*b[ 7] + a[ 2]*b[11] + a[ 3]*b[15];

//   res.m[ 4] = a[ 4]*b[ 0] + a[ 5]*b[ 4] + a[ 6]*b[ 8] + a[ 7]*b[12];
//   res.m[ 5] = a[ 4]*b[ 1] + a[ 5]*b[ 5] + a[ 6]*b[ 9] + a[ 7]*b[13];
//   res.m[ 6] = a[ 4]*b[ 2] + a[ 5]*b[ 6] + a[ 6]*b[10] + a[ 7]*b[14];
//   res.m[ 7] = a[ 4]*b[ 3] + a[ 5]*b[ 7] + a[ 6]*b[11] + a[ 7]*b[15];

//   res.m[ 8] = a[ 8]*b[ 0] + a[ 9]*b[ 4] + a[10]*b[ 8] + a[11]*b[12];
//   res.m[ 9] = a[ 8]*b[ 1] + a[ 9]*b[ 5] + a[10]*b[ 9] + a[11]*b[13];
//   res.m[10] = a[ 8]*b[ 2] + a[ 9]*b[ 6] + a[10]*b[10] + a[11]*b[14];
//   res.m[11] = a[ 8]*b[ 3] + a[ 9]*b[ 7] + a[10]*b[11] + a[11]*b[15];

//   res.m[12] = a[12]*b[ 0] + a[13]*b[ 4] + a[14]*b[ 8] + a[15]*b[12];
//   res.m[13] = a[12]*b[ 1] + a[13]*b[ 5] + a[14]*b[ 9] + a[15]*b[13];
//   res.m[14] = a[12]*b[ 2] + a[13]*b[ 6] + a[14]*b[10] + a[15]*b[14];
//   res.m[15] = a[12]*b[ 3] + a[13]*b[ 7] + a[14]*b[11] + a[15]*b[15];
// }

// ============================================================================
// Operators and member functions:
// ============================================================================

// ----------------------------------------------------------------------------
//  Func:  mat4f * mat4f
//  Desc:  Matrix multiplication of A and B. Returns [A]*[B].
// ----------------------------------------------------------------------------
inline mat4f operator * (const mat4f& A, const mat4f& B)
{
    mat4f res;
    const float *a=&A.m11;
    const float *b=&B.m11;

    res.m11 = a[ 0]*b[ 0] + a[ 1]*b[ 4] + a[ 2]*b[ 8] + a[ 3]*b[12];
    res.m12 = a[ 0]*b[ 1] + a[ 1]*b[ 5] + a[ 2]*b[ 9] + a[ 3]*b[13];
    res.m13 = a[ 0]*b[ 2] + a[ 1]*b[ 6] + a[ 2]*b[10] + a[ 3]*b[14];
    res.m14 = a[ 0]*b[ 3] + a[ 1]*b[ 7] + a[ 2]*b[11] + a[ 3]*b[15];

    res.m21 = a[ 4]*b[ 0] + a[ 5]*b[ 4] + a[ 6]*b[ 8] + a[ 7]*b[12];
    res.m22 = a[ 4]*b[ 1] + a[ 5]*b[ 5] + a[ 6]*b[ 9] + a[ 7]*b[13];
    res.m23 = a[ 4]*b[ 2] + a[ 5]*b[ 6] + a[ 6]*b[10] + a[ 7]*b[14];
    res.m24 = a[ 4]*b[ 3] + a[ 5]*b[ 7] + a[ 6]*b[11] + a[ 7]*b[15];

    res.m31 = a[ 8]*b[ 0] + a[ 9]*b[ 4] + a[10]*b[ 8] + a[11]*b[12];
    res.m32 = a[ 8]*b[ 1] + a[ 9]*b[ 5] + a[10]*b[ 9] + a[11]*b[13];
    res.m33 = a[ 8]*b[ 2] + a[ 9]*b[ 6] + a[10]*b[10] + a[11]*b[14];
    res.m34 = a[ 8]*b[ 3] + a[ 9]*b[ 7] + a[10]*b[11] + a[11]*b[15];

    res.m41 = a[12]*b[ 0] + a[13]*b[ 4] + a[14]*b[ 8] + a[15]*b[12];
    res.m42 = a[12]*b[ 1] + a[13]*b[ 5] + a[14]*b[ 9] + a[15]*b[13];
    res.m43 = a[12]*b[ 2] + a[13]*b[ 6] + a[14]*b[10] + a[15]*b[14];
    res.m44 = a[12]*b[ 3] + a[13]*b[ 7] + a[14]*b[11] + a[15]*b[15];

    return res;
}

// ----------------------------------------------------------------------------
//  Func:  mat4f + mat4f
//  Desc:  Matrix addition of A and B. Returns [A] + [B].
// ----------------------------------------------------------------------------
// works
inline mat4f operator + (const mat4f &A, const mat4f &B)
{
  mat4f res;
#if 0
  for(int i=0; i<4; i++)
    {
      res.m[(i<<2) + 0] = A.m[(i<<2) + 0] + B.m[(i<<2) + 0];
      res.m[(i<<2) + 1] = A.m[(i<<2) + 1] + B.m[(i<<2) + 1];
      res.m[(i<<2) + 2] = A.m[(i<<2) + 2] + B.m[(i<<2) + 2];
      res.m[(i<<2) + 3] = A.m[(i<<2) + 3] + B.m[(i<<2) + 3];
    }
#elif 0
  for(int i=0; i<16; i+=4)
    {
      res.m[i  ] = A.m[i  ] + B.m[i  ];
      res.m[i+1] = A.m[i+1] + B.m[i+1];
      res.m[i+2] = A.m[i+2] + B.m[i+2];
      res.m[i+3] = A.m[i+3] + B.m[i+3];
    }
#else
  float *r = &res.m11;
  const float *a = &A.m11;
  const float *b = &B.m11;
  for(int i=0; i<16; i++,r++,a++,b++)
    {
      *r = *a + *b;
    }
#endif
  return res;
}
// ----------------------------------------------------------------------------
//  Func:  mat4f - mat4f
//  Desc:  Matrix subtraction of A and B. Returns [A] - [B].
// ----------------------------------------------------------------------------
// works
inline mat4f operator - (const mat4f &A, const mat4f &B)
{
  mat4f res;
#if 1
  float *m=&res.m11;
  const float *a = &A.m11;
  const float *b = &B.m11;
  for(int i=0; i<16; i+=4)
    {
      m[i  ] = a[i  ] - b[i  ];
      m[i+1] = a[i+1] - b[i+1];
      m[i+2] = a[i+2] - b[i+2];
      m[i+3] = a[i+3] - b[i+3];
    }
#else
  float *r = &res.m11;
  const float *a = &A.m11;
  const float *b = &B.m11;
  for(int i=0; i<16; i++,r++,a++,b++)
    {
      *r = *a + *b;
    }
#endif
  return res;
}

// ----------------------------------------------------------------------------
//  Func:  + mat4f
//  Desc:  unary positive Matrix operation. Returns [A].
// ----------------------------------------------------------------------------
// unary +
inline mat4f operator + (const mat4f &A)
{
  return A;
}

// ----------------------------------------------------------------------------
//  Func:  - mat4f
//  Desc:  unary negative Matrix operation. Returns -[A].
// ----------------------------------------------------------------------------
// unary -
inline mat4f operator - (const mat4f &A)
{
  mat4f res;
  float *m=&res.m11;
  const float *a = &A.m11;
  for(int i=0; i<16; i+=4)
    {
      m[i  ] = -a[i  ];
      m[i+1] = -a[i+1];
      m[i+2] = -a[i+2];
      m[i+3] = -a[i+3];
    }
  return res;
}

// ----------------------------------------------------------------------------
//  Func:  mat4f * float
//  Desc:  Matrix scale operation. Returns scale*[A].
// ----------------------------------------------------------------------------
// works!
inline mat4f operator * (const mat4f &A, const float scale)
{
  mat4f res;
  float *m=&res.m11;
  const float *a = &A.m11;
  for(int i=0; i<16; i+=4)
    {
      m[i  ] = scale*a[i  ];
      m[i+1] = scale*a[i+1];
      m[i+2] = scale*a[i+2];
      m[i+3] = scale*a[i+3];
    }
  return res;
}

// ----------------------------------------------------------------------------
//  Func:  float * mat4f
//  Desc:  Matrix scale operation. Returns scale*[A].
// ----------------------------------------------------------------------------
// works!
inline mat4f operator * (const float scale, const mat4f &A)
{
  mat4f res;
  float *m=&res.m11;
  const float *a = &A.m11;
  for(int i=0; i<16; i+=4)
    {
      m[i  ] = scale*a[i  ];
      m[i+1] = scale*a[i+1];
      m[i+2] = scale*a[i+2];
      m[i+3] = scale*a[i+3];
    }
  return res;
}

// ----------------------------------------------------------------------------
//  Func:  mat4f *= mat4f
//  Desc:  Matrix post multiplication.Returns [This]=[This]*[B].
// ----------------------------------------------------------------------------
inline mat4f& mat4f::operator *= (const mat4f &B)
{
  //make a copy
  mat4f Temp(*this);
  float *m=&m11;
  const float *a = &Temp.m11;
  const float *b = &B.m11;

  m[ 0] = b[ 0]*a[ 0] + b[ 1]*a[ 4] + b[ 2]*a[ 8] + b[ 3]*a[12];
  m[ 1] = b[ 0]*a[ 1] + b[ 1]*a[ 5] + b[ 2]*a[ 9] + b[ 3]*a[13];
  m[ 2] = b[ 0]*a[ 2] + b[ 1]*a[ 6] + b[ 2]*a[10] + b[ 3]*a[14];
  m[ 3] = b[ 0]*a[ 3] + b[ 1]*a[ 7] + b[ 2]*a[11] + b[ 3]*a[15];

  m[ 4] = b[ 4]*a[ 0] + b[ 5]*a[ 4] + b[ 6]*a[ 8] + b[ 7]*a[12];
  m[ 5] = b[ 4]*a[ 1] + b[ 5]*a[ 5] + b[ 6]*a[ 9] + b[ 7]*a[13];
  m[ 6] = b[ 4]*a[ 2] + b[ 5]*a[ 6] + b[ 6]*a[10] + b[ 7]*a[14];
  m[ 7] = b[ 4]*a[ 3] + b[ 5]*a[ 7] + b[ 6]*a[11] + b[ 7]*a[15];

  m[ 8] = b[ 8]*a[ 0] + b[ 9]*a[ 4] + b[10]*a[ 8] + b[11]*a[12];
  m[ 9] = b[ 8]*a[ 1] + b[ 9]*a[ 5] + b[10]*a[ 9] + b[11]*a[13];
  m[10] = b[ 8]*a[ 2] + b[ 9]*a[ 6] + b[10]*a[10] + b[11]*a[14];
  m[11] = b[ 8]*a[ 3] + b[ 9]*a[ 7] + b[10]*a[11] + b[11]*a[15];

  m[12] = b[12]*a[ 0] + b[13]*a[ 4] + b[14]*a[ 8] + b[15]*a[12];
  m[13] = b[12]*a[ 1] + b[13]*a[ 5] + b[14]*a[ 9] + b[15]*a[13];
  m[14] = b[12]*a[ 2] + b[13]*a[ 6] + b[14]*a[10] + b[15]*a[14];
  m[15] = b[12]*a[ 3] + b[13]*a[ 7] + b[14]*a[11] + b[15]*a[15];

  return *this;
}

// ----------------------------------------------------------------------------
//  Func:  this *= float
//  Desc:  Matrix scale operation. Returns [this] * scale.
// ----------------------------------------------------------------------------
inline mat4f& mat4f::operator *= (const float s)
{
  float *m=&m11;
  m[ 0] = s*m[ 0];  m[ 1] = s*m[ 1];  m[ 2] = s*m[ 2];  m[ 3] = s*m[ 3];
  m[ 4] = s*m[ 4];  m[ 5] = s*m[ 5];  m[ 6] = s*m[ 6];  m[ 7] = s*m[ 7];
  m[ 8] = s*m[ 8];  m[ 9] = s*m[ 9];  m[10] = s*m[10];  m[11] = s*m[11];
  m[12] = s*m[12];  m[13] = s*m[13];  m[14] = s*m[14];  m[15] = s*m[15];
  return *this;
}

// ----------------------------------------------------------------------------
//  Func:  this += float
//  Desc:  Matrix addition operation. Returns [this] + [B].
// ----------------------------------------------------------------------------
inline mat4f& mat4f::operator += (const mat4f &B)
{
  float *m=&m11;
  const float *a=&B.m11;
  m[ 0] = m[ 0]+a[ 0];  m[ 1] = m[ 1]+a[ 1];  m[ 2] = m[ 2]+a[ 2];  m[ 3] = m[ 3]+a[ 3];
  m[ 4] = m[ 4]+a[ 4];  m[ 5] = m[ 5]+a[ 5];  m[ 6] = m[ 6]+a[ 6];  m[ 7] = m[ 7]+a[ 7];
  m[ 8] = m[ 8]+a[ 8];  m[ 9] = m[ 9]+a[ 9];  m[10] = m[10]+a[10];  m[11] = m[11]+a[11];
  m[12] = m[12]+a[12];  m[13] = m[13]+a[13];  m[14] = m[14]+a[14];  m[15] = m[15]+a[15];
  return *this;
}

// ----------------------------------------------------------------------------
//  Func:  this -= float
//  Desc:  Matrix subtraction operation. Returns [this] + [B].
// ----------------------------------------------------------------------------
inline mat4f& mat4f::operator -= (const mat4f &B)
{
  float *m=&m11;
  const float *b=&B.m11;
  m[ 0] = m[ 0]-b[ 0];  m[ 1] = m[ 1]-b[ 1];  m[ 2] = m[ 2]-b[ 2];  m[ 3] = m[ 3]-b[ 3];
  m[ 4] = m[ 4]-b[ 4];  m[ 5] = m[ 5]-b[ 5];  m[ 6] = m[ 6]-b[ 6];  m[ 7] = m[ 7]-b[ 7];
  m[ 8] = m[ 8]-b[ 8];  m[ 9] = m[ 9]-b[ 9];  m[10] = m[10]-b[10];  m[11] = m[11]-b[11];
  m[12] = m[12]-b[12];  m[13] = m[13]-b[13];  m[14] = m[14]-b[14];  m[15] = m[15]-b[15];
  return *this;
}


// ----------------------------------------------------------------------------
//  Func:  transpose                            T
//  Desc:  transpose this Matrix. Returns [this]
// ----------------------------------------------------------------------------
inline void mat4f::transpose()
{
# define SWAP(_a_,_b_) t=_a_; _a_=_b_; _b_=t
  float t;
  SWAP(m12,m21);  SWAP(m13,m31);  SWAP(m14,m41);
  SWAP(m21,m12);  SWAP(m23,m32);  SWAP(m24,m42);
  SWAP(m31,m13);  SWAP(m32,m23);  SWAP(m34,m43);
  SWAP(m41,m14);  SWAP(m42,m24);  SWAP(m43,m34);
}

inline mat4f & mat4f::translate(const vec4f &p)
{
  m14=p.x;  m24=p.y;  m34=p.z;
  return *this;
}

// ============================================================================
// Stand alone constructors:
// ============================================================================

// ----------------------------------------------------------------------------
//  Func:  Transpose                                   T
//  Desc:  construct the transposed Matrix. Returns [A]
// ----------------------------------------------------------------------------
inline mat4f Transpose(const mat4f &A)
{
  mat4f res;
  res.m11=A.m11;  res.m12=A.m21;  res.m13=A.m31;  res.m14=A.m41;
  res.m21=A.m12;  res.m22=A.m22;  res.m23=A.m32;  res.m24=A.m42;
  res.m31=A.m13;  res.m32=A.m23;  res.m33=A.m33;  res.m34=A.m43;
  res.m41=A.m14;  res.m42=A.m24;  res.m43=A.m34;  res.m44=A.m44;
  return res;
}

// ----------------------------------------------------------------------------
//  Func:  IdentityMatrix
//  Desc:  constructs an identity Matrix. All elements are zero, the trace
//         elements are set to 1. Returns [I]
// ----------------------------------------------------------------------------
inline mat4f IdentityMatrix()
{
  mat4f res;
  res.m11=1.0f;  res.m12=0.0f;  res.m13=0.0f;  res.m14=0.0f;
  res.m21=0.0f;  res.m22=1.0f;  res.m23=0.0f;  res.m24=0.0f;
  res.m31=0.0f;  res.m32=0.0f;  res.m33=1.0f;  res.m34=0.0f;
  res.m41=0.0f;  res.m42=0.0f;  res.m43=0.0f;  res.m44=1.0f;
  return res;
}

///////////////////////////////////////////////////////////////////////////////
//
//                               V E C T O R
//
///////////////////////////////////////////////////////////////////////////////

// ============================================================================
// Constructors:
// ============================================================================

inline vec4f::vec4f(const vec4f& v) : x(v.x), y(v.y), z(v.z), w(v.w) {}
inline vec4f::vec4f(const float x_, const float y_, const float z_, const float w_) : x(x_), y(y_), z(z_), w(w_) {}
inline vec4f::vec4f(const float *arr) : x(arr[0]), y(arr[1]), z(arr[2]), w(arr[3]) {}
inline vec4f::vec4f(const float f) : x(f), y(f), z(f), w(f) {}

// ============================================================================
// Operators and member functions:
// ============================================================================

// ----------------------------------------------------------------------------
//  Func:   vec4f = vec4f
//  Desc:   Vector assignment.
// ----------------------------------------------------------------------------
inline vec4f& vec4f::operator = (const vec4f& a)
{
  x = a.x;  y = a.y;  z = a.z;  w = a.w;
  return *this;
}

// ----------------------------------------------------------------------------
//  Func:   MatVecMult
//  Desc:   Vector multiplication with matrix. [r] = [M]*[v].
// ----------------------------------------------------------------------------
inline void MatVecMult(const mat4f& Mat, const vec4f& Vec, vec4f& res)
{
  float a[4];
  const float *v = Vec.vec;
  for (int i=0; i<4; i++)
    {
      const float *m = &Mat.m[i<<2];
      a[i] = m[0]*v[0] + m[1]*v[1] + m[2]*v[2] + m[3]*v[3];
    }
  res=vec4f(a);
}

// ----------------------------------------------------------------------------
//  Func:   MatVecMult
//  Desc:   Vector multiplication with matrix. Returns [Mat]*[Vec].
// ----------------------------------------------------------------------------
// inline vec4f MatVecMult(const mat4f& Mat, const vec4f& Vec)
// {
// #if 0
//   float a[4];
//   const float *v = Vec.vec;
//   for (int i=0; i<4; i++)
//     {
//       const float *m = &Mat.m[i<<2];
//       a[i] = m[0]*v[0] + m[1]*v[1] + m[2]*v[2] + m[3]*v[3];
//     }
//   return vec4f(a);
// #else
//   vec4f r;
//   const float *m = Mat.m;
//   const float *v = Vec.vec;
//   r.x = m[ 0]*v[0] + m[ 1]*v[1] + m[ 2]*v[2] + m[ 3]*v[3];
//   r.y = m[ 4]*v[0] + m[ 5]*v[1] + m[ 6]*v[2] + m[ 7]*v[3];
//   r.z = m[ 8]*v[0] + m[ 9]*v[1] + m[10]*v[2] + m[11]*v[3];
//   r.w = m[12]*v[0] + m[13]*v[1] + m[14]*v[2] + m[15]*v[3];
//   return r;
// #endif
// }

// ----------------------------------------------------------------------------
//  Func:   MatVecMult
//  Desc:   Vector multiplication with matrix. Returns [Mat]*[Vec].
// ----------------------------------------------------------------------------
inline vec4f operator * (const mat4f &Mat, const vec4f &Vec)
{
  vec4f r;
  // const float *m = &Mat.m11;
  const float *v = Vec.vec;

//   r.x = m[ 0]*v[0] + m[ 1]*v[1] + m[ 2]*v[2] + m[ 3]*v[3];
//   r.y = m[ 4]*v[0] + m[ 5]*v[1] + m[ 6]*v[2] + m[ 7]*v[3];
//   r.z = m[ 8]*v[0] + m[ 9]*v[1] + m[10]*v[2] + m[11]*v[3];
//   r.w = m[12]*v[0] + m[13]*v[1] + m[14]*v[2] + m[15]*v[3];

  const float *l1=Mat._L1, *l2=Mat._L2, *l3=Mat._L3, *l4=Mat._L4;
  r.x = l1[0]*v[0] + l1[1]*v[1] + l1[2]*v[2] + l1[3]*v[3];
  r.y = l2[0]*v[0] + l2[1]*v[1] + l2[2]*v[2] + l2[3]*v[3];
  r.z = l3[0]*v[0] + l3[1]*v[1] + l3[2]*v[2] + l3[3]*v[3];
  r.w = l4[0]*v[0] + l4[1]*v[1] + l4[2]*v[2] + l4[3]*v[3];

  return r;
//   return MatVecMult(Mat, Vec);
}

// Dot Product
// ----------------------------------------------------------------------------
//  Func:   dot4
//  Desc:   Scalar Vector Product. Returns float = [a]*[b].
// ----------------------------------------------------------------------------
inline float dot4(const vec4f &a, const vec4f &b)
{
  return a.x*b.x + a.y*b.y + a.z*b.z + a.w*b.w;
}

// ----------------------------------------------------------------------------
//  Func:   dot3
//  Desc:   Scalar Vector Product which takes only the first three values into
//          account. Returns float = [a]*[b].
// ----------------------------------------------------------------------------
inline float dot3(const vec4f &a, const vec4f &b)
{
  return a.x*b.x + a.y*b.y + a.z*b.z;
}

// ----------------------------------------------------------------------------
//  Func:   vec4f % vec4f
//  Desc:   Cross product of two 3D Vectors. Returns [res] = [a]x[b]
// ----------------------------------------------------------------------------
inline vec4f operator % (const vec4f &a, const vec4f &b)
{
  return cross(a,b);
  // vec4f r;
  // r.x = a.y*b.z - a.z*b.y;
  // r.y = a.z*b.x - a.x*b.z;
  // r.z = a.x*b.y - a.y*b.x;
  // r.w = 0.0f;
  // return r;
}

inline vec4f  cross (const vec4f &a, const vec4f &b)
{
  vec4f r;
  r.x = a.y*b.z - a.z*b.y;
  r.y = a.z*b.x - a.x*b.z;
  r.z = a.x*b.y - a.y*b.x;
  r.w = 0.0f;
  return r;
}

// ----------------------------------------------------------------------------
//  Func:   vec4f | vec4f
//  Desc:   Vector elements product.
// ----------------------------------------------------------------------------
inline vec4f operator | (const vec4f &a, const vec4f &b)
{
  vec4f r;
  r.x=a.x*b.x;  r.y=a.y*b.y;  r.z=a.z*b.z;  r.w=a.w*b.w;
  return r;
}

// ----------------------------------------------------------------------------
//  Func:   vec4f * float
//  Desc:   Vector scale.
// ----------------------------------------------------------------------------
inline vec4f operator * (const vec4f &v, const float s)
{
  vec4f r;
  r.x=v.x*s;  r.y=v.y*s;  r.z=v.z*s;  r.w=v.w*s;
  return r;
}

// ----------------------------------------------------------------------------
//  Func:   float * vec4f
//  Desc:   Vector scale.
// ----------------------------------------------------------------------------
inline vec4f operator * (const float s, const vec4f &v)
{
  vec4f r;
  r.x=v.x*s;  r.y=v.y*s;  r.z=v.z*s;  r.w=v.w*s;
  return r;
}

// ----------------------------------------------------------------------------
//  Func:   +vec4f (unary +)
//  Desc:   Returns v
// ----------------------------------------------------------------------------
inline vec4f operator + (const vec4f &v)
{
  return v;
}

// ----------------------------------------------------------------------------
//  Func:   vec4f + vec4f
//  Desc:   Vector addition. Returns [a] + [b]
// ----------------------------------------------------------------------------
inline vec4f operator + (const vec4f &a, const vec4f &b)
{
  return vec4f(a.x+b.x, a.y+b.y, a.z+b.z, a.w+b.w);
}

// ----------------------------------------------------------------------------
//  Func:   -vec4f (unary -)
//  Desc:   Returns the negative [v]
// ----------------------------------------------------------------------------
inline vec4f operator - (const vec4f &a)
{
  return vec4f(-a.x, -a.y, -a.z, -a.w);
}

// ----------------------------------------------------------------------------
//  Func:   vec4f - vec4f
//  Desc:   Vector substraction. Returns [a] - [b]
// ----------------------------------------------------------------------------
inline vec4f operator - (const vec4f &a, const vec4f &b)
{
  return vec4f(a.x-b.x, a.y-b.y, a.z-b.z, a.w-b.w);
}

// ----------------------------------------------------------------------------
//  Func:   vec4f *= mat4f
//  Desc:   Matrix-Vector-Multiplication. Returns [this] = [Mat] * [this]
// ----------------------------------------------------------------------------
inline vec4f& vec4f::operator *= (const mat4f &Mat)
{
//   MatVecMult(Mat, *this, *this);
//   return *this;

  vec4f t(*this);
  const float *v = t.vec;

//   const float *m = &Mat.m11;
//   x = m[ 0]*v[0] + m[ 1]*v[1] + m[ 2]*v[2] + m[ 3]*v[3];
//   y = m[ 4]*v[0] + m[ 5]*v[1] + m[ 6]*v[2] + m[ 7]*v[3];
//   z = m[ 8]*v[0] + m[ 9]*v[1] + m[10]*v[2] + m[11]*v[3];
//   w = m[12]*v[0] + m[13]*v[1] + m[14]*v[2] + m[15]*v[3];

  const float *l1=Mat._L1, *l2=Mat._L2, *l3=Mat._L3, *l4=Mat._L4;
  x = l1[0]*v[0] + l1[1]*v[1] + l1[2]*v[2] + l1[3]*v[3];
  y = l2[0]*v[0] + l2[1]*v[1] + l2[2]*v[2] + l2[3]*v[3];
  z = l3[0]*v[0] + l3[1]*v[1] + l3[2]*v[2] + l3[3]*v[3];
  w = l4[0]*v[0] + l4[1]*v[1] + l4[2]*v[2] + l4[3]*v[3];

  return *this;
}

// ----------------------------------------------------------------------------
//  Func:   vec4f *= float
//  Desc:   Vector in place scale. Returns [this]*s
// ----------------------------------------------------------------------------
inline vec4f& vec4f::operator *= (const float s)
{
  x*=s;  y*=s;  z*=s;  w*=s;
  return *this;
}

// ----------------------------------------------------------------------------
//  Func:   vec4f |= vec4f
//  Desc:   Vector elements multiplication in place. Returns [this]*[b]
// ----------------------------------------------------------------------------
inline vec4f& vec4f::operator |= (const vec4f &b)
{
  x*=b.x;  y*=b.y;  z*=b.z;  w*=b.w;
  return *this;
}

// ----------------------------------------------------------------------------
//  Func:   vec4f += vec4f
//  Desc:   Vector addition in place. Returns [this]+[b]
// ----------------------------------------------------------------------------
inline vec4f& vec4f::operator += (const vec4f &b)
{
  x+=b.x;  y+=b.y;  z+=b.z;  w+=b.w;
  return *this;
}

// ----------------------------------------------------------------------------
//  Func:   vec4f -= vec4f
//  Desc:   Vector addition in place. Returns [this]-[b]
// ----------------------------------------------------------------------------
inline vec4f& vec4f::operator -= (const vec4f &b)
{
  x-=b.x;  y-=b.y;  z-=b.z;  w-=b.w;
  return *this;
}

// ----------------------------------------------------------------------------
//  Func:   float = vec4f.length4()
//  Desc:   Returns the length of this vector in 4d space
// ----------------------------------------------------------------------------
inline float vec4f::length4() const
{
  return (float)sqrt(x*x + y*y + z*z + w*w);
}

// ----------------------------------------------------------------------------
//  Func:   float = length4(vec4f)
//  Desc:   Returns the length of this vector in 4d space
// ----------------------------------------------------------------------------
inline float length4(const vec4f &v)
{
  return (float)sqrt(v.x*v.x + v.y*v.y + v.z*v.z + v.w*v.w);
}

// ----------------------------------------------------------------------------
//  Func:   float = vec4f.length3()
//  Desc:   Returns the length of this vector in 3d space (only )
// ----------------------------------------------------------------------------
inline float vec4f::length3() const
{
  return (float)sqrt(x*x + y*y + z*z);
}

// ----------------------------------------------------------------------------
//  Func:   float = length3(vec4f)
//  Desc:   Returns the length of this vector in 3d space
// ----------------------------------------------------------------------------
inline float length3(const vec4f &v)
{
  return (float)sqrt(v.x*v.x + v.y*v.y + v.z*v.z);
}

// ----------------------------------------------------------------------------
//  Func:   vec4f.normalize4()
//  Desc:   Normalizes this vector in all 4 dimensions and returns it.
// ----------------------------------------------------------------------------
inline vec4f& vec4f::normalize4()
{
  const float rl = 1/length4();
  *this *= rl;
  return *this;
}

// ----------------------------------------------------------------------------
//  Func:   vec4f = normalize4(vec4f)
//  Desc:   Returns the normalized vector.
// ----------------------------------------------------------------------------
inline vec4f normalize4(const vec4f &v)
{
  vec4f res(v);
  res.normalize4();
  return res;
}

// ----------------------------------------------------------------------------
//  Func:   vec4f.normalize3()
//  Desc:   Normalizes this vector in the first 3 dimensions and returns it.
//          The 4th component (w) is set to zero!
// ----------------------------------------------------------------------------
inline vec4f& vec4f::normalize3()
{
  const float rl = 1/length3();
  x *= rl;  y *= rl;  z *= rl;  w=0.0f;
  return *this;
}

// ----------------------------------------------------------------------------
//  Func:   vec4f = normalize3(vec4f)
//  Desc:   Returns the normalized vector (only the first 3). The 4th component
//          (w) is set to zero!
// ----------------------------------------------------------------------------
inline vec4f normalize3(const vec4f &v)
{
  vec4f res(v);
  res.normalize3();
  return res;
}
