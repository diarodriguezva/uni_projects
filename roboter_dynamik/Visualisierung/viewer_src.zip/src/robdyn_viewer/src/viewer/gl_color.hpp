/*!
@file gl_color.hpp

 utility functions for setting opengl colors

 Author: Thomas Buschmann (buschmann@amm.mw.tum.de)

*/
#ifndef __GLCOLOR_HPP__
#define __GLCOLOR_HPP__
#include <viewer_config.hpp>
#ifndef MACX
#include <GL/gl.h>
#else
#include <OpenGL/gl.h>
#endif//MACX

struct GLColor
{
  GLfloat v[3];
};

inline void glColor(const GLColor c)
{
  glColor3fv(c.v);
}

/*
  some often used colors
*/

const GLColor GLBlack={{0.0,0.0,0.0}};
const GLColor GLGray50={{0.5,0.5,0.5}};
const GLColor GLGray30={{0.3,0.3,0.3}};
const GLColor GLWhite={{1.0,1.0,1.0}};
const GLColor GLOrange={{1.0,0.5,0.0}};
const GLColor GLRed={{1.0,0.0,0.0}};
const GLColor GLGreen={{0.0,1.0,0.0}};
const GLColor GLBlue={{0.0,0.0,1.0}};
const GLColor GLCatiaDefault={{0.823529,0.823529,1}};
#endif//__GLCOLOR_HPP__
