/*!
@file ansi_console.h

 utility macros for ansi console output

 Copyright (C) Thomas Buschmann, Institute of Applied Mechanics, TU-Muenchen
 All rights reserved.
 Contact: buschmann@amm.mw.tum.de

*/
#ifndef __ANSI_CONSOLE_H__
#define __ANSI_CONSOLE_H__

#define ANSI_ESC          "\x1b"
#define ANSI_BEGIN        "\x1b["
#define ANSI_END          "m"

#define ANSI_CODE(x)(ANSI_BEGIN x ANSI_END)

#define ANSI_BOLD         "01"
//colors	       
#define ANSI_FG_BLACK     "30"
#define ANSI_FG_RED       "31"
#define ANSI_FG_GREEN     "32"
#define ANSI_FG_YELLOW    "33" 
#define ANSI_FG_BLUE      "34"
#define ANSI_FG_MAGENTA   "35"
#define ANSI_FG_CYAN      "36"
#define ANSI_FG_WHITE     "37"
#define ANSI_FG_DEFAULT   "39"
#define ANSI_BG_BLACK     "40"
#define ANSI_BG_RED       "41"
#define ANSI_BG_GREEN     "42"
#define ANSI_BG_YELLOW    "43"
#define ANSI_BG_BLUE      "44"
#define ANSI_BG_MAGENTA   "45"
#define ANSI_BG_CYAN      "46"
#define ANSI_BG_WHITE     "47"
#define ANSI_BG_DEFAULT   "49"

#define ANSI_FRAMED       "51"
#define ANSI_ENCIRCLED    "52"
#define ANSI_OVERLINED    "53"
#define ANSI_NOT_ENC_NOT_OVRL "54"
#define ANSI_NOT_OVRL     "55"


#define ANSI_NORMAL (ANSI_FG_DEFAULT ";" ANSI_BG_DEFAULT ";" ANSI_NOT_ENC_NOT_OVRL)
#endif//__ANSI_CONSOLE_H__
