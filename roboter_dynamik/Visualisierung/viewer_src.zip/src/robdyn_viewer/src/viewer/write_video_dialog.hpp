#ifndef __WRITE_VIDEO_DIALOG_HPP__
#define __WRITE_VIDEO_DIALOG_HPP__


#include <QtGui>
#include <QDialog>
#include <QColorDialog>
#include <ui_write_video_dialog.h>
#include <viewer.hpp>


class WriteVideoDialog: public QDialog, private Ui::WriteVideoDialog
{
  Q_OBJECT
  
  public:

  WriteVideoDialog(QWidget *p);
  ~WriteVideoDialog();

  const VideoOptions& getOpts()const{return opts;}		     

private slots:
  void askForName();
  void accept();
private:
  VideoOptions opts;
};

#endif //__WRITE_VIDEO_DIALOG_HPP__
