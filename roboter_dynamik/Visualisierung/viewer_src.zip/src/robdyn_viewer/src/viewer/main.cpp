#include "main_win.hpp"
#include <QtGui>
#include <iostream>
#include <gl_objects.hpp>
using namespace std;

int main(int argc, char** argv)
{
 initGLExt();

  QString conf;
  QApplication app(argc,argv);

  setlocale(LC_NUMERIC,"C");

  QGLFormat glf = QGLFormat::defaultFormat(); 
  glf.setSampleBuffers(true); 
//   glf.setSamples(4); 
  QGLFormat::setDefaultFormat(glf); 

  MainWin win(0,conf);  
  win.setWindowTitle("Animations-Program zur Vorlesung RoboterDynamik");
  win.show();
  return app.exec();
}
