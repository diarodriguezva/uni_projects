#ifndef __SELECTION_HIT__HPP__
#define __SELECTION_HIT__HPP__

#include <QGLViewer/vec.h>

struct SelectionHit
{
  unsigned int numNames;
  const unsigned int *names;
  double time;
  qglviewer::Vec hitPoint;
};

#endif // __SELECTION_HIT__HPP__
