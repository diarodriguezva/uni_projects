/*
  Copyright (C) Markus Schwienbacher, Institute of Applied Mechanics, TU-Muenchen
  All rights reserved.
  Contact: schwienbacher@amm.mw.tum.de
*/

#include <cstdlib>

#include "lightviewer.hpp"

using namespace qglviewer;
using namespace std;

LightViewer::LightViewer(QWidget *p):
  QGLViewer(p),
  shadeBackground(true)
{
  light0 = new ManipulatedFrame();
  light1 = new ManipulatedFrame();
  
  arrow = new Arrow(2.2, 0.6, 0.2, 0.08, 32);
  sphere = new Sphere(0.8, 32);
}

LightViewer::~LightViewer()
{
  delete arrow;
  delete sphere;
}

void LightViewer::drawWithNames()
{
  //  cout<<__PRETTY_FUNCTION__<<"\n";flush(cout);
  //  glPushMatrix();
  
  glPushName(0);
  drawLightArrow(GL_LIGHT0);
  glPopName();
  
  glPushName(1);
  drawLightArrow(GL_LIGHT1);
  glPopName();
  
  glPushName(-1);
  sphere->draw();
  glPopName();
  
  //  glPopMatrix();
}

void LightViewer::postSelection(const QPoint& point)
{
  Q_UNUSED(point);
  
  qDebug()<<__PRETTY_FUNCTION__<<"selectedFrame()="<<selectedName();
  
  if(selectedName()==0)
    setManipulatedFrame(light0);
  else if(selectedName() ==1)
    setManipulatedFrame(light1);
  else if(selectedName() ==-1)
    setManipulatedFrame(NULL);
  else
    return;
}

void LightViewer::preDraw()
{
  if(shadeBackground)
    {
      glClear(GL_DEPTH_BUFFER_BIT);
      drawShadedBackground();
    }
  else
    {
      const QColor bc = backgroundColor();
      glClearColor(bc.redF(), bc.greenF(), bc.blueF(), 1.0f);
      glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    }
  
  // GL_PROJECTION matrix
  camera()->loadProjectionMatrix();
  // GL_MODELVIEW matrix
  camera()->loadModelViewMatrix();
  
  emit drawNeeded();
}

void LightViewer::draw()
{
  //qDebug(__PRETTY_FUNCTION__);
  
  glPushMatrix();
  glLoadIdentity();
  
  // setup Light
  if(l0)
    {
      glEnable(GL_LIGHT0);
      glLightfv(GL_LIGHT0, GL_DIFFUSE, ld);
      glLightfv(GL_LIGHT0, GL_AMBIENT, la);
      glLightfv(GL_LIGHT0, GL_SPECULAR, ls);
      glLightfv(GL_LIGHT0, GL_POSITION, lp0);
    }
  else
    glDisable(GL_LIGHT0);
  if(l1)
    {
      glEnable(GL_LIGHT1);
      glLightfv(GL_LIGHT1, GL_DIFFUSE, ld);
      glLightfv(GL_LIGHT1, GL_AMBIENT, la);
      glLightfv(GL_LIGHT1, GL_SPECULAR, ls);
      glLightfv(GL_LIGHT1, GL_POSITION, lp1);
    }
  else
    glDisable(GL_LIGHT1);
  
  glPopMatrix();
  
  // setup global Material
  glMaterialfv(GL_FRONT, GL_EMISSION, me);
  glMaterialf(GL_FRONT, GL_SHININESS, mShin);
  
  drawLightArrow(GL_LIGHT0, selectedName()==0);
  drawLightArrow(GL_LIGHT1, selectedName()==1);
  
  // since most objects are exported from CATIA V5 draw the sphere in the "default CATIA V5 blue" to get a better feeling of the appearance of the light. 
  glColor3f(0.824f, 0.824f, 1.0f);
  sphere->draw();
}

void LightViewer::drawLightArrow(const GLenum light, const bool selected)
{
  GLboolean lightIsOn;
  glGetBooleanv(light, &lightIsOn);
  
  if (lightIsOn)
    {
      glPushMatrix();
      glLoadIdentity();
      
      
      float posLight[4];
      glGetLightfv(light, GL_POSITION, posLight);
      
      Vec dir(posLight[0], posLight[1], posLight[2]);
      
      Quaternion qlf(Vec(0,0,-1), dir);
      
      Vec pos = camera()->cameraCoordinatesOf(Vec(0,0,0));
      
      glTranslated(pos[0], pos[1], pos[2]);
      glMultMatrixd(qlf.matrix());
      glTranslatef(0,0,-1.0);
      
      // it is not only possible to draw a selected arrow in a different color but also different form (e.g. bigger) by drawing another object
      if(selected)
	glColor3f(1.0f,0.0f,0.0f);
      else
	glColor3f(0.0f,1.0f,0.0f);
      arrow->draw();
      glPopMatrix();
    }
}

// void LightViewer::setDefaultShortcuts()
// {
//   setShortcut(HELP,		Qt::Key_H);
//   keyboardActionDescription_[HELP] = 			"Opens this help window";
// }

// void LightViewer::setDefaultMouseBindings()
// {
//   qDebug()<<__PRETTY_FUNCTION__;
//   setMouseBinding(Qt::NoModifier | Qt::LeftButton, SELECT, true);
//   setMouseBinding(Qt::NoModifier | Qt::LeftButton, FRAME, ROTATE);
// }

void LightViewer::init()
{
  qDebug()<<__PRETTY_FUNCTION__;
  
  glDisable(GL_LIGHT0);
  glDisable(GL_LIGHT1);
  glDisable(GL_LIGHT2);
  glDisable(GL_LIGHT3);
  glDisable(GL_LIGHT4);
  glDisable(GL_LIGHT5);
  glDisable(GL_LIGHT6);
  glDisable(GL_LIGHT7);
  
  connect(light0,SIGNAL(spun()),
	  this,SLOT(updateLight0Pos()));
  connect(light0,SIGNAL(manipulated()),
	  this,SLOT(updateLight0Pos()));
  
  connect(light1,SIGNAL(spun()),
	  this,SLOT(updateLight1Pos()));
  connect(light1,SIGNAL(manipulated()),
	  this,SLOT(updateLight1Pos()));
  


#if 1
  setWheelBinding(Qt::NoModifier, CAMERA, NO_MOUSE_ACTION);

  setHandlerKeyboardModifiers(QGLViewer::FRAME,  Qt::NoModifier);
  setHandlerKeyboardModifiers(QGLViewer::CAMERA,  Qt::NoModifier);
  
  setMouseBinding(Qt::NoModifier | Qt::LeftButton, CAMERA, NO_MOUSE_ACTION);
  setMouseBinding(Qt::NoModifier | Qt::MidButton,   CAMERA, NO_MOUSE_ACTION);
  setMouseBinding(Qt::ControlModifier | Qt::LeftButton, CAMERA, NO_MOUSE_ACTION);
  setMouseBinding(Qt::NoModifier | Qt::RightButton, CAMERA, NO_MOUSE_ACTION);

  setMouseBinding(Qt::NoModifier | Qt::LeftButton, FRAME, ROTATE);
  setMouseBinding(Qt::NoModifier | Qt::MidButton,   FRAME, NO_MOUSE_ACTION);
  setMouseBinding(Qt::NoModifier | Qt::RightButton, FRAME, NO_MOUSE_ACTION);
  
  setMouseBinding(Qt::NoModifier | Qt::LeftButton, SELECT, true);
  
  setMouseBinding(Qt::ShiftModifier | Qt::MidButton, CAMERA, NO_MOUSE_ACTION);

  setMouseBinding(Qt::ShiftModifier | Qt::LeftButton, NO_CLICK_ACTION);
  setMouseBinding(Qt::MidButton, NO_CLICK_ACTION,      true);
  setMouseBinding(Qt::RightButton, NO_CLICK_ACTION,      true);

  setMouseBinding(Qt::LeftButton,  NO_CLICK_ACTION, true, Qt::RightButton);
  setMouseBinding(Qt::RightButton, NO_CLICK_ACTION,  true, Qt::LeftButton);
  setMouseBinding(Qt::LeftButton,  NO_CLICK_ACTION,  true, Qt::MidButton);
  setMouseBinding(Qt::RightButton, NO_CLICK_ACTION,    true, Qt::MidButton);

  setManipulatedFrame(NULL);
  
  
  // remove default accelerators 
  setShortcut(DRAW_AXIS,	0);
  setShortcut(DRAW_GRID,	0);
  setShortcut(DISPLAY_FPS,	0);
  setShortcut(ENABLE_TEXT,	0);
  setShortcut(EXIT_VIEWER,	0);
  setShortcut(SAVE_SCREENSHOT,	0);
  setShortcut(CAMERA_MODE,	0);
  setShortcut(FULL_SCREEN,	0);
  setShortcut(STEREO,		0);
  setShortcut(ANIMATION,	0);
  //  setShortcut(HELP,		0);
  setShortcut(EDIT_CAMERA,	0);
  setShortcut(MOVE_CAMERA_LEFT,	0);
  setShortcut(MOVE_CAMERA_RIGHT,0);
  setShortcut(MOVE_CAMERA_UP,	0);
  setShortcut(MOVE_CAMERA_DOWN,	0);
  setShortcut(INCREASE_FLYSPEED,0);
  setShortcut(DECREASE_FLYSPEED,0);//NO_MOUSE_ACTION
#endif

  glEnable(GL_CULL_FACE);
  glEnable(GL_LIGHTING);
  glEnable(GL_DEPTH_TEST);
  
  //camera()->setSceneRadius(2.2f);
  camera()->setType(Camera::ORTHOGRAPHIC);
  
  const GLfloat white[4]={1,1,1,1};
  glMaterialfv(GL_FRONT, GL_AMBIENT_AND_DIFFUSE, white);
  glMaterialfv(GL_FRONT, GL_SPECULAR, white);
  
  emit viewerInitialized(); 
}

QString LightViewer::helpString() const
{
  return "TESFDSFADFA sadflkjfsa";
}

void LightViewer::setLightSettings(const LightSettings &ls_)
{
  l0=ls_.l0;
  if(l0)
    {
      memcpy(this->la, ls_.a, 4*sizeof(GLfloat));
      memcpy(this->ld, ls_.d, 4*sizeof(GLfloat));
      memcpy(this->ls, ls_.s, 4*sizeof(GLfloat));
      memcpy(this->lp0, ls_.p0, 4*sizeof(GLfloat));
      
      const Vec pos(ls_.p0[0],ls_.p0[1],ls_.p0[2]);
      Quaternion ql(Vec(0,0,1), pos);
      light0->setOrientation(ql);
      light0->setReferenceFrame(camera()->frame());
    }
  
  l1=ls_.l1;
  if(l1)
    {
      memcpy(this->lp1, ls_.p1, 4*sizeof(GLfloat));
      
      const Vec pos(ls_.p1[0],ls_.p1[1],ls_.p1[2]);
      Quaternion ql(Vec(0,0,1), pos);
      light1->setOrientation(ql);
      light1->setReferenceFrame(camera()->frame());
    }
  
  updateGL();
}

void LightViewer::setMaterialSettings(const MaterialSettings &ms)
{
  memcpy(this->me, ms.e, 4*sizeof(GLfloat));
  this->mShin = ms.shininess;
  
  //qDebug()<<__PRETTY_FUNCTION__<<"summary: Material: s:"<<ms.s[0]<<ms.s[1]<<ms.s[2]<<"e:"<<ms.e[0]<<ms.e[1]<<ms.e[2]<<"shin:"<<ms.shininess;
  
  updateGL();
}

void LightViewer::setBackgroundSettings(const BackgroundSettings &bs)
{
  setBackgroundColor(bs.bg);
  shadeBackground=bs.shaded;
  updateGL();
}

void LightViewer::setViewerSettings(const ViewerSettings &vs)
{
  setLightSettings(vs.ls);
  setMaterialSettings(vs.ms);
  setBackgroundSettings(vs.bs);
}

void LightViewer::updateLight0Pos()
{
  const GLdouble *m =light0->matrix();
  emit(lightPosChanged(GL_LIGHT0, Vec(m[8],m[9],m[10])));
}

void LightViewer::updateLight1Pos()
{
  const GLdouble *m =light1->matrix();
  emit(lightPosChanged(GL_LIGHT1, Vec(m[8],m[9],m[10])));
}

// rebuilds the default shaded CATIA V5 background
void LightViewer::drawShadedBackground()
{
  const GLfloat f1=0.12;
  const GLfloat f2=0.6;
  const QColor bc = backgroundColor();
  const GLfloat c0[3]={bc.redF(), bc.greenF(), bc.blueF()};
  const GLfloat c1[3]={c0[0]*(1-f1)+f1, c0[1]*(1-f1)+f1, c0[2]*(1-f1)+f1};
  const GLfloat c2[3]={c0[0]*(1-f2)+f2, c0[1]*(1-f2)+f2, c0[2]*(1-f2)+f2};
  const GLfloat pos=0.3;
  const int h = height();
  const int w = width();
  
  glDisable(GL_LIGHTING);
  
  startScreenCoordinatesSystem(true);
  {
    glNormal3f(0.0, 0.0, 1.0);
    glBegin(GL_QUAD_STRIP);
    glColor3f(c0[0], c0[1], c0[2]);
    glVertex2i(w,h);
    glVertex2i(0,h);
    glColor3f(c1[0], c1[1], c1[2]);
    glVertex2i(w,static_cast<GLint>(h*pos));
    glVertex2i(0,static_cast<GLint>(h*pos));
    glColor3f(c2[0], c2[1], c2[2]);
    glVertex2i(w,0);
    glVertex2i(0,0);
    glEnd();
  }
  stopScreenCoordinatesSystem();
  
  glClear(GL_DEPTH_BUFFER_BIT);
  
  glEnable(GL_LIGHTING);
}
