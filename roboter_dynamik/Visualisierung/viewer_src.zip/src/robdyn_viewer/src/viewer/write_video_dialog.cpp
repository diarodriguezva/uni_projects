#include <viewer_config.hpp>
#include <write_video_dialog.hpp>


WriteVideoDialog::WriteVideoDialog(QWidget *p):
  QDialog(p)
{
  setupUi(this);
  opts.baseName="./frame";
  QDir dir;
  opts.tStart=0.0;
  opts.tEnd=1.0;
  opts.outputType=VideoOptions::OUTPUT_WMV1;
  opts.outputDim=VideoOptions::SVGA;

  dimComboBox->addItem("VGA     (640x480)");
  dimComboBox->addItem("SVGA    (800x600)");
  dimComboBox->addItem("XGA     (1024x768)");
  dimComboBox->addItem("DV-PAL  (720x576)");
  dimComboBox->addItem("current viewer size");

  dimComboBox->setCurrentIndex(1);

  formatComboBox->addItem("png (numbered stills)");
  formatComboBox->addItem("avi (wmv1 codec)");
  formatComboBox->addItem("avi (wmv2 codec)");
  formatComboBox->setCurrentIndex(1);

  nameLineEdit->setText(opts.baseName);
  
  
  connect(namePushButton,SIGNAL(clicked()),
	  this, SLOT(askForName()));

}

WriteVideoDialog::~WriteVideoDialog()
{
  
}

void WriteVideoDialog::askForName()
{
  QString name = QFileDialog::getSaveFileName(this, tr("Base Filename"),"./");
  if(!name.isEmpty())
    opts.baseName=name;
  nameLineEdit->setText(opts.baseName);
}

void WriteVideoDialog::accept()
{
  qDebug()<<"\n "<<__PRETTY_FUNCTION__<<"\n";
  opts.tStart=tStartSpinbox->value();
  opts.tEnd=tEndSpinbox->value();

  opts.outputType=formatComboBox->currentIndex();
  opts.outputDim=dimComboBox->currentIndex();

  opts.baseName=nameLineEdit->text();

  hide();
  emit accepted();
}
