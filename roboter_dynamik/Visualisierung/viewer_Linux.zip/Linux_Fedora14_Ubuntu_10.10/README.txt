Abhängigkeiten: 

---------- Verwendete Bibliotheken -------- 
/lib64/libc.so.6
/lib64/libdl.so.2
/lib64/libexpat.so.1
/lib64/libgcc_s.so.1
/lib64/libglib-2.0.so.0
/lib64/libgobject-2.0.so.0
/lib64/libgthread-2.0.so.0
/lib64/libm.so.6
/lib64/libpthread.so.0
/lib64/librt.so.1
/lib64/libuuid.so.1
/lib64/libz.so.1
/usr/lib64/libfontconfig.so.1
/usr/lib64/libfreetype.so.6
/usr/lib64/libGLU.so.1
/usr/lib64/libICE.so.6
/usr/lib64/libpng12.so.0
/usr/lib64/libQtCore.so.4
/usr/lib64/libQtGui.so.4
/usr/lib64/libQtOpenGL.so.4
/usr/lib64/libQtXml.so.4
/usr/lib64/libSM.so.6
/usr/lib64/libstdc++.so.6
/usr/lib64/libX11.so.6
/usr/lib64/libXau.so.6
/usr/lib64/libxcb.so.1
/usr/lib64/libXcursor.so.1
/usr/lib64/libXext.so.6
/usr/lib64/libXfixes.so.3
/usr/lib64/libXinerama.so.1
/usr/lib64/libXi.so.6
/usr/lib64/libXrandr.so.2
/usr/lib64/libXrender.so.1
/usr/lib64/nvidia/libGL.so.1
/usr/lib64/nvidia/libnvidia-glcore.so.260.19.36
/usr/lib64/nvidia/tls/libnvidia-tls.so.260.19.36


---------- Packete, die diese installieren -------- 
expat-2.0.1-10.fc13.x86_64
fontconfig-2.8.0-2.fc14.x86_64
freetype-2.4.2-4.fc14.x86_64
glib2-2.26.0-2.fc14.x86_64
glibc-2.13-1.x86_64
libgcc-4.5.1-4.fc14.x86_64
libICE-1.0.6-2.fc13.x86_64
libpng-1.2.44-1.fc14.x86_64
libSM-1.1.0-7.fc12.x86_64
libstdc++-4.5.1-4.fc14.x86_64
libuuid-2.18-4.8.fc14.x86_64
libX11-1.3.4-4.fc14.x86_64
libXau-1.0.6-1.fc14.x86_64
libxcb-1.7-1.fc14.x86_64
libXcursor-1.1.10-5.fc14.x86_64
libXext-1.1.2-2.fc14.x86_64
libXfixes-4.0.5-1.fc14.x86_64
libXi-1.3.2-1.fc14.x86_64
libXinerama-1.1-2.fc13.x86_64
libXrandr-1.3.0-5.fc13.x86_64
libXrender-0.9.6-1.fc14.x86_64
mesa-libGLU-7.9-5.fc14.x86_64
qt-4.7.2-8.fc14.x86_64
qt-x11-4.7.2-8.fc14.x86_64
xorg-x11-drv-nvidia-libs-260.19.36-1.fc14.x86_64
zlib-1.2.5-2.fc14.x86_64

Anmerkung: das Programm wurde auf einem System mit Nvidia Karte 
und Nvidia OpenGL Bibliotheken übersetzt
